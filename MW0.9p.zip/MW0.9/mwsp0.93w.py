#!/usr/bin/python3 #0 3
# -*- coding:utf-8 -*-
#author: Jacky.Shi distribute under General Public License v3 http://www.gnu.org/licenses/quick-guide-gplv3.html
#E-mail: 625052847@qq.com 欢迎ＱＱ打赏，留下QQ号方便邮件收获更新信息
''' 3 4 (0 0 0 8)

标准构架
功能方法（函数）

# 4 7 (0 0 69 3433 84 120 126)

模块导入 from import
主程序			
类声明 class MindWay(QDialog)
初始化模式 __init__(self)
界面初始化 initMindWay(self)

# 7 7 (5 0 0 19 29 37 48)

界面操作方法
文件操作方法
计算相关方法
分页相关方法
分页格式方法

# 7 18 (0 0 2421 2389 2236 2206 2199 2184 2153 2067 2060 2110 2014 2006 1762 1511 1491 1115)

显示下栏文件 slot_btn3_openFile
显示上栏文件 slot_btn_openFile(self)
表项响应 ViewOp(self)
获取最新勾选的行号 JustCheckedNumber(self)
顶行更新 FirstLine(self,myStr)
顶显点选行或结果 CopyText(self)
编辑框显示摘录displayextract(self)
删除表显项 DelItemView(self,lnum)
删除点选项 DelItem(self)
手动摘录 Extract(self)
顶行添至点选行后 AddItemView(self,lnum,lstr)
点选行后增加行 AddItem(self)
列表搜索 SearchRow(self,n,FullStep,ss)
列表搜索响应 SearchRun2(self)
文件及列表搜索响应 SearchRun1(self)
记录点选表项 OnOpNumber(self)

# 18 9 (8 0 2361 2342 2304 2250 1514 1316 1183)

本页列表更新进文件 UpListtoFile(self,mylist,lpath)
整列表转文件	WListtoFile(self,mylist,lpath)
行更新进文件 WLinetoFile(self,llist,lpath,lnum)
库文件操作 slot_btn_chooseFile(self)
文件搜索 SearchFile(self,lpath,ss)
文件打开准备 myfileopen(self,slecstr,n)
撤消一步 Undo(self)

# 9 7 (27 0 2425 3077 2579 3350 3299)

分层拆解括号串 AltStr(self,slecstr,digit_num,strcacup)
字串数、符分拆至五位列表	ArrangStr(self,lstr,symb)
算式串计算转化 strcacu(self,mystr)
获取浮点小数位 floatfmt(self,lstr)
检测字串是否实数 IsNumber(self,localstr)

# 7 10 (37 0 1282 1191 1115 1049 848 796 641 593)

判断括号成对 Listp(self,localstr)
索引摘录显示 EIDisp(self)
索引摘录 EIndex (self)
配对分割字串 psplit(self,string,p1,p2)
程序摘录 AutoE(self,string)
分页显示 ExpView(self,top,bot)
分页前跳 forward(self)
分页回跳 backward(self)

# 10 12 (45 0 502 464 411 393 281 124)

@调出弹出框 PopList(self,string,expbnow)
格式文件操作 FFOpen(self)
段落格式编辑 PFormat(self)
数字括号项位 DLFmt(self,datastr)
链接格式编辑 JFormat(self)
增删行格式调整 PJCheck(self)
'''




# 12 14 (64)

#模块导入
#from MWsp import *  #pyuic5 -o MWsp.py MWsp.ui ui文件转换py文件

from tempfile import TemporaryFile,NamedTemporaryFile
import sys,math,random  
from PyQt5 import QtWidgets    #导入相应的包
from PyQt5.QtWidgets import QMessageBox #导入弹出框v0.62
from PyQt5.QtCore import *
from PyQt5.uic import loadUi #直接导用ui文件
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QInputDialog, QLineEdit, QDialog,QApplication,QFileDialog
import sys, os

# 14 35 (77)

class MindWay(QDialog):#类声明
	fileName_choose=""#全局变量
	Ignore=-1#兼容如意软件变量，此版因为考虑python及C等编程语言模式，数字括号设为第2，3位，如意是第1，2位
	PicSize=600
	FormatShow=False
	FFname=""
	ViewList=[]
	AutoMode=False
	Expdic={}
	ExpMode=False
	Expbnow=0
	Expitem=-1
	Expbnow=0
	Expfnow=0
	Expbackstep=0
	Expforestep=0
	FullStep=0
	lViewList=0
	MyOutput=""
	CheckedRowNuber=[]
	JustNum=-1
	mystr=""
	PosFound=-1
	numt1=["","","","",""]
	numt1id=[0,0,0,0,0]
	fmt=3
	PMark='♢'
	JMark='♡'
	promptstr1="特殊字符：☯图片⌇续行♢分页♡链接"
	prompstr="***多文件搜索,逻辑浏览摘录***本页为文件目录页，点中下边文件名，再点上方[上栏]按钮进入内容页，点下方[下栏]按钮，在下栏打开该文件。本目录页可多文件搜索，双击本行,输入搜索关键字；或点[v]将粘贴点中行内容；多条件关键字由','分隔，多内容由空格或'、'分隔，精确数字匹配在第一个字输入'｀'。点中本行后，可勾选整页或(第2次)消勾，勾选进行摘录；点[计算]按钮计算点中行算式，结果显示在本行；点[文库]按钮可增加文件。本软件是自由软件，遵循GPL v3.0许可，见http://www.gnu.org/licenses/quick-guide-gplv3.html，您可以自由再发布（包括要求有偿），但没有担保。"
	OftenFiles="oftenfiles.set"#库文件名
	FruitFile="Fruit.txt"#搜索结果文件名
	IndexFile="Fruit.idx"#搜索结果索引文件名

# 35 5 (92)

	def __init__(self):#初始化模式
		QDialog.__init__(self)
		self.initMindWay()

# 5 66 (128)
		
	def initMindWay(self):#界面初始化
		self.cwd = os.getcwd() # 获取当前程序文件位置
		self.resize(1000,750)   # 设置窗体大小

#		self.ui = Ui_MainWindow()
#		self.ui.setupUi(self) #前两行调入后缀为py的界面与下行效果一致

		self.ui = loadUi('MWsp0.9.ui')#调入对话框界面

		#self.ui.listView.setFixedSize(700,400)

		self.ui.toolButton_1.setFixedSize(20,100)
		self.ui.toolButton_2.setFixedSize(40,20)
		self.ui.toolButton_3.setFixedSize(220,20)
		self.ui.toolButton_4.setFixedSize(220,20)
		self.ui.toolButton_5.setFixedSize(220,20)
		self.ui.toolButton_6.setFixedSize(40,20)

		self.ui.toolButton_7.setFixedSize(20,100)
		self.ui.toolButton_8.setFixedSize(40,20)
		#self.ui.toolButton_9.setToolTip("定位文件")
		self.ui.toolButton_9.setFixedSize(220,20)
		self.ui.toolButton_10.setFixedSize(220,20)
		#self.ui.toolButton_11.setToolTip("打开文件")
		self.ui.toolButton_11.setFixedSize(220,20)
		#self.ui.toolButton_12.setToolTip("计算")
		self.ui.toolButton_12.setFixedSize(40,20)

		self.model = QStandardItemModel()
		self.model2 = QStandardItemModel()
		self.ui.listView.clicked.connect(self.ViewOp)

		self.ui.toolButton_9.clicked.connect(self.slot_btn_chooseFile)#选择文件

		self.ui.toolButton_10.clicked.connect(self.AddItem)#增加项

		self.ui.toolButton_4.clicked.connect(self.DelItem)#删除项

		self.ui.toolButton_11.clicked.connect(self.slot_btn_openFile)#打开文件
		self.ui.toolButton_3.clicked.connect(self.slot_btn3_openFile)#打开下部文件

		self.ui.toolButton_6.clicked.connect(self.SearchRun1)#搜索上栏内容
		self.ui.toolButton_5.clicked.connect(self.SearchRun2)#搜索下栏内容

		self.ui.toolButton_8.clicked.connect(self.CopyText)#V

		self.ui.toolButton_12.clicked.connect(self.handle)#计算

		self.ui.toolButton_24.clicked.connect(self.Undo)#撤消一步摘录索引
		self.ui.toolButton_7.clicked.connect(self.backward)#往回浏览

		self.ui.toolButton.clicked.connect(self.EIndex)#本页摘录索引
		self.ui.toolButton_1.clicked.connect(self.forward)#往前浏览
		self.ui.toolButton_2.clicked.connect(self.Extract)#摘录显示DelItemView

		self.ui.toolButton_14.clicked.connect(self.FFOpen)#右栏文件操作
		self.ui.toolButton_17.clicked.connect(self.PFormat)#新建段落格式
		self.ui.toolButton_18.clicked.connect(self.JFormat)#新建跳跃格式
		self.ui.toolButton_19.clicked.connect(self.PJCheck)#新建跳跃格式

		self.ui.toolButton_13.clicked.connect(QCoreApplication.instance().quit)#退出

		self.myfileopen("",2)
		self.myfileopen(self.OftenFiles,1)

# 66 156 (70)

	def PJCheck(self):#增删行格式调整
		#self.JMark='♡'
		data=self.ui.textEdit.toPlainText()#读取编辑框中内容
		i1=len(data)
		self.DLFmt(data)
		stepf=stepb=0
		ifmt=oldfmt=0
		i3 = 0
		in1 =0#起点行
		in2=0#终点行
		ih=0	
		#EditMode=False
		Peditp=False#调整段格式
		#ddic={}
		Elist=Elinl=[]
		if(i1>0):
			mylist=data.split('\n')
			lm=len(mylist)
			for i in range(lm):
				#print("浏览至行",i)
				if(i==ifmt):#只对格式行检索
					#print("检索",i,"格式行：",mylist[i])
					linelist=mylist[i].split()
					ll=len(linelist)
					if(ll>=self.Ignore+3):#初步判断格式行
						if(linelist[self.Ignore+2]!='0'):#前跳格式不为0
							if(ifmt+1+int(linelist[self.Ignore+2])<=lm):
								ifmt=ifmt+1+int(linelist[self.Ignore+2])#准备下一步要检索的行距
								oldfmt+=1+int(linelist[self.Ignore+2])
								#print("原行号：",oldfmt,"预计下一个格式行为:",ifmt)
								linelist1=mylist[ifmt].split()
							if(len(linelist1)>=self.Ignore+2):#预读行为格式行
								if(linelist1[self.Ignore+1]!=linelist[self.Ignore+2]) or (not linelist1[self.Ignore+2].isdigit()):
									Peditp=True
							else:
								Peditp=True
							if Peditp:
								#print(ifmt,"行检测不符合数字括号格式，开始逐行扫描定位格式行")
								for ir in range(i+2,lm):#从下面第2行开始逐行检验
								#	print("\t",ir,"行：",mylist[ir])
									if(len(mylist[ir].split())>=self.Ignore+2):
										if(mylist[ir].split()[self.Ignore+1]==linelist[self.Ignore+2]) and (mylist[ir].split()[self.Ignore+2].isdigit()):
											ifmt=ir
											stepf=ir-i-1#2
											dlta=stepf-int(linelist[self.Ignore+2])#-2
											ito=i+int(linelist[self.Ignore+2])+1
											Elinl=[i,ifmt,oldfmt-int(linelist[self.Ignore+2])-1,oldfmt,int(linelist[self.Ignore+1]),int(linelist[self.Ignore+2]),dlta]
											Elist.append(Elinl)#将误差存入编辑列表
											#print("\t编辑列表调整为：",Elist)
											#ddic[str(i)]=dlta#将误差存入字典
											#print("\t调整字典成为：",ddic)
											#print("\t更新下一个格式行为:",ifmt,"误差：",dlta,"前跳行",stepf)
											ss=linelist[0]+" "+str(stepf)
											if(ll>2):
												for ir1 in range(2,ll):
													ss=ss+" "+linelist[ir1]
											mylist[i]=ss
											#print("\t格式行",i,"更新为：",mylist[i])
										
											linelist=mylist[ifmt].split()
											ss=str(stepf)+" "+linelist[self.Ignore+2]
											ll=len(linelist)
											if(ll>2):
												for ir1 in range(2,ll):
													ss=ss+" "+linelist[ir1]

											mylist[ifmt]=ss
											#print("\t下一格式行",i,"更新为：",mylist[ifmt],"\n\n")
											Peditp=False
											break
						else:#前跳格式不为0，文件已至尾部
							#print("\t前跳值为0，文件已至尾部")
							break

			#ddic.clear()
			#print(ddic,"字典删除")

			#显示到textedit
			self.ui.textEdit.clear()
			for data in mylist:
				self.ui.textEdit.append(data)

			#调整链接格式
			#print("\n===调整链接格式===\n")
			#print(Elist)
			ifmt=oldfmt=0
			le1=len(Elist)
			for i in range(lm):
				#print("\t\t调整至行",i,)
				if(i==ifmt):#只对格式行检索
				#	print("\n\t\t检索",i,"格式行：",mylist[i])
					linelist=mylist[i].split()
					ll=len(linelist)
					if(ll>=self.Ignore+3):#初步判断格式行
						stepb=int(linelist[self.Ignore+1])
						stepf=int(linelist[self.Ignore+2])
						if(linelist[self.Ignore+2]!='0'):#前跳格式不为0
							if(ifmt+1+int(linelist[self.Ignore+2])<=lm):
								ifmt=ifmt+1+int(linelist[self.Ignore+2])#准备下一步要检索的行距
								#print("\t\t\t预计下一个格式行为:",ifmt)
						if(self.Listp(mylist[i])):#检查有无表（链接）
							jlstr=self.psplit(mylist[i],'(',')')[-1]
							lenstr=len(jlstr)
							jlist=jlstr[1:-1].split()#获取最末列表
							if(jlist[0].isdigit()):#当表首项为数字时，判断为数字括号链接格式
								dltab=dltaf=0
								#print("\t\t遍历各调整段确定回跳偏差")
								for i3 in range(le1):
									if(i<=Elist[i3][1]):
										dltab=Elist[i3][2]-Elist[i3][0]

								#print("\t\t遍历各调整段确定前跳偏差")
								for i3 in range(le1):
									if(i>=Elist[i3][0]):
										dltaf=Elist[i3][3]-Elist[i3][1]
										break
								#print("\t",i,"行名义格式增补： 回跳dltab",dltab,"行,跳前dltaf",dltaf,"行")
								lj=len(jlist)
								for i1 in range(lj):#检查各链接值是否与调整段交叉
									if(i1==0):
										i4=i3=int(jlist[i1])
								#		print("\t\t回跳",i3,"行")
										for i2 in range(le1):#遍历各调整段
											#检查回跳行是否至本行名义格式(未调整前格式)前
											njumpb=i+dltab-stepb-1
								#			print("\t",i,"行名义格式增补+",dltab,"-回步长",stepb+1,"-回跳=",njumpb-i3,"<=?调整前原回步",Elist[i2][2])
								#			print("\t",i,"行名义格式增补+",dltab,"-回步长",stepb+1,"=",njumpb,">=?调整前原前步",Elist[i2][3],"\n")
											if ((njumpb-i3) <= Elist[i2][2]) and (njumpb >= Elist[i2][3]):
								#				print("\t\t跳跃链接跨越",Elist[i2][0],"至",Elist[i2][1],"行","调整",Elist[i2][6])
												i4=i4+Elist[i2][6]
								#				print("\t\t\t回跳格式调整值",i4)
										ss=str(i4)
								#		print("\t\t\t0项",ss,"\n")

									else:
										i4=i3=int(jlist[i1])
								#		print("\t\t前跳",i3,"行")
										for i2 in range(le1):#遍历各调整段
											#检查前跳行是否至本行名义格式(未调整前格式)后
											njumpf=i+dltaf+stepf+1
								#			print("\t\t",i,"行名义格式增补+",dltaf,"+前步长",stepf+1,"+前跳",i3,"=",njumpf+i3,">=?调整前原前步",Elist[i2][3])
								#			print("\t\t",i,"行名义格式增补+",dltaf,"+前步长",stepf+1,"=",njumpf,"<=?调整前原回步",Elist[i2][2],"\n")
											if ((njumpf+i3) >= Elist[i2][3]) and (njumpf <= Elist[i2][2]):
								#				print("\t\t跳跃链接跨越原",Elist[i2][2],"至",Elist[i2][3],"行","调整",Elist[i2][6])
												i4=i4+Elist[i2][6]
								#				print("\t\t\t后跳格式调整值",i4)
										ss+=" "+str(i4)
								#	print("\t\t调整后",ss)
								mylist[i]=mylist[i][:-lenstr]+'('+ss+')'
								#print("\t",i,"行调整后:[",mylist[i],"]\n")
			#显示到textedit
			self.ui.textEdit.clear()
			for data in mylist:
				self.ui.textEdit.append(data)

# 156 111 (137)

	def JFormat(self):#链接格式编辑
		#self.JMark='♡'
		data=self.ui.textEdit.toPlainText()#读取编辑框中内容
		self.DLFmt(data)
		i1=len(data)
		stepf=stepb=0
		ifmt=0
		i3 = 0
		in1 =0#起点行
		in2=0#终点行
		ih=0	
		if(i1>0):
			mylist=data.split('\n')
			lm=len(mylist)

			for i in range(lm):
				#print("运行行",i)
				if(i==ifmt):#只对格式行检索
					#print("检索",i,"格式行：",mylist[i])
					linelist=mylist[i].split()
					if(len(linelist)>=self.Ignore+3):#初步判断格式行
						if(linelist[self.Ignore+2]!='0'):
							ifmt+=1+int(linelist[self.Ignore+2])#准备下一步要检索的行距
							#print("\t计算下一个格式行为:",ifmt)
						else:
							#print("\t前跳值为0")
							break
						if(self.Listp(mylist[i])):#有无括号格式
							jumpstr=self.psplit(mylist[i],'(',')')[-1]
							#print("\t\t发现括号字串",jumpstr)#最后一个括号项为跳跃格式
							if(jumpstr.find(self.JMark)>=0):#整体浏览有链接标记
								jumplist=jumpstr[1:-1].split()
								i2=0
								for jumpit in jumplist:#搜索标记符，确定前半标记
									if(jumpit.find(self.JMark)<0):#子项没有发现链接标记
										if(i2==0):
											strt=jumpit
										else:
											strt=strt+" "+jumpit
									else:	#子项有发现链接标记
										markstr=jumpit
										stepf=int(linelist[self.Ignore+2])
										ifmt1=i+stepf+1
										for i3 in range(i+stepf+1,lm):#搜索配对标记，直到发现替换
											if(i3==ifmt1):#只对格式行检索
												#print("\t\t\t配对标记检索",i3,"格式行：",mylist[i3])
												linelist1=mylist[i3].split()
												if(len(linelist1)>=self.Ignore+3):#初步判断格式行
													if(linelist1[self.Ignore+2]!='0'):
														ifmt1+=1+int(linelist1[self.Ignore+2])
														#print("\t\t寻找配对链接计算下一个格式行为:",ifmt1)
													f3=mylist[i3].find(markstr)
													if(f3>=0):
														stepb=int(linelist1[self.Ignore+1])
														ifstr=str(i3-(i+stepf+1))
														ibstr=str(i3-(stepb+1)-i)
														strt=strt+" "+ifstr
														#print(i3,"行配对链接标记：",markstr,"前跳",ifstr,"回跳",ibstr,"跳跃格式",strt)
														if(self.Listp(mylist[i3])):
														#	print(i3,"行有括号，准备替换")
															jumpstr1=self.psplit(mylist[i3],'(',')')[-1][1:-1]
															jumplist1=jumpstr1.split()
															i4=0
															for jumpit1 in jumplist1:
																if(jumpit1!=markstr):
																	if(i4==0):
																		strt1=jumpit1
																	else:
																		strt1=strt1+" "+jumpit1
																else:
																	if(i4==0):
																		strt1=ibstr
																	else:
																		strt1=strt1+" "+ibstr
																i4+=1
															if(len(self.psplit(mylist[i3],'(',')'))==2):
																mylist[i3]=self.psplit(mylist[i3],'(',')')[0]+'('+strt1+')'#更新后半表项
														#		print(i3,"行跳跃格式替换更新为：",mylist[i3])
															else:
																mylist[i3]=self.psplit(mylist[i3],'(',')')[0]+self.psplit(mylist[i3],'(',')')[1]+'('+strt1+')'#更新后半表项
														#		print(i3,"行跳跃格式替换更新为：",mylist[i3])

														else:#无括号格式时丢弃
															if(f3+1+len(markstr)==len(mylist[i3])):#串末
																strt1=mylist[i3][:f3-1]
															else:#非串末
																strt1=mylist[i3][:f3-1]+mylist[i3][f3+len(markstr):]
															mylist[i3]=strt1#更新表项
														#	print(i3,"行丢弃跳跃标记更新为：",mylist[i3])
														break
											i3+=1
									i2+=1
								if(len(self.psplit(mylist[i],'(',')'))==2):
									mylist[i]=self.psplit(mylist[i],'(',')')[0]+'('+strt+')'#更新前半表项
								#	print(i,"行跳跃格式替换更新为：",mylist[i])
								else:
									mylist[i]=self.psplit(mylist[i],'(',')')[0]+self.psplit(mylist[i],'(',')')[1]+'('+strt+')'#更新前半表项
								#	print(i,"行跳跃格式替换更新为：",mylist[i])
					else:
						print("格式行错误")
				#i+=1

			fh2=TemporaryFile('w+t',encoding='utf-8' )
			for data in mylist:
				fh2.write(data+"\n")
			fh2.seek(0)			
			data=fh2.read()
			fh2.close()
			self.ui.textEdit.setPlainText(data)

# 111 17 (294)
	def DLFmt(self,datastr):#数字括号项位
		#print("进入数字括号项数判定模块")
		mylist=datastr.split('\n')
		lie=mylist[0].split()
		ll=len(lie)
		if(ll>=2):
		#	print("首项转成列表：\t",lie)
			i1=0
			for lstr in lie:#判断数字括号格式项序号
				if(i1<=ll-1):
		#			print("列项末符：",lstr[-1])
					if(lstr[-1]=='0'):
						if(lie[i1+1].isdigit()):
							self.Ignore=i1-1
		#					print("格式项self.Ignore=",self.Ignore)
							break
				i1+=1
# 17 52 (406)
		
	def PFormat (self):#段落格式编辑
		#self.PMark='♢'
		data=self.ui.textEdit.toPlainText()#读取编辑框中内容
		i2=-1
		i3 = 0
		in1 =0#起点行
		in2=0#终点行
		ih=0	
		ss=""
		if(len(data)>0):
			ss=self.model.item(0).index().data()#获取listView的0行内容作为格式前缀
			i1=len(data)
			fh2=TemporaryFile('w+t',encoding='utf-8' )
			for i in range(i1):
				#print(data[i],end="")
				if(data[i]!=self.PMark):#检查非标记字符
					if (data[i]=='\n'):#统计行数
						in2+=1#终点行计数
						ih=0#行字符计数供判断是否行首
						#print("in2=",in2)
					
					else:
						ih+=1
					
				else:#检查是标记字符
					#print("in2=",in2)
					if(ih == 0):#标记为行首时
						in2+=1
						fh2.write(ss+str(in1)+" "+str(in2)+"\n")
						fh2.write(data[i2+1:i]+"\n")
						in1=in2
						in2=0
						i2 = i
					
					else :#标记非行首时
						in2+=1
						fh2.write(ss+str(in1)+" "+str(in2+1)+"\n")
						fh2.write(data[i2+1:i]+"\n\n")
						in1=in2+1
						in2=0
						i2 = i
						ih+=1
			fh2.write(ss+str(in1)+" "+str(in2+1)+"\n")
			fh2.write(data[i2+1:i]+"\n\n")
			fh2.write(ss+str(in2+1)+" "+"0\n")
			fh2.seek(0)
			data=fh2.read()
			fh2.close()
			self.ui.textEdit.setPlainText(data)


# 52 37 (424)
	
	def FFOpen(self):#格式文件操作
		filet=self.FFname
		locFname,filetype = QFileDialog.getOpenFileName(self,
									"选择需编辑或更新的文件",
									self.cwd,# 起始路径 
									"All Files (*);;Setfiles(*.set);;Pthon Files (*.py);;Text Files (*.txt);;向导文件(*.xdf)")# 设置文件扩展名过滤,用双分号间隔

		data=self.ui.textEdit.toPlainText()#看编辑框中有没有内容

		if(len(data)==0):#(not filet.strip()):#编辑框无内容，打开文件，准备编辑
			fh=open(locFname,mode='r+t',encoding='UTF-8')
			if fh:
				fh.seek(0)#注意读取文件时候要将文件指针指向第一个
				data=fh.read()
				fh.close()
				mylist = data.split("\n")
				#print("完成打开文件，准备读取->",locFname,"。文件内容:\n",data,"转列表为：\n",mylist)
				for ss in mylist:
					self.ui.textEdit.append(ss)#v0.76
				self.FFname=locFname
		else:#编辑框有内容，看是否已有此文件，准备覆盖更新
			if(locFname==filet):
				reply = QMessageBox.information(self,"文件覆盖提示", "文件："+filet+" 将被更新覆盖，你确定吗？",QMessageBox.Yes | QMessageBox.No)  
				if(reply==QMessageBox.Yes):
					fh=open(locFname,mode='w+t',encoding='UTF-8')
					fh.write(data)
			else:
				reply = QMessageBox.information(self,"文件保存提示", "文件["+locFname+"]所作修改将被保存，你确定吗？",QMessageBox.Yes | QMessageBox.No)  
				if(reply==QMessageBox.Yes):
					fh=open(locFname,mode='w+t',encoding='UTF-8')
					fh.write(data)
				
			fh.close()
		self.ui.show()
#		self.show()

# 37 77 (477)

	def PopList (self,string,expbnow):#@调出弹出框
#string不带括号,expbnow本页首行在文件中的位置
#调出弹出框格式，如@9~10,意为本页9~10行组成一个弹出框,如@9~10?姓名,则将?后内容‘姓名’作为提示；
#赋值格式，(1 9 0 (@9~10) 0),意为将弹框选择赋给第9行末项为名的变量
		#print("进入弹出框模块")
		Indexpath=os.path.join(os.getcwd(),self.IndexFile)
		CheckedRowNuber=[]
		#stringe=string
		#string=string[1:-1]
		if(string[0]=='@'):#初判格式符合
			if(string.find('~')>0):#再判格式符合
				if(string.find(',')>0):
					linstr=string.split(',')[0][1:]
					colstr=string.split(',')[1]
					if(colstr=='0'):#取行的值作弹出框内容(1 9 0 (@9~10:$?姓名,0) 0)兼容如意
						if(string.find('?')>=0):
							if(string.find(',')>=0):
								pstr=string.split(',')[0].split('?')[-1]
							else:
								pstr=string.split('?')[-1]
						else:
							pstr=""
						if(string.find(':')>0):
							ie=int(string.split(':')[0].split('~')[-1])+expbnow#int(list2[0])#获取终行，顶行编号为0
							ib=int(string.split(':')[0].split('~')[0][1:])+expbnow#int(list2[0])#获取始行
						else:
							ie=int(string.split('~')[-1])+expbnow#int(list2[0])#起行为0行
							ib=int(string.split('~')[0][1:])+expbnow#int(list2[0])
					#	print("行数据弹出框提示：[",pstr,"]，起始行：",ib,"，终止行：",ie)
						locList=[]
						for i in range(ib,ie+1):
							locList.append(self.ViewList[i])
					#	print("\t弹出框初始化前表：",locList)
					else:#取列的值作弹出框内容(1 9 0 (@2,3~6:$?数值) 0)
						if(string.find('?')>=0):
							pstr=colstr.split('?')[-1]
							colstr=colstr.split('?')[0]
						else:
							pstr=""
						if(string.find(':')>0):
							ie=int(colstr.split(':')[0].split('~')[-1])
							ib=int(colstr.split(':')[0].split('~')[0])
						else:
							ie=int(colstr.split('~')[-1])
							ib=int(colstr.split('~')[0])
					#	print("列数据弹出框提示：[",pstr,"]，起始行：",ib,"，终止行：",ie)
						collist=self.ViewList[expbnow+int(linstr)].split()
						locList=[]#self.
						for i in range(ib,ie+1):
							locList.append(collist[i])
					#	print("\t弹出框初始化前表：",locList)

				else:#取行的值作弹出框内容#格式(1 9 0 (@9~10?姓名) 0)
					if(string.find('?')>=0):
						pstr=string.split('?')[-1]
						datastr=string.split('?')[0][1:]
					else:
						pstr=""
						datastr=string[1:]
					ie=int(datastr.split('~')[-1])+expbnow#int(list2[0])#起行为0行
					ib=int(datastr.split('~')[0])+expbnow#int(list2[0])
					#print("简格式无逗号，行弹出框提示：[",pstr,"]，起始行：",ib,"，终止行：",ie)
					locList=[]#self.
					for i in range(ib,ie+1):
						locList.append(self.ViewList[i])#self.
					#print("\t弹出框初始化前表：",locList)#self.
				line,ok = QInputDialog.getItem(self,"选择表项或双击输入",pstr,locList,3,True)
				if ok:
					string=line
				#print("\t处理后字串成为：",string)
			else:
				print("字符串[",string,"]弹出框格式错误，应包含~符")
		else:
			print("字符串[",string,"]弹出框格式错误，首字应为@")
		return string

# 77 47 (526)

	def backward (self):#分页回跳
		#print("\n进入回跳模块backward->")#,end=""
		#self.NOpIdx=[]#清空多选项表
		if self.ExpMode and self.Expbnow>0:#在myfileopen兼容模式中已赋值
			self.EIndex()#显示上页摘录成果

			bnowstr=self.ViewList[self.Expbnow]#获取当前格式行
			#print("\n＝＝＝\n\t＝＝＝回跳当前",self.Expbnow,"行：",bnowstr)
			lie=bnowstr.split()#转成表
			lcol=len(lie)
			if(lcol>self.Ignore+2):#格式检查
			#	print("\t",self.Expbnow,"行初判为格式行；")
				#if(self.Expitem<0):#浏览链接没有选中
				#	print("\t\t","没有选中跳转浏览链接，步进显示下一页：")
				#	self.Expbnow=self.Expfnow
				#	bnowstrb=self.ViewList[self.Expbnow]#获取当前格式行
				#	self.Expfnow=self.Expbnow+int(bnowstrb.split()[self.Ignore+2])+1
				#	self.ExpView(int(self.Expbnow),int(self.Expfnow))
				#else:#浏览链接有选中
				#	print("\t\t","跳转浏览链接选中第",self.Expitem,"项；")
				jumpp=autop=False
				if(self.Listp(bnowstr)):#初检有无浏览跳转链接项
					plist=self.psplit(bnowstr,"(",")")
					liste=plist[-1][1:-1].split()#提取最后一个括号项内容
					if(liste[0].isdigit()):#括号项首项为数字，表示有链接
			#			print("\n\t\t\t浏览链接表为：",liste)
						#le=len(liste)#获取链接表项数
						jumpp=True
					else:
			#			print("\n\t\t\t程序摘引串为：",liste)
						autop=True
				if jumpp:#有浏览跳转链接
					#if(self.Expitem<=le-1 ):#v0.76选中表项合规检查
					itemn=int(liste[0])#提取回跳链接步长
			#		print("\t\t\t\t链接表第",self.Expitem,"项所提取链接步长为：\t",itemn)
				else:
					itemn=0
				self.Expbnow=self.Expbnow-int(lie[self.Ignore+1])-1-itemn
				ljump=self.ViewList[self.Expbnow].split()#获取链接跳转后的格式行表
				if(len(ljump)>=self.Ignore+2 and ljump[self.Ignore+2].isdigit()):
					self.Expfnow=self.Expbnow+int(ljump[self.Ignore+2])+1
					self.ExpView(int(self.Expbnow),int(self.Expfnow))
			else:
				print(self.Expbnow,"行格式错误")
			self.Expitem=-1

# 47 154 (604)
			
	def forward (self):#分页前跳
		#print("\n进入前跳模块forward->")#,end=""
		if self.ExpMode and self.Expfnow< self.lViewList-2:#在myfileopen兼容模式中已赋值
			if(self.Expfnow==0):
				i=self.model.item(0).checkState()#检测顶行是否勾选，决定是人工模式或程序模式
				#print("\n\t检测顶行勾选与否：",i)
				if(i>0):
					self.AutoMode=True#程序模式
					#self.Expitem=0
				#	print("\n\t进入程序摘录模式，AutoMode：",self.AutoMode)
				else:
					self.AutoMode=False#人工模式

			self.EIndex()#显示上页摘录成果

			if not self.AutoMode:#非程序摘录模式下从屏幕获取，程序模式由AutoE赋值
				#self.NOpIdx=[]#清空多选项表
				self.Expitem=-1
				self.Expitem=self.OnOpNumber()
				#print("前跳选中行",self.Expitem)
				#self.Expbnow=self.Expfnow
				bnowstr=self.ViewList[self.Expbnow]#获取当前格式行
				#print("\n＝＝＝\n\t＝＝＝前跳当前",self.Expbnow,"行：",bnowstr)
				lie=bnowstr.split()#转成表
				lcol=len(lie)
				#if(self.Expitem>=0):
				if(lcol>self.Ignore+2):#格式检查
				#	print("\t",self.Expbnow,"行初判为格式行；")
					jumpp=False
					if(self.Expitem>0):#浏览链接有选中
				#		print("\t\t","跳转浏览链接选中第",self.Expitem,"项；")
						#jumpp=autop=False
						if(self.Listp(bnowstr)):#初步检查有无浏览跳转链接项
							plist=self.psplit(bnowstr,"(",")")
							liste=plist[-1][1:-1].split()#提取最后一个括号项内容
							if(liste[0].isdigit()):#括号项首项为数字，表示有链接
				#				print("\n\t\t\t浏览链接表为：",liste)
								le=len(liste)#获取链接表项数
								jumpp=True
								#if(len(plist)==3):#包括了浏览链接和程序表
									#autop=True
									#提取倒数第2个括号项内容为程序表
									#stra=self.psplit(plist[-2][1:-1])#[1:]
									#print("\n\t\t\t程序摘引串为：",stra)
							#else:
								#autop=True
								#stra=self.psplit(plist[-1][1:-1])#[1:]#提取最后括号项内容为程序表
								#print("\n\t\t\t程序摘引串为：",stra)
						if jumpp:#有浏览跳转链接
							if(self.Expitem<=le-1 ):#v0.76选中表项合规检查
								itemn=int(liste[self.Expitem])#提取链接步长
					#			print("\t\t\t\t链接表第",self.Expitem,"项所提取链接步长为：",itemn)
								self.Expbnow=self.Expbnow+int(lie[self.Ignore+2])+1+itemn
								ljump=self.ViewList[self.Expbnow].split()#获取链接跳转后的格式行表
								if(len(ljump)>=self.Ignore+2 and ljump[self.Ignore+2].isdigit()):
									self.Expfnow=self.Expbnow+int(ljump[self.Ignore+2])+1
									self.ExpView(int(self.Expbnow),int(self.Expfnow))#***
					if(not jumpp):#浏览链接没有选中向前项self.Expitem<=0 or 
					#	print("\t\t","没有选中跳转浏览链接，步进显示下一页：")
						self.Expbnow=self.Expfnow
						bnowstrb=self.ViewList[self.Expbnow]#获取当前格式行
						self.Expfnow=self.Expbnow+int(bnowstrb.split()[self.Ignore+2])+1
						self.ExpView(int(self.Expbnow),int(self.Expfnow))#***
						#if autop:
						#	print("发现程序摘引串")
						#	for astr in stra:
						#		self.AutoE(astr[1:-1])
			else:#程序摘录模式
				bnowstr=self.ViewList[self.Expbnow]#获取当前格式行
				#print("\n＝＝＝\n\t＝＝＝autofore当前",self.Expbnow,"行：",bnowstr)
				lie=bnowstr.split()#转成表
				lcol=len(lie)
				jumpp=False
				autop=False
				if(lcol>self.Ignore+2):#格式检查
				#	print("\t",self.Expbnow,"行autofore初判为格式行；选中项：",self.Expitem)
					#if(self.Expitem<0):#浏览链接没有选中则auto退出
					#	print("\t\t","没有选中跳转浏览链接，步进显示下一页：")
					#	self.Expbnow=self.Expfnow
					#	bnowstrb=self.ViewList[self.Expbnow]#获取当前格式行
					#	self.Expfnow=self.Expbnow+int(bnowstrb.split()[self.Ignore+2])+1
					#	self.ExpView(int(self.Expbnow),int(self.Expfnow))#***

					if(self.Listp(bnowstr)):#初步检查有无浏览跳转链接项
						plist=self.psplit(bnowstr,"(",")")
						liste=plist[-1][1:-1].split()#提取最后一个括号项内容
						if(liste[0].isdigit()):#括号项首项为数字，表示有链接
				#			print("\n\t\t\tautofoe浏览链接表为：",liste)
							le=len(liste)#获取链接表项数
							jumpp=True
							if(len(plist)==3):#包括了浏览链接和程序表
								autop=True
								#提取倒数第2个括号项内容为程序表
								stra=plist[-2][1:-1]#self.psplit()[1:]
				#				print("\n\t\t\tautofore程序表共3项，摘引串为：",stra)
						else:
							autop=True
							#提取最后括号项内容为程序表
							stra=plist[-1][1:-1]#self.psplit()[1:]
				#			print("\n\t\t\tautofore提取末项程序表摘引串为：",stra)

					if(self.Expitem>=0):#浏览链接有选中
				#		print("\t\tautofore跳转浏览链接选中第",self.Expitem,"项；")
						if jumpp:#有浏览跳转链接
							if(self.Expitem<=le-1 ):#v0.76选中表项合规检查
								itemn=int(liste[self.Expitem])#提取链接步长
				#				print("\t\t\t\tautofore链接表第",self.Expitem,"项步长为：",itemn)
								self.Expbnow=self.Expbnow+int(lie[self.Ignore+2])+1+itemn
								ljump=self.ViewList[self.Expbnow].split()#获取链接跳转后的格式行表
								if(len(ljump)>=self.Ignore+2 and ljump[self.Ignore+2].isdigit()):
									self.Expfnow=self.Expbnow+int(ljump[self.Ignore+2])+1
									#self.Expitem=-1	
									self.ExpView(int(self.Expbnow),int(self.Expfnow))#***

									bnowstr=self.ViewList[self.Expbnow]#获取当前格式行
									if(self.Listp(bnowstr)):#初步检查有无浏览跳转链接项
										plist=self.psplit(bnowstr,"(",")")
										liste=plist[-1][1:-1].split()#提取最后一个括号项内容
										if(liste[0].isdigit()):#括号项首项为数字，表示有链接
				#							print("\n\t\t\tautofore前跳后浏览链接表为：",liste)
											le=len(liste)#获取链接表项数
											jumpp=True
										else:
											jumpp=False
										if(len(plist)==3):#包括了浏览链接和程序表
											autop=True
											#提取倒数第2个括号项内容为程序表
											stra=plist[-2][1:-1]#self.psplit()[1:]
				#							print("\n\t\t\tautofore前跳后程序表共3项，摘引串为：",stra)
										else:
											autop=False											
									else:
										autop=True
										#提取最后括号项内容为程序表
										stra=plist[-1][1:-1]#self.psplit()[1:]
				#						print("\n\t\t\tautofore前跳后提取末项程序表摘引串为：",stra)

					if autop:
				#		print("\n\t---> autofore执行程序摘引串")
						self.AutoE(stra)
					else:#浏览链接没有选中
				#		print("\t\tautofore没有选中跳转浏览链接、接引串，步进显示下一页：")
						self.Expbnow=self.Expfnow
						bnowstrb=self.ViewList[self.Expbnow]#获取当前格式行
						self.Expfnow=self.Expbnow+int(bnowstrb.split()[self.Ignore+2])+1
						self.ExpView(int(self.Expbnow),int(self.Expfnow))#***
						#else:
						#	print(self.Expbnow,"auto行无跳转链接")

					#if not jumpp:	
				else:
					print(self.Expbnow,"autofore格式行有误")

# 154 51 (652)

	def ExpView (self,top,bot):#分页显示
	#显示self.ViewList第top行到第bot行
		#print("\n进入专用格式显示模块ExpView->")
		bnowstr=self.ViewList[top]#获取当前格式行
		#print("顶",top,"行内容：",bnowstr)
		lie=bnowstr.split()#转成表
		#print("转成表",lie)
		lcol=len(lie)
		lp0=le=0
		jumpp=False
		autop=False
		if(self.Listp(bnowstr)):#检查有无浏览链接项
			plist=self.psplit(bnowstr,"(",")")
			lp0=len(plist[0].split())#去除括号项后的列表项数
			liste=plist[-1][1:-1].split()#提取最后一个括号项内容
			le=len(liste)#获取链接表项数

		i1=0
		for i in range(top,bot):
			if(i==top):#格式行
				#print(" 格式行",i,end="")
				if self.FormatShow:
					item = QStandardItem(self.ViewList[i])
				else:
					item = QStandardItem("")
				
				item.setCheckState(False)
				item.setCheckable(True)
				self.model.clear()
				self.model.appendRow(item)
				if(le>0):#有链接表时，显示小手图标
					if((i1<=le-1) and liste[i1]!='0'):
						self.model.item(i1).setIcon(QIcon("click.png"))
			else:#非格式行
				item = QStandardItem(self.ViewList[i])
				item.setCheckState(False)
				item.setCheckable(True)
				self.model.appendRow(item)
				if(le>0):#有链接表时，显示小手图标
					if((i1<=le-1) and liste[i1]!='0'):
						self.model.item(i1).setIcon(QIcon("click.png"))
				if self.ViewList[i].strip(): #v0.56插入图片☯xx.jpg
					if (self.ViewList[i][0]=='☯') :
						picname=os.path.join("src",self.ViewList[i][1:]+".jpg")
						self.model.item(i1).setIcon(QIcon(picname))
						self.ui.listView.setIconSize(QSize(self.PicSize,self.PicSize))
			i1+=1
		self.ui.listView.setModel(self.model)
		self.ui.show()

# 51 200 (807)

	def AutoE (self,string):#程序摘录
		#print("\n进入自动摘录模块AutoE,操作字串：\n",string)#string为去掉括号的字符串
		Indexpath=os.path.join(os.getcwd(),self.IndexFile)
		#if(self.Expbnow==0):#v0.74
		#	f=open(Indexpath,mode='w+t',encoding='UTF-8')
		#	f.write(self.fileName_choose+"\n")
		#	print("self.Expbnow=",self.Expbnow,"覆盖模式")
		#else:
		f=open(Indexpath,mode='a+t',encoding='UTF-8')
		#print("self.Expbnow=",self.Expbnow,"追加模式")
		if(len(string)==1):
			if f:
				i1=1
				for i in range(self.Expbnow,self.Expfnow):
					f.write(str(self.Expbnow)+" "+str(i1)+" "+"\n")
					i1+=1

				f.write("\n")#方便undo操作
			#f.close()
			
		else:
			AElist=self.psplit(string,"(",")")
			#print("\t自动摘录",self.Expbnow," 行转化操作列表：",AElist)
			#print("=================",self.Expbnow,"=================")
			la=len(AElist)
			for i in range(1,la):
				stril=AElist[i][1:-1].split()
				lsl=len(stril)
				if(lsl==1):
			#		print("\t\t单项程序摘录：",AElist[i])
					if f:
						if(stril.isdigit()):
							if(int(string)<self.Expfnow-self.Expbnow):
								f.write(str(self.Expbnow)+" "+string+" "+"\n")
						else:	
							i1=1
							for i in range(self.Expfnow-self.Expbnow-1):
								f.write(str(self.Expbnow)+" "+str(i1)+" "+"\n")
								i1+=1

						f.write("\n")#方便undo操作
					#f.close()
				elif(lsl==2):
			#		print("\t\t双项程序摘录表AElist[",i,"]：",AElist[i])
					if(stril[0]=="0"):#后台程序浏览模式
						if f:
							f.close()
			#			print("\t\t两项式",AElist[i],"程序摘录->")
						if(str(self.Expbnow) in self.Expdic):#检查本列表项有没有运行过
							i1=self.Expdic[str(self.Expbnow)]#运行过的提取该行序号
							if(i>=i1):
			#					print("\n\t\t\t\t=>已历自动浏览行：",self.Expbnow,"运项序号 ",i1," 当前循环i=",i)
								self.Expdic[str(self.Expbnow)]=i
								if(i==la):
			#						print(self.Expbnow,"行自动摘录表共",la,"项，已运行至",i,"项，该行从字典中删除。")
									self.Expdic.pop(str(self.Expbnow))#各项运行后，删除字典该行							
								if(stril[1]=="0"):
									self.backward()
								elif(stril[1].isdigit()):
									self.Expitem=int(stril[1])
			#						print("\t\t\t\t自动浏览准备进入forward模块,链接项：",self.Expitem)
									self.forward()
								else:
									print(string," 中 ",AElist[i]," 第二项应为数字，请纠正：",stril[1])
						else:
							self.Expdic[str(self.Expbnow)]=i							
			#				print("\n\t\t\t\t->发现自动浏览行：",self.Expbnow,"初次运行项序号i=",i)
							if(stril[1]=="0"):
							#	Branch=1
							#	break
								self.backward()
							elif(stril[1].isdigit()):
								self.Expitem=int(stril[1])
			#					print("\t\t\t\t自动浏览准备进入forward模块,链接项：",self.Expitem)
							#	Branch=2
							#	break
							#	f.close()
								self.forward()
							else:
								print(string," 中 ",AElist[i]," 第二项应为数字，请纠正：",stril[1])
					else:
						toi=int(stril[1])
						fri=int(stril[1])-int(stril[0])
			#			print("\t\t两项式",AElist[i],"程序摘录，从",fri,"到",toi)
						if f:
							i1=fri
							for i in range(int(stril[0])):
								f.write(str(self.Expbnow)+" "+str(i1)+" "+"\n")
								i1+=1
							f.write("\n")#方便undo操作
						#f.close()
				elif(lsl==3):
					toi=int(stril[1])
					fri=int(stril[1])-int(stril[0])+1
			#		print("\t\t三项程序摘录，从",fri,"到",toi)
					Indexpath=os.path.join(os.getcwd(),self.IndexFile)
					if(self.Expbnow==0):#v0.74
						f=open(Indexpath,mode='w+t',encoding='UTF-8')
						f.write(self.fileName_choose+"\n")
					else:
						f=open(Indexpath,mode='a+t',encoding='UTF-8')
					if f:
						i1=fri
						for i in range(int(stril[0])):
							if(stril[2]=='0'):
								f.write(str(self.Expbnow)+" "+str(i1)+"\n")
								#print("换行")
							else:
								f.write(str(self.Expbnow)+" "+str(i1)+" \"⌇\"\n")
								#print("不换行")
							i1+=1
						f.write("\n")#方便undo操作
					#f.close()
				elif(lsl==4):
					toi=int(stril[1])
					fri=int(stril[1])-int(stril[0])+1
					if(stril[3].isdigit()):#第四项为数字时，调出该行字串
						string4=self.ViewList[self.Expbnow+int(stril[3])]
						if(self.Listp(string4)):
							#strt=self.psplit(string4,'(',')')[0]
							#print(string4,"括号内容：",strt,end="")
							string4=self.AltStr(string4,0,self.Expbnow)
					#		print("经Altstr转化为串：",string4)
					else:
						string4=stril[3]
			#		print("\t\t四项程序摘录，从",fri,"到",toi,"第4项字串[",string4,"]")
					if f:
						i1=fri
						for i in range(int(stril[0])):
							if(stril[2]=='0'):
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+string4+"\"\n")
							else:
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+string4+"⌇\"\n")
							i1+=1
						f.write("\n")#方便undo操作
					#f.close()
				elif(lsl==5):
					toi=int(stril[1])
					fri=int(stril[1])-int(stril[0])+1
					i3=int(stril[2])
					string2=self.ViewList[self.Expbnow+toi]#-1
					lstring2=string2.split()
					if(len(lstring2)>=2):
						laststr2=string2.split()[-1]#如果目标行为空格多项，取最后一项为赋值变量
					else:
						laststr2=string2#如果目标行为空格单项，整取为赋值变量
					if(stril[3].isdigit()):#第四项为数字时，调出该行字串
						string4=self.ViewList[self.Expbnow+int(stril[3])]
					else:
						string4=stril[3]#第四项非数字时，本身作为字串
			#		print("\t\t五项程序摘录，从",fri,"到",toi,"第2项末串[",laststr2,"]赋值第4项字串[",string4,"]")
#					self.AltStr(string4,0,1)
					if f:
						i1=fri
						for i in range(int(stril[0])-1):
							f.write(str(self.Expbnow)+" "+str(i1)+" "+"\n")
							i1+=1
						if(i3>0):
							if(self.Listp(string4)):
								#strt=self.psplit(string4,'(',')')[0]
								#print(string4,"括号内容：",strt,end="")
								strt=self.AltStr(string4,0,self.Expbnow)
					#			print("经弹出框输入转化为串：",strt)
								if(int(stril[4])>0):#第五项>0，不赋值,但计算
									f.write(str(self.Expbnow)+" "+str(i1)+" \""+strt+"⌇\"\n")
								elif (int(stril[4])<0):#第五项<0，赋值
									f.write(str(self.Expbnow)+" "+str(i1)+" "+laststr2+" \""+strt+"⌇\"\n")							
								elif (int(stril[4])==0):#else:#第五项=0，赋值
									f.write(str(self.Expbnow)+" "+str(i1)+" "+laststr2+" \""+strt+"⌇\"\n")
							else:
								if(int(stril[4])>0):#第五项>0，不赋值,但计算
									f.write(str(self.Expbnow)+" "+str(i1)+" "+" \""+string4+"⌇\"\n")
								elif (int(stril[4])<0):#第五项<0，赋值
									f.write(str(self.Expbnow)+" "+str(i1)+" "+laststr2+" \""+string4+"⌇\"\n")							
								elif (int(stril[4])==0):#else:#第五项=0，赋值
									f.write(str(self.Expbnow)+" "+str(i1)+" "+laststr2+" \""+string4+"⌇\"\n")

						else:
							if(self.Listp(string4)):
								#if(string4[1]=='@'):
								strt=self.AltStr(string4,0,self.Expbnow)
						#		print(string4,"经弹出框输入转化为串：",strt)
								if(int(stril[4])>0):#第五项>0，不赋值,但计算
									f.write(str(self.Expbnow)+" "+str(i1)+" \""+strt+"\"\n")
								elif (int(stril[4])<0):#第五项<0，赋值
									f.write(str(self.Expbnow)+" "+str(i1)+" "+laststr2+" \""+strt+"\"\n")							
								elif (int(stril[4])==0):#else:#第五项=0，赋值
									f.write(str(self.Expbnow)+" "+str(i1)+" "+laststr2+" \""+strt+"\"\n")
							else:
								if(int(stril[4])>0):#第五项>0，不赋值,但计算
									f.write(str(self.Expbnow)+" "+str(i1)+" "+" \""+string4+"\"\n")
								elif (int(stril[4])<0):#第五项<0，赋值
									f.write(str(self.Expbnow)+" "+str(i1)+" "+laststr2+" \""+string4+"\"\n")							
								elif (int(stril[4])==0):#else:#第五项=0，赋值
									f.write(str(self.Expbnow)+" "+str(i1)+" "+laststr2+" \""+string4+"\"\n")
						f.write("\n")#方便undo操作
		f.close()
		self.EIDisp()

# 200 36 (859)

	def psplit (self,string,p1,p2):#配对分割字串
	#一对p1,p2字符分割字串string
		i=ib=0
		ls=len(string)
		#print("进入psplit,字串",string,",串长",ls)
		res=[]
		s=""
		unlock=True
		for i in range(ls):
			#print("i=",i,"unlock=",unlock,"ib=",ib)
			if(unlock):
				if(string[i]==p1):#"("
					#print("发现左边界 ",p1,end="")#括号
					if(s.strip()):
						res.append(s)
					#print(" ,左边界前字串：",s)#括号
					unlock=False
					s=p1 #"("
					ib=1
				else:
					s=s+string[i]
			else:
				s=s+string[i]
				if(string[i]==p1):#"("
					ib+=1
				elif(string[i]==p2):#")"
					ib-=1
				if(ib==0 or i==ls-1):
					res.append(s)
					#print("双界内字串：",s)#括号
					unlock=True
					s=""
				#print(s)
		return res

# 36 28 (1097)

	def OnOpNumber (self):#记录点选表项
		#print("\n进入操作行定位OnOpNumber\n")
		ic=self.ui.listView.currentIndex()
		i1=-1
		i=0
		for i in range(self.model.rowCount()):
			i0=self.model.item(i).index()
			if(ic==i0):
				#if i not in self.NOpIdx:
				#	self.NOpIdx.append(i)
				#	print("正在操作第",i,"行，状态选中，添加到列表self.NOpIdx->",self.NOpIdx)
				#else:
					#llast=self.NOpIdx[-1]
					#print("正在操作第",i,"行，列表最后项->",llast)
				#	if(i!=self.NOpIdx[-1]):
				#		self.NOpIdx.remove(i)
				#		print("正在操作第",i,"行……非列表最后项，取消选择，从列表删除->",self.NOpIdx)
				i1=i
				break

			i = i + 1
		#if(len(self.NOpIdx)>0):
		#	i1=int(self.NOpIdx[-1])
		#else:
		#	i1=-1
		return i1

# 28 48 (1097)

	def EIndex (self):#索引摘录
		#print("\n进入摘引　EIndex")
		CheckedRowNuber=[]
		n=self.model.rowCount()
		for i in range(0,n):#(1,n):#v0.86
			if self.model.item(i).checkState():
				#print("共",n,"行，检索第",i,"行已勾选")
				if(i not in CheckedRowNuber ):#0.33
					CheckedRowNuber.append(i)
		if(len(CheckedRowNuber)>0):
			#print("EIndex中self.Expbnow=",self.Expbnow,"行，选中行数：",len(CheckedRowNuber))
			Indexpath=os.path.join(os.getcwd(),self.IndexFile)
			if(self.Expbnow==0):#v0.74
				f=open(Indexpath,mode='w+t',encoding='UTF-8')
				f.write(self.fileName_choose+"\n")
			else:
				f=open(Indexpath,mode='a+t',encoding='UTF-8')
			if f:
				for i in CheckedRowNuber:
					fi=self.ViewList[self.Expbnow+i]#获取原文件中i行内容
					si=self.model.item(i).index().data()#获取listView的i行内容
					#if(i==i1):
					if(self.Expfnow==0):
						#print("self.Expforestep=",self.Expforestep)						
						Is1=str(i-1)
					else:
						#print("self.Expforestep=",self.Expforestep)						
						Is1=str(i)
					#if(i in self.NOpIdx):
						#print("勾中行",i,"同时为点中行")
					#if(si[-1]=='⌇'):
					#	if (ss.strip()):
					#		f.write(str(self.Expbnow)+" "+Is1+" \""+ss+"⌇\"\n")
					#	else:
					if(si==fi):
						f.write(str(self.Expbnow)+" "+Is1+"\n")
					else:
						#print("勾中行",i,"不是点中行")
						f.write(str(self.Expbnow)+" 0 "+"\""+si+"\"\n")
					#	if (ss.strip()):
					#		f.write(str(self.Expbnow)+" "+Is1+" \""+ss+"\"\n")
					#	else:
					#		f.write(str(self.Expbnow)+" "+Is1+" \""+"\"\n")
				f.write("\n")#方便undo操作
			f.close()
			self.EIDisp()

# 48 26 (1144)

	def Undo (self):#撤消一步
		#print("\n进入撤消Undo")
		Indexpath=os.path.join(os.getcwd(),self.IndexFile)
		CheckedRowNuber=[]
		f=open(Indexpath,mode='r+t',encoding='UTF-8')
		if f:
			f.seek(0)#注意读取文件时候要将文件指针指向第一个
			s=f.read()
			mylist = s.split("\n")#含完整的文件路径
			lm=len(mylist)
			f.close()
			ic=0
			for i in range(lm-2):
				s=mylist[i]	
				if not s.strip():
					ic=i
			#print("总行数",lm,"最后的空行为:",ic)
					
			f=open(Indexpath,mode='w+t',encoding='UTF-8')
			for i in range(ic):
				s=mylist[i]	
				f.write(s+"\n")
			f.close()
			self.EIDisp()

# 26 90 (1175)

	def EIDisp (self):#索引摘录显示
		global DlgStr
		#print("\n进入摘引显示　EIDisp")
		Indexpath=os.path.join(os.getcwd(),self.IndexFile)
		CheckedRowNuber=[]
		f=open(Indexpath,mode='r+t',encoding='UTF-8')
		#print("打开摘引文件：",Indexpath)
		if f:
			f.seek(0)#注意读取文件时候要将文件指针指向第一个
			s=f.read()
			mylist = s.split("\n")#含完整的文件路径
			lm=len(mylist)
			f.close()
			f1=open(self.fileName_choose,mode='r+t',encoding='UTF-8')
			s=f1.read()
			f1.close()
			#print("打开文件：",self.fileName_choose)
			mylist1 = s.split("\n")#含完整的文件路径
			self.ui.textEdit.clear()
			linefeed=True#
			ss=""
			for i in range(1,lm):
				s=mylist[i]#从摘引文件成表中读项
				if(s.strip()):
					list2=s.split()
					l2=len(list2)#空格项数
					if(i<lm-1):
						#print("摘引文件第",i,"行:",s)
						i1=int(list2[0])+int(list2[1])
						if(l2>=3):#有附加字串self.Ignore+
							plist2=self.psplit(s,"\"","\"")
							#print("\t三以上项字串： ",s,"配对分割表：",plist2)
							if(len(plist2)>=2):#字串格式为最后一项，有内容时项数为2
								sse=plist2[1][1:-1]#将字串剔除引号
							#	print("第",i,"行摘引：",s,"化整后：",int(list2[0])," ",int(list2[1]),"附加输入：",sse)
							#	if(self.Listp(sse)):
							#		self.PopList(sse,int(list2[0]))
							#		sse=DlgStr
							else:
								sse=""
						if(l2>=3):
							#ss = ss+mylist1[i1]+sse
							if(list2[1]=='0'):#第二数为0时，特别处理
								ss = sse								
							else:#第二数非0时，提取原文件该行内容，附加字串
								ss = mylist1[i1]+sse
							#print("\t提取",list2[0],"+",list2[1],"行，附加字串[",sse,"]后字串->",ss)
							#self.ui.textEdit.moveCursor(QTextCursor.End)
							#self.ui.textEdit.insertPlainText(ss)
						else:#两项时只提取原文件该行内容
							#ss = ss+mylist1[i1]
							ss = mylist1[i1]
							#print("\t提取",i1,"行:",ss)
							#self.ui.textEdit.append(ss)
							#self.ui.textEdit.moveCursor(QTextCursor.End)
							#self.ui.textEdit.insertPlainText(ss+"\n")
						#if(ss.strip()):
						#	if(ss[-1]=='⌇'):
						#		linefeed=False
						#	else:
						#		linefeed=True#
						if linefeed:#有回车符时
							if(ss.strip()):
								if(ss[-1]=='⌇'):
							#		print("\n\t",i1,"行末有⌇",ss,"去除成为：",ss[:-1])
									self.ui.textEdit.append(ss[:-1])#v0.76
								else:
									self.ui.textEdit.append(ss)#v0.76
						else:#无回车符时
							if(ss.strip()):
								if(ss[-1]=='⌇'):
							#		print("\n\t",i1,"行末有⌇",ss,"去除成为：",ss[:-1])
									self.ui.textEdit.moveCursor(QTextCursor.End)
									self.ui.textEdit.insertPlainText(ss[:-1])
								else:
									self.ui.textEdit.moveCursor(QTextCursor.End)
									self.ui.textEdit.insertPlainText(ss)#[:-1])
							if ss.strip(): #v0.55插入图片☯xx.jpg
								if (ss[0]=='☯') :
									picname=os.path.join("src",ss[1:]+".jpg")#ss[1:]+'.jpg'
									self.ui.textEdit.append('<img src="file://'+os.path.join(os.getcwd(),"src",picname)+'" width="600">')
						if(ss.strip()):
							if(ss[-1]=='⌇'):
								linefeed=False
							else:
								linefeed=True#
							ss=""
		#print("退出摘引显示　EIDisp")

# 90 14 (1202)

	def Listp (self,localstr):#判断括号成对
		i2=i3=0
		n1=len(localstr)
		for i1 in range(n1):
			if(localstr[i1]=='('):
				i2+=1
			elif(localstr[i1]==')'):
				i3+=1
		if((i2 == i3) and (i2>0)):
			return True
		else:
			return False

# 14 164 (1311)

	def myfileopen (self,slecstr,n): #文件打开准备
		#print("\n进入myfileopen->",n,"新开文件名： ",slecstr)
		ExpMode=False
		mypath=os.path.join(os.getcwd(),self.OftenFiles)
		fh=False
		model=QStandardItemModel()
		if(slecstr.strip()):		
			fh=open(slecstr,mode='a+t',encoding='UTF-8')
			#if not fh:
			#	fh=open(mypath,mode='r',encoding='UTF-8')
		else:
			if(n==2):
				if(not self.fileName_choose.strip()):
					#print("首次打开……")
					self.fileName_choose=mypath#v0.60-
					picname='微信打赏.jpg'
					item = QStandardItem("欢迎随宜打赏鼓励……软件源代码公开，服务收费是自由软件的通行模式，支持有偿服务请QQ625052847，参考标准$5/分钟。"+self.promptstr1)
					#item.setCheckState(False)
					#item.setCheckable(True)
					model.clear()
					model.appendRow(item)						
					model.item(0).setIcon(QIcon(os.path.join(os.getcwd(),"src",picname)))
					self.ui.listView_2.setIconSize(QSize(300,300))
			
		if fh:
			fh.seek(0)
			data=fh.read()
			#print("完成打开文件->",slecstr)
			#print("<-。文件内容：\n",data)
			fh.close()
			
			self.DLFmt(data)#v0.89

			mylist = data.split("\n")
			model = QStandardItemModel()
			#print("self.fileName_choose=",self.fileName_choose," ? mypath=",mypath)
			lie=mylist[0].split()
			lcol=len(lie)
			if(lcol>=2):
				#print("首项转成列表：\t",lie)
				#i1=0
				#ll=len(lie)
				#for lstr in lie:#判断程序调整格式项序号
				#	if(i1<=ll-1):
				#		if(lstr[-1]=='0'):
				#			if(lie[i1+1].isdigit()):
				#				self.Ignore=i1-1
				#				print("格式项self.Ignore=",self.Ignore)
				#				break
				#	i1+=1
				if(lie[self.Ignore+1][-1]=='0' and lie[self.Ignore+2].isdigit()):
					self.ExpMode=True
					self.lViewList=len(mylist)
					self.ViewList=mylist
					self.Expbackstep=0
					self.Expforestep=int(lie[self.Ignore+2])
					self.Expbnow=0#V0.75
					self.Expfnow=0
					#print(slecstr,"判断为专用模式文件！")
			#		print("文件初打开，回跳位置",self.Expbnow,"回跳步长：",self.Expbackstep,"前跳位置",self.Expfnow,"前跳步长：",self.Expforestep)		
				else:
					self.ExpMode=False
					#print(slecstr,"判断为非专用模式文件！")
			else:
				self.ExpMode=False
				#print(slecstr,"为非专用模式文件！")

			i=0
			i1=0#格式行
			if not self.ExpMode:#非专用文件
				for task in mylist:
					#print("i=",i,",i1=",i1)
					if(self.fileName_choose==mypath):#当打开oftenfiles.set文件时
						lstr=os.path.split(task)[1]#忽略路径，只取文件名，成文库目录
						item = QStandardItem(lstr)
						item.setCheckState(False)
						item.setCheckable(True)
					else:	
						item = QStandardItem(task)
						item.setCheckState(False)
						item.setCheckable(True)
					if i == 0 :
						item1 = QStandardItem(self.prompstr)
						item1.setCheckState(False)
						item1.setCheckable(True)
						model.clear()
						model.appendRow(item1)
						model.appendRow(item)
					else:
						model.appendRow(item)
						if task.strip(): #v0.56插入图片☯xx.jpg
							if (task[0]=='☯') :
								picname=os.path.join("src",task[1:]+".jpg")
								model.item(i+1).setIcon(QIcon(picname))
								if(n==1):
									self.ui.listView.setIconSize(QSize(self.PicSize,self.PicSize))
								if(n==2):
									self.ui.listView_2.setIconSize(QSize(self.PicSize,self.PicSize))
					i=i+1
			else:#Expert mode专用文件
				for task in mylist:
					if(self.fileName_choose==mypath):#打开oftenfiles.set设置文件时
						lstr=os.path.split(task)[1]#取文件的名
						item = QStandardItem(lstr)
						item.setCheckState(False)
						item.setCheckable(True)
					else:	
						if(i==i1):#v0.73打开其它文件时，格式空置显示
							#print("i=",i,",i1=",i1)
							#item = QStandardItem("")
							if self.FormatShow:
								item = QStandardItem(self.ViewList[i])
							else:
								item = QStandardItem("")

						else:
							item = QStandardItem(task)
						item.setCheckState(False)
						item.setCheckable(True)

					if i == 0 :#首页首项显示提示
						item1 = QStandardItem(self.prompstr)
						item1.setCheckState(False)
						item1.setCheckable(True)
						model.clear()
						model.appendRow(item1)#兼容模式首页多此一行
	
						if(i==i1):#v0.73格式行
							if(i<self.lViewList-2):
								lie=mylist[i1].split()
								if(self.Ignore+2<len(lie)):
									i1=i+int(lie[self.Ignore+2])+1#定位下一个格式行
									#print("\t兼容首页当前格式行i=",i,",下一个格式行i1=",i1)
						model.appendRow(item)
					else:#i!=0兼容模式非首页首项
						if(i==i1):#v0.73
							if(i<self.lViewList-2):
								lie=mylist[i1].split()
								if(self.Ignore+2<len(lie)):
									i1=i+int(lie[self.Ignore+2])+1
									#print("\t当前格式行i=",i,",下一个格式行i1=",i1)
						model.appendRow(item)
						if task.strip(): #v0.56插入图片☯xx.jpg
							if (task[0]=='☯') :
								picname=os.path.join("src",task[1:]+".jpg")
								model.item(i+1).setIcon(QIcon(picname))
								if(n==1):
									self.ui.listView.setIconSize(QSize(self.PicSize,self.PicSize))
								if(n==2):
									self.ui.listView_2.setIconSize(QSize(self.PicSize,self.PicSize))
					i=i+1

		if(model):
			if(n==1):
				self.model=model
				self.ui.listView.setModel(self.model)
			elif(n==2):
				self.model2=model
				self.ui.listView_2.setModel(self.model2)
		#self.NOpIdx=[]#v0.76清空多选项表
		self.ui.show()
#			self.show()

# 164 19 (1345)

	def SearchRun1(self):#文件及列表搜索响应
		#print("进入SearchRun1搜索->")
		FullStep=False
		i=self.model.item(0).checkState()
		if(i>0):
			FullStep=True
		ss=self.model.item(0).index().data()#获取listView的0行内容***
		localpath=os.path.join(os.getcwd(),self.OftenFiles)
		#print("localpath=",localpath,"\nfileName_choose=",self.fileName_choose,"=?\t搜索关键字",ss)
		if(localpath==self.fileName_choose):
			if FullStep:
				self.SearchFile(localpath,ss)
			else:
				self.SearchRow(1,FullStep,ss)
		else:
			self.SearchRow(1,FullStep,ss)
		self.prompstr=ss#v0.54

# 19 12 (1510)

	def SearchRun2(self):#列表搜索响应
		#print("进入SearchRun2搜索->")
		FullStep=False
		i=self.model2.item(0).checkState()
		if(i>0):
			FullStep=True
		ss=self.model2.item(0).index().data()
		#print("\t搜索关键字ss=",ss,"\t连续搜索：",FullStep)

		self.SearchRow(2,FullStep,ss)

# 12 237 (1511)

	def SearchFile (self,lpath,ss):#文件搜索
		bratio=0.05 #0.49空行比，决定搜索结果是否扩展至空行
		Fruitpath=os.path.join(os.getcwd(),self.FruitFile)
		#print("进入SearchFile搜索->",ss,"\t当前打开文件：",self.fileName_choose)
		if((ss[0]=='`') or (ss[0]=='｀')) :
			Ltdp=True#v0.54
			ss=ss[1:]	
#			print("首字为`或｀进入有界搜索，关键字->",ss)
		else:
			Ltdp=False#v0.54
		sslist2=[]
#		v0.54由空格及'、'表解构并行搜索项数
		sslistt=[]
		sslist1=[]
		sym=[' ','、']
		sslistt.extend(ss.split(sym[0]))
		i=0
		li=len(sslistt)
		for sp in  sym[1:]:
			for i in range(len(sslistt)):
				ss1=sslistt[i]
				if(ss1.find(sp)>=0):
					sslist1.extend(ss1.split(sp))
				else:
					if ss1.strip():
						sslist1.append(ss1)
				if(i==li-1):
					sslistt=sslist1
					li=len(sslistt)
					sslist1=[]
#				print("i=",i,"\t列表变化：",sslist1)
		sslist1=sslistt
#		print("\t关键字'、'拆分后列表结果：",sslist1)

		lenl1=len(sslist1)
		for i1 in range(lenl1):
			if(sslist1[i1].find(",")>=0):
#				print("搜索关键字中含','")
				sslist2=sslist1[i1].split(",")#","解构多条件搜索	
#				print("\n多条件关键字集sslist2=",sslist2)
			elif(sslist1[i1].find("，")>=0):
#				print("搜索关键字中含中文'，'")
				sslist2=sslist1[i1].split("，")#中文"，"解构多条件搜索	
#				print("\n多条件关键字集sslist2=",sslist2)
		lenl2=len(sslist2)
		fh1=open(lpath,mode='r+t',encoding='UTF-8')
		fh2=open(Fruitpath,mode='a+t',encoding='UTF-8')
#		fh2=TemporaryFile('w+t',encoding='utf-8' )
		if fh2:
			fh2.close
			fh2=open(Fruitpath,mode='w+t',encoding='UTF-8')
			fh2.write("搜索关键字：\t"+ss+"\n")

		if fh1:
			fh1.seek(0)#文件指针指向首位
			data=fh1.read()
			mylist = data.split("\n")#含完整的文件路径
		fh1.close()

#		if(self.PosFound==-1):
#			i=1
#		else:
#			i=self.PosFound
#		print("\n\ti=",i,"行发现,指针定位->",self.PosFound)
		it=len(mylist)
		for it1 in range(1,it):#按序打开文件
			if self.model.item(it1).checkState():
				lfilename=os.path.join("src",mylist[it1-1])

				#linecount=len([ "" for line in open(lfilename,"r")])#统计文件行数黑客代码

				fh1=open(lfilename,mode='r+t',encoding='UTF-8')
				if fh1:
#					print("\t\t打开文件：",lfilename)
					fh1.seek(0)
					data=fh1.read()
					listt = data.split("\n")#含完整的文件路径
				fh1.close()
				it2=len(listt)#每个文件中的表项数

				blinecount=0
				for data in listt:#统计空行数
					if data=="":
						blinecount+=1

				if(blinecount/it2>bratio):#空行比是否较大
					srchexpand=True#扩展搜索结果
					ib=0#记录前一个空行号
				else:
					srchexpand=False
#				print("文件:",lfilename,"共",it2,"\t行，空行：",blinecount,"\t行，空行比",blinecount/it2)

				i=0
				ifirst=0
				slestate=False
				while (i<it2):
					s=listt[i]#获取文件内容
#					print("第",i,"行：",s)

					if not s.strip():
						ib=i
					if slestate:
#						print("入选内容：\t",s)
						if not s.strip():
							fh2.write(s+"\n")
							slestate=False
#							print("入选内容已至空行",i)
#					else:
#						print("未入选内容：\t",s)
					if slestate:
						fh2.write(s+"\n")
					else:	
						printed=False
						for i1 in range(lenl1):
							if(sslist2):
								i2p=0
								for i2 in range(lenl2):
									newpos2=s.find(sslist2[i2])
#									print("Search i2=",i2,"\t",sslist2[i2],"newpos2=",newpos2)
									if (newpos2>=0):
										#v0.54有界搜索
										if Ltdp:
											newpos2e=newpos2+len(sslist2[i2])-1
											if(newpos2==0):
												if(newpos2e<len(s)-1):
													if not (s[newpos2e].isdigit() and s[newpos2e+1].isdigit()):
														#print(i,"行右界数文转变")
														i2p+=1
												elif (newpos2e==len(s)-1):
													#print(i,"右界尽")
													i2p+=1
											else:
												if(newpos2e<len(s)-1):
													if not (s[newpos2e].isdigit() and s[newpos2e+1].isdigit()):
														#print(i,"行右界数文转变")
														if not (s[newpos2].isdigit() and s[newpos2-1].isdigit()):
															#print(i,"行左界数文转变")
															i2p+=1
												elif (newpos2e==len(s)-1):
													#print(i,"右界尽")
													if not (s[newpos2].isdigit() and s[newpos2-1].isdigit()):
														#print(i,"行左界数文转变")
														i2p+=1

										else:
											#print(i,"行发现无界搜索关键字->\t",sslist2[i2])
											i2p+=1
								if(i2p>=lenl2):
#									print("\n\t本行多条件匹配：",s)
									PosFound=i+1
									if(srchexpand):
										slestate=True
									if(not printed):#0.52
										if(ifirst==0):
											fh2.write("「 "+os.path.split(lfilename)[1]+" 」\t文件中搜索结果：\n")	
											ifirst=1
#										print("搜索[",ss,"]内容在",PosFound,"行发现,写入文件->",Fruitpath)	
										if slestate:
											for i3 in range(ib,i-1):
												fh2.write(listt[i3]+"\n")
											fh2.write("＝＝＝＝＝＝\n")
	
										fh2.write(s+"\n")
	
										if slestate:
											fh2.write("＝＝＝＝＝＝\n")
										printed=True#0.52
							else:
								newpos1=s.find(sslist1[i1])
								#print("搜索关键字中不含中英文','，字串",s,"位置",newpos1,"关键字：",sslist1[i1],"……开始有界检测")
								if(newpos1>=0):#发现搜索内容
									#v0.54有界搜索
									i2p=0
									if Ltdp:
										newpos1e=newpos1+len(sslist1[i1])-1
#										print(i,"行",newpos1,"~",newpos1e,"列发现无‘，’有界搜索关键字->\t",sslist1[i1])
										if(newpos1==0):
#											print("newpos1==0\tnewpos1e=",newpos1e)
											if(newpos1e<len(s)-1):
												if not (s[newpos1e].isdigit() and s[newpos1e+1].isdigit()):
													#print("右界数文转变")
													i2p+=1
											elif (newpos1e==len(s)-1):
												#print("右界尽",s[newpos1e])
												i2p+=1
										else:
											if(newpos1e<len(s)-1):
												if not (s[newpos1e].isdigit() and s[newpos1e+1].isdigit()):
													#print("右界数文转变")
													if not (s[newpos1].isdigit() and s[newpos1e-1].isdigit()):
														#print("左界数文转变")
														i2p+=1
											elif (newpos1e==len(s)-1):
												#print("右界尽",s[newpos1e])
												if not (s[newpos1].isdigit() and s[newpos1e-1].isdigit()):
													#print("左界数文转变")
													i2p+=1
									else:
#										print(i,"行发现无‘，’无界搜索关键字->\t",sslist1[i1])
										i2p+=1
									if(i2p>=1):

										PosFound=i+1
										if(srchexpand):
											slestate=True
										if(not printed):#0.52
											if(ifirst==0):
												fh2.write("\n\t「 "+os.path.split(lfilename)[1]+" 」\t文件中搜索结果：\n")
												ifirst=1
#											print("搜索[",ss,"]内容在",PosFound,"行发现,写入文件->",Fruitpath)
											if slestate:
												for i3 in range(ib,i-1):
													fh2.write(listt[i3]+"\n")
												fh2.write("＝＝＝＝＝＝\n")
		
											fh2.write(s+"\n")
		
											if slestate:
												fh2.write("＝＝＝＝＝＝\n")
											printed=True#0.52
#									else:
#										print("无有界搜索结果，i2p=",i2p)
	
					i+=1
				if(i==it2):
					PosFound=1
					#print("\n***搜索文件：",lfilename,"到达尾部***\n")

		if fh2:
			fh2.close()
#v48			fh2=open(Fruitpath,mode='r+t',encoding='UTF-8')
			#fh2.seek(0)
			#data=fh2.read()
		#self.ui.textEdit.setText(data)
		self.displayextract()

# 237 243 (1543)

	def SearchRow(self,n,FullStep,ss):#列表搜索
		#print("进入SearchRow搜索->",n,"关键字： ",ss,"连续搜索",FullStep)
		if(n==1):
			model=self.model
		elif (n==2):
			model=self.model2
		#FullStep=model.item(0).checkState()#0行未勾选，搜索一次中止，否则全文搜索标记
		#ss=model.item(0).index().data()#获取listView的0行内容***
		#v0.61关键字去括号
		sst=ss
		ls=len(sst)
		ik1=sst.find('(')
		ik2=sst.find(')')
		treatp=False
		if(ik1>=0):
			treatp=True
			while(ik1>=0):
				if(ik1>0):
					#print("发现左括号，开始去除……")
					if(ik2>=0):
						if(ik2>ik1):
							sst=sst[0:ik1]+sst[ik2+1:ls]
							#print("发现右括号，字符串去括号后成为:\t",sst)
						else:
							sst=sst[ik2+1:ik1]
							#print("未发现右括号，字符串去括号后成为:\t",sst)
					else:
						sst=sst[0:ik1]
					ik1=sst.find('(')
					ik2=sst.find(')')
			#print("处理小括号后关键字为： ",sst)
		ls=len(sst)
		ik1=sst.find('（')
		ik2=sst.find('）')
		if(ik1>=0):
			treatp=True
			while(ik1>=0):
				if(ik1>0):
					#print("发现左括号，开始去除……")
					if(ik2>=0):
						if(ik2>ik1):
							sst=sst[0:ik1]+sst[ik2+1:ls]
							#print("发现右括号，字符串去括号后成为:\t",sst)
						else:
							sst=sst[ik2+1:ik1]
							#print("未发现右括号，字符串去括号后成为:\t",sst)
					else:
						sst=sst[0:ik1]
					ik1=sst.find('（')
					ik2=sst.find('）')
			#print("处理大括号后关键字为： ",sst)
		if treatp:		
			ss=sst
			#print("括号处理后关键字为： ",ss)

		if((ss[0]=='`') or (ss[0]=='｀')) :
			Ltdp=True#v0.54
			ss=ss[1:]	
			#print("首字为`或｀进入有界搜索，关键字->",ss)
		else:
			Ltdp=False#v0.54

		sslist2=[]
#		v0.54由空格及'、'表解构并行搜索项数
		sslistt=[]
		sslist1=[]
		sym=[' ','、']
		sslistt.extend(ss.split(sym[0]))
		i=0
		li=len(sslistt)
		for sp in  sym[1:]:
			for i in range(len(sslistt)):
				ss1=sslistt[i]
				if(ss1.find(sp)>=0):
					sslist1.extend(ss1.split(sp))
				else:
					if ss1.strip():
						sslist1.append(ss1)
				if(i==li-1):
					sslistt=sslist1
					li=len(sslistt)
					sslist1=[]
#				print("i=",i,"\t列表变化：",sslist1)
		sslist1=sslistt
#		print("\t关键字'、'拆分后列表结果：",sslist1)

		lenl1=len(sslist1)
		for i1 in range(lenl1):
			if(sslist1[i1].find(",")>=0):
#				print("搜索关键字中含','")
				slist2=sslist1[i1].split(",")#","解构多条件搜索	
#				print("\n多条件关键字集sslist2=",sslist2)
			elif(sslist1[i1].find("，")>=0):
#				print("搜索关键字中含中文'，'")
				sslist2=sslist1[i1].split("，")#中文"，"解构多条件搜索	
#				print("\n多条件关键字集sslist2=",sslist2)
		lenl2=len(sslist2)
		slestate=False

		if(self.PosFound==-1):
			i=1
		else:
			i=self.PosFound
		#print("\n\ti=",i,"行已发现关键字,指针定位->",self.PosFound)

		it=model.rowCount()

		while (i<it):
			s=model.item(i).index().data()#获取内容
#			print("第",i,"项：",s)
			if slestate:
#				print("入选内容：\t",s)
					slestate=False
#					print("入选内容已至空行",i)
#			else:
#				print("未入选内容：\t",s)
			if slestate:
				itemc=model.item(i)
				itemc.setData(QVariant(Qt.Checked),Qt.CheckStateRole)#改变索引行勾选态***
				si=model.item(i).index()#获取所在行的索引号***
				if(n==1):
					self.ui.listView.setCurrentIndex(si)#定位索引号行***
				elif(n==2):
					self.ui.listView_2.setCurrentIndex(si)#定位索引号行***
			else:	
				for i1 in range(lenl1):
					if(sslist2):
						i2p=0
						for i2 in range(lenl2):
							newpos2=s.find(sslist2[i2])
#							print("Search i2=",i2,"\t",sslist2[i2],"newpos2=",newpos2)
							if (newpos2>=0):
								#print("交集搜索发现关键字",sslist2[i2])

								#v0.54有界搜索
								if Ltdp:
									newpos2e=newpos2+len(sslist2[i2])-1
									if(newpos2==0):
										if(newpos2e<len(s)-1):
											if not (s[newpos2e].isdigit() and s[newpos2e+1].isdigit()):
												#print("右界数文转变")
												i2p+=1
										elif (newpos2e==len(s)-1):
											#print(i,"到达右边界")
											i2p+=1
									else:
										if(newpos2e<len(s)-1):
											if not (s[newpos2e].isdigit() and s[newpos2e+1].isdigit()):
												#print("右界数文转变")
												if not (s[newpos2].isdigit() and s[newpos2-1].isdigit()):
													#print("左界数文转变")
													i2p+=1
										elif (newpos2e==len(s)-1):
											#print(i,"到达右边界")
											if not (s[newpos2].isdigit() and s[newpos2-1].isdigit()):
												#print("左界数文转变")
												i2p+=1
								else:
									#print(i,"行发现无界搜索关键字->\t",sslist2[i2])
									i2p+=1

						if(i2p>=len(sslist2)):
#							print("\n\t本行多条件匹配：",s)
							#newpos1=s.find(sslist1[i1])
							#if(newpos1>=0):#发现0项内容
							self.PosFound=i+1
	
							slestate=True
		#					print("搜索[",ss,"]内容在",i,"行发现,指针定位->",self.PosFound)
							itemc=model.item(i)
							itemc.setData(QVariant(Qt.Checked),Qt.CheckStateRole)#改变索引行勾选态***
							if not FullStep:
								si=model.item(i).index()#获取所在行的索引号***
								if(n==1):
									self.ui.listView.setCurrentIndex(si)#定位索引号行***
									self.ui.listView.scrollTo(si)#ScrollHint(i)#setSelection(i)
								elif(n==2):
									self.ui.listView_2.setCurrentIndex(si)#定位索引号行***
									self.ui.listView_2.scrollTo(si)#ScrollHint(i)#setSelection(i)
								i=it
#								print("\n\t0行没有勾选,标记搜索位置后，搜索暂停\t")
								break
						
					else:
#						print("搜索关键字中不含','")
						newpos1=s.find(sslist1[i1])
						if(newpos1>=0):#发现0项内容
							#print(s,"\t并集搜索发现关键字\t",sslist1[i1])
							i2p=0

							if Ltdp:
								newpos1e=newpos1+len(sslist1[i1])-1
								if(newpos1==0):
									if(newpos1e<len(s)-1):
										if not (s[newpos1e].isdigit() and s[newpos1e+1].isdigit()):
											#print("右界数文转变")
											i2p+=1
									elif (newpos1e==len(s)-1):
										#print(i,"到达右边界")
										i2p+=1
								else:
									if(newpos1e<len(s)-1):
										if not (s[newpos1e].isdigit() and s[newpos1e+1].isdigit()):
											#print("右界数文转变")
											if not (s[newpos1].isdigit() and s[newpos1-1].isdigit()):
												#print("左界数文转变")
												i2p+=1
									elif (newpos1e==len(s)-1):
										#print(i,"到达右边界")
										if not (s[newpos1].isdigit() and s[newpos1-1].isdigit()):
											#print("左界数文转变")
											i2p+=1

							else:
#								print(i,"行发现无‘，’无界搜索关键字->\t",sslist1[i1])
								i2p+=1
							if(i2p>=1):

								self.PosFound=i+1
	
								slestate=True
								#print("搜索[",ss,"]内容在",i,"行发现,指针定位->",self.PosFound)
								itemc=model.item(i)
								itemc.setData(QVariant(Qt.Checked),Qt.CheckStateRole)#改变索引行勾选态***
								if not FullStep:#如果0行没有勾选，到第一个搜索位置就中止，否则全文件搜索标记
									#self.ui.listView.setFocus()#v0.54
									si=model.item(i).index()#获取所在行的索引号***
									if(n==1):
										self.ui.listView.setCurrentIndex(si)#定位索引号行***
										self.ui.listView.scrollTo(si)#ScrollHint(i)#setSelection(i)
									elif(n==2):
										self.ui.listView_2.setCurrentIndex(si)#定位索引号行***
										self.ui.listView_2.scrollTo(si)#ScrollHint(i)#setSelection(i)
									i=it
									break

			i+=1
		#print("\n搜索到达\t",i,"/",it)
		if(i==it):
			self.PosFound=1
#			print("\n***搜索到达尾部***\n")

# 243 7 (1781)
	
	def AddItem(self):#点选行后增加行
#		print("进入AddItem")
		lnum=self.OnOpNumber()#1016
		lstr=self.model.item(0).index().data()#获取0行内容
		self.AddItemView(lnum,lstr)

# 7 45 (2025)

	def AddItemView(self,lnum,lstr):#顶行添至点选行后
#		print("进入AddItemView")
#		lnum=self.OnOpNumber()#1016
#		lstr=self.model.item(0).index().data()#获取0行内容
		mylist=[]
		for i in range(self.model.rowCount()):
			s=self.model.item(i).index().data()#获取内容
#			print("第",i,"项：",s)
			mylist.append(s)
			if(i==lnum):#操作行时，将0行内容插入列表
#				print("插入",i+1,"项：",lstr)
				mylist.append(lstr)
		i=0
		for task in mylist:
			item = QStandardItem(task)
			item.setCheckState(False)
			item.setCheckable(True)
			if i == 0 :
				self.model.clear()
				self.model.appendRow(item)
			else :
				self.model.appendRow(item)
			self.ui.listView.setModel(self.model)
			i=i+1
		i=0
		it=self.model.rowCount()
#		print("\tAddItem表有",it,"项")
		for i in range(it):
#			print("第",i,"项：")
			if(i<=lnum):
				if(i in self.CheckedRowNuber):
#					print("插入行前第",i,"行在选中表中")
					it=self.model.item(i)
					it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)
			if(i>lnum):
				if(i-1 in self.CheckedRowNuber):
#					print("插入行后第",i-1,"行在选中表中")
					it=self.model.item(i)
					it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)
			i+=1

		self.ui.show()
#		self.show()			

# 45 6 (2033)

	def DelItem(self):#删除点选项
#		print("进入DelItem")
		lnum=self.OnOpNumber()#1016
		self.DelItemView(lnum)

# 6 42 (2079)

	def DelItemView(self,lnum):#删除表显项
#		print("进入DelItemView")
#		lnum=self.OnOpNumber()#1016
#		lstr=self.model.item(0).index().data()#获取0行内容
		mylist=[]
		for i in range(self.model.rowCount()):
			s=self.model.item(i).index().data()#获取内容
#			print("第",i,"项：",s)
			if(i!=lnum):#至所删行时，跳过列表
				mylist.append(s)
		i=0
		for task in mylist:
			item = QStandardItem(task)
			item.setCheckState(False)
			item.setCheckable(True)
			if i == 0 :
				self.model.clear()
				self.model.appendRow(item)
			else :
				self.model.appendRow(item)
			self.ui.listView.setModel(self.model)
			i=i+1
		i=0
		it=self.model.rowCount()
#		print("\tAddItem表共有",it,"项")
		for i in range(it):
#			print("第",i,"项：")
			if(i<lnum):
				if(i in self.CheckedRowNuber):
#					print("所删行前第",i,"行在选中表中")
					it=self.model.item(i)
					it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)
			if(i>lnum):
				if(i in self.CheckedRowNuber):
#					print("所删行后第",i-1,"行在选中表中")
					it=self.model.item(i)
					it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)

		self.ui.show()
#		self.show()			

# 42 42 (2086)

	def Extract (self):#手动摘录
		#print("\n进入摘录　Extract")
		Fruitpath=os.path.join(os.getcwd(),self.FruitFile)
		for i in range(1,self.model.rowCount()):#0.33
			if self.model.item(i).checkState():
#				print("检索第",i,"行已选中")
				if(i not in self.CheckedRowNuber ):#0.33
					self.CheckedRowNuber.append(i)
#		print(self.CheckedRowNuber)
#		f = TemporaryFile('w+t',encoding='utf-8' )
		#print("self.Expbnow=",self.Expbnow)
		if(self.Expbnow==0):#v0.74
			f=open(Fruitpath,mode='w+t',encoding='UTF-8')
		else:
			f=open(Fruitpath,mode='a+t',encoding='UTF-8')
			
		#self.ui.textEdit.clear()
		if f:
			for i in self.CheckedRowNuber:
#			print("\n梳理选中的第",i,"项，写入文件")
#			si=self.model.item(i).index()
#			print("\n\t选中项索引：",si)          
#			s=si.data()
				s=self.model.item(i).index().data()
#			print("\t\t选中项内容：",s)          
			#self.ui.textEdit.append(s)
			#if s.strip(): #v0.55插入图片☯xx.jpg
			#	if (s[0]=='☯') :
			#		picname=s[1:]+'.jpg'
					#picnames.append(picname)
# self.ui.textEdit.append('￼')
					#self.ui.textEdit.append(picname)
				f.write(s+"\n")
		f.close()
		self.displayextract()
#		f.seek(0)#注意读取文件时候要将文件指针指向第一个
#		s=f.read()
#		print(s)   
#		self.ui.textEdit.setText(s)
#		for picname in picnames:

# 42 30 (2129)

	def displayextract(self):#编辑框显示摘录
		Fruitpath=os.path.join(os.getcwd(),self.FruitFile)
		f=open(Fruitpath,mode='r+t',encoding='UTF-8')
		if f:
			f.seek(0)#注意读取文件时候要将文件指针指向第一个
			s=f.read()
			mylist = s.split("\n")#含完整的文件路径
			f.close()
			self.ui.textEdit.clear()
			linefeed=True
			for s in mylist:
				if(s.strip()):
					if linefeed:
						self.ui.textEdit.append(s)#v0.76
					else:
						self.ui.textEdit.moveCursor(QTextCursor.End)
						self.ui.textEdit.insertPlainText(s[:-1])
						linefeed=True
					if(s[-1]=='⌇'):
						linefeed=False

				#if s.strip(): #v0.55插入图片☯xx.jpg
					if (s[0]=='☯') :
						picname=s[1:]+'.jpg'
						#self.ui.textEdit.append('<img src="file://'+os.path.join(os.getcwd(),"src",picname)+'" width="600">')
						self.ui.textEdit.append('<img src="'+os.path.join(os.getcwd(),"src",picname)+'" width="600">')
				else:
					self.ui.textEdit.append(s)#v0.76

# 30 14 (2172)
					
	def CopyText(self):#顶显点选行或结果
#		print("\n进入　CopyText,listview 共",self.model.rowCount(),"行")
		i=self.OnOpNumber()
#		print("\t获取正在操作行i=",i)
		if(i==0):
#			print("listview 显示文件名：",self.fileName_choose)
			self.FirstLine(self.fileName_choose)
		else:
			slecstr=self.model.item(i).index().data()#获取列表内容***
			self.myStr=slecstr
#			print("\ti=",i,"内容slecstr=",slecstr)
			self.FirstLine(slecstr)

# 14 6 (2203)

	def FirstLine(self,myStr):#顶行更新
		i1=self.model.item(0).index()#获取0行索引
		self.model.setData(i1, myStr)#更新0行数据
		self.ui.listView.setModel(self.model)

# 6 29 (2218)
	
	def JustCheckedNumber(self):#获取最新勾选的行号
#		print("进入获取最新　勾选　行号方法\n")
#		print("勾选　行序号表",self.CheckedRowNuber)
		i=0
		if(len(self.CheckedRowNuber)==0):
			for i in range(self.model.rowCount()):
				if self.model.item(i).checkState():
					self.JustNum=i
#					print("\n\t只选中一项，为第",i,"行……")
					break
				i = i + 1
		else:
			for i in range(self.model.rowCount()):
				if self.model.item(i).checkState():
					if i not in self.CheckedRowNuber:
						self.JustNum=i
#						print("\n\t不在表中，刚选第",self.JustNum,"行……")
				i = i + 1
		self.CheckedRowNuber=[]
		i=0
		for i in range(self.model.rowCount()):
			if self.model.item(i).checkState():
#				print("选中第",i,"行……",self.mylist[i])
				self.CheckedRowNuber.append(i)
			i = i + 1
#		print("\n\t勾选　行序号表",self.CheckedRowNuber)
#		print("\n\t***刚选中第",self.JustNum,"行")

# 29 23 (2225)
		
	def ViewOp (self):#表项响应
#		print("\n\t列表操作")
		it1=self.OnOpNumber()
		self.JustCheckedNumber()
		if (it1==0):#0行选中全表选中，0行取消，全表取消
			if (self.JustNum!=-1):
				if(self.JustNum==0):
					if self.model.item(0).checkState():
						i=0
						for i in range(self.model.rowCount()):
							it=self.model.item(i)
							it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)
#							print("\t复选第",i,"项")
							i+=1
					else:
						i=0
						for i in range(self.model.rowCount()):
							it=self.model.item(i)
							it.setData(QVariant(Qt.Unchecked),Qt.CheckStateRole)
#							print("\t\t取消复选第",i,"项")
							i+=1

# 23 53 (2236)
			
	def	slot_btn_chooseFile (self):#库文件操作
#		print("选择方法中全局文件名为:",self.fileName_choose)#测试全局变量
		if self.fileName_choose.strip():#v0.4中转打开的非库文件
			filet=self.fileName_choose
		self.fileName_choose,filetype = QFileDialog.getOpenFileName(self,
									"选择库文件或在列文件可以实际更新",
									self.cwd,# 起始路径 
									"All Files (*);;Setfiles(*.set);;Pthon Files (*.py);;Text Files (*.txt);;向导文件(*.xdf)")# 设置文件扩展名过滤,用双分号间隔

		mypath=os.path.join(os.getcwd(),self.OftenFiles)
		mylist1=[]
		lnum=self.OnOpNumber()
		if lnum<0:
			lnum=0
#		print("常用文件路径：",mypath,"当前操作lnum=",lnum,"行")
		fh=open(mypath,mode='a+t',encoding='UTF-8')
		if fh:
			fh.seek(0)#注意读取文件时候要将文件指针指向第一个
			data=fh.read()
			mylist = data.split("\n")
#			print("完成打开文件，准备读取->",mypath,"。文件内容:\n",data,"转列表为：\n",mylist)
			if self.fileName_choose not in mylist:
				if(self.fileName_choose == mypath):
#					print ("你选择了常用文件库本身，不能写入，但列表框内的内容将被更新！")
					reply = QMessageBox.information(self,"文库更新提示", "文件："+self.fileName_choose+" 为文库设置文件，你要更新吗？",QMessageBox.Yes | QMessageBox.No)#使用infomation信息框v0.62
					if(reply==QMessageBox.Yes):
						for i in range(1,self.model.rowCount()):
							mylist1.append(self.model.item(i).index().data())#获取内容
						self.WLinetoFile(mylist1,mypath,-1)
				else:
#					print ("文件名不在列表内,当前选中第",lnum,"行，在其后插入（默认首行0）：")
					reply = QMessageBox.information(self,"文库添加提示", "文件："+self.fileName_choose+" 尚未在文库，你确定添加吗？", QMessageBox.Yes | QMessageBox.No)  
					if(reply==QMessageBox.Yes):
						lstr=os.path.split(self.fileName_choose)[1]
						self.AddItemView(lnum,lstr)
						self.WLinetoFile(mylist,mypath,lnum)
			else:
#				print ("\n\t文件名已在列表内，不进行添加，但正好为列表显示文件时，更新写入列表内容。")
				if(self.fileName_choose==filet):
					if(self.Expfnow==0):#全览模式下保存
						reply = QMessageBox.information(self,"文件覆盖提示", "文件："+self.fileName_choose+" 将被重写覆盖，你确定吗？",QMessageBox.Yes | QMessageBox.No)  
						if(reply==QMessageBox.Yes):
							self.WListtoFile(mylist,self.fileName_choose)
					else:#分页模式下保存
						reply = QMessageBox.information(self,"文件覆盖提示", "文件["+self.fileName_choose+"]正在分页模式下操作，如果保存将只更新本页内容，你确定吗？",QMessageBox.Yes | QMessageBox.No)  
						if(reply==QMessageBox.Yes):
							self.UpListtoFile(mylist,self.fileName_choose)

			fh.close()
		self.ui.show()
#		self.show()

# 53 37 (2260)

	def WLinetoFile(self,llist,lpath,lnum):#行更新进文件
#		print("进入加新行进文件操作，新行:",self.fileName_choose,"\n\t准备写至：",lpath)
#		print("显示列表为：",llist)
		fh1=open(lpath,mode='r+t',encoding='UTF-8')
		if fh1:
			fh1.seek(0)#读取文件时候要将文件指针指向第一个
			data=fh1.read()
			mylist = data.split("\n")#含完整的文件路径
		fh1.close()
		if(lnum>=0):
			mylist.insert(lnum,self.fileName_choose)
			fh1=open(lpath,mode='w+t',encoding='UTF-8')
			if fh1:
				fh1.seek(0)
				for i in range(len(mylist)):
					if mylist[i].strip():
#						print("准备将第",i,"项写入文件：",lpath)
						fh1.write(mylist[i]+'\n')
			fh1.close()
		else:#根据删除、拖放更新文件列表
			fh1=open(lpath,mode='w+t',encoding='UTF-8')
			if fh1:
				fh1.seek(0)
				for i in range(len(llist)):
					for i1 in range(len(mylist)):
						if(llist[i].strip()):
							lstr=os.path.split(mylist[i1])[1]
							if(llist[i]==lstr):
#								print("第",i,"项：",llist[i],"-->对应完整路径：",mylist[i1],"写入")#此法不能删除某一同名文件
								fh1.write(mylist[i1]+'\n')
								break
#							else:
#								print(lstr,"非对应路径，不予写入文件：",lpath)

			fh1.close()

# 37 18 (2314)
						
	def WListtoFile(self,mylist,lpath):#整列表转文件
#		mypath=os.getcwd()+"/"+self.OftenFiles
#		print("进入写文件操作，文件:",self.fileName_choose,"\n\t准备压栈至：",lpath)
		fh1=open(lpath,mode='w+t',encoding='UTF-8')
		if fh1:
			fh1.seek(0)#注意读取文件时候要将文件指针指向第一个
#		with open(mypath, mode='a+t',encoding='UTF-8') as fh:
#'r'读,'w'写,'a'追加,'r+'=r+w可读写，若不存在就报错(IOError)'w+'=w+r可读写，若不存在就创建）
#'a+'=a+r可追加可读，若不存在就创建；二进制文件，就都加一个b：'rb','wb','ab','rb+','wb+','ab+'
		for i in range(1,self.model.rowCount()):
			s=self.model.item(i).index().data()#获取内容
#			if s.strip():
#				print("准备将第",i,"项写入文件：",s)
			fh1.write(s+'\n')

		fh1.close()

# 18 17 (2352)
			
	def UpListtoFile(self,mylist,lpath):#本页列表更新进文件
#		mypath=os.getcwd()+"/"+self.OftenFiles
		print("进入更新列表至文件操作，文件:",self.fileName_choose,"\n\t准备压栈至：",lpath)
		fh1=open(lpath,mode='w+t',encoding='UTF-8')
		if fh1:
			fh1.seek(0)
		for i in range(0,self.Expbnow):
			fh1.write(self.ViewList[i]+'\n')
		for i in range(0,self.model.rowCount()):
			s=self.model.item(i).index().data()#获取内容
			fh1.write(s+'\n')
		for i in range(self.Expfnow,self.lViewList):
			fh1.write(self.ViewList[i]+'\n')

		fh1.close()

# 17 31 (2390)

	def	slot_btn_openFile(self):#显示上栏文件
		#print("\n进入slot_btn_openfile->")
		fh=False
		mypath=os.path.join(os.getcwd(),self.OftenFiles)
		fh1=open(mypath,mode='r',encoding='UTF-8')
		if fh1:
			data=fh1.read()
			filelist=data.split("\n")
		fh1.close()
		i=self.model.item(0).checkState()#检测顶行是否勾选，决定是之后文件格式行显示否
		#print("\n\t检测顶行勾选与否：",i)
		if(i>0):
			self.FormatShow=True#格式行显示
			#print("\n\t格式行显示开关打开",self.FormatShow)
		else:
			self.FormatShow=False#格式行不显示
			#print("\n\t格式行显示开关关闭",self.FormatShow)

		i=self.OnOpNumber()#v0.76
		if (i<=0):
			slecstr=mypath
		else:
#			print("\n\ti>0,i=",i)
			if(filelist):
				slecstr=os.path.join(os.getcwd(),"src",filelist[i-1])
		self.fileName_choose=slecstr
		#print("\n当前打开文件self.fileName_choose名： ",self.fileName_choose)
		self.prompstr="" #slecstr v0.76
		self.myfileopen(slecstr,1)

# 31 21 (2408)

	def	slot_btn3_openFile(self):#显示下栏文件
		#print("\n进入slot_btn3_openfile->")
		fh=False
		mypath=os.path.join(os.getcwd(),self.OftenFiles)
		fh1=open(mypath,mode='r',encoding='UTF-8')
		if fh1:
			data=fh1.read()
			filelist=data.split("\n")
		fh1.close()
		i=self.OnOpNumber()#v0.4
		if (i<=0):
			slecstr=mypath
			#self.fileName_choose=mypath
		else:
#			print("\n\ti>0,i=",i)
			if(filelist):
				slecstr=os.path.join(os.getcwd(),"src",filelist[i-1])
		self.prompstr="" #slecstr v0.76
		self.myfileopen(slecstr,2)

# 21 153 (2411)

	def AltStr (self,slecstr,digit_num,strcacup):#分层拆解括号串
#digit_num<0,如-1表程序判断小数位数，>=0表强制输出小数位；strcacup表示计算1与否0,也表示当前表首项self.Expbnow位置
		global DlgStr
#		print("\n\n\t***计算字符串进入分解方法：",slecstr)
#		str1=self.ui.lineEdit_2.text()
#		slecstr=self.model.item(0).index().data()#获0行内容#1015
		self.mystr=slecstr
#		print("字串为：",self.mystr)
		strpara=" "
		str1=self.mystr
#		print("字串为：",str1,"分隔符为[",strpara,"]")
		#strlist=[]
		strlist=str1.split(strpara)
		ns = len(strlist)
		i1 = len(strpara)
#		print("一级分解后计算字符串成为表：",strlist,"\t共",ns,"项")
		if (i1==0):
			strpara0=""
		itt=0
		while(itt<ns):#各表项遍历
			self.mystr=str1t = strlist[itt]#分解的字串项
#			print("\n分解的字串项：",str1t)
			self.fmt=self.floatfmt(str1t)#v0.60
			#print("\t字串小数位数：",self.fmt)
			bracketn = 0
			slen = len( str1t)
			nct =0 
			while(nct < slen):
				strn = str1t[nct]
				nct+=1
				if(strn == '('):
					bracketn = bracketn+1
			nct1=0
			k1=0
			while(k1<bracketn):#各层括号解析
				bracketnt = 0
				numn = 0
				bracketb = 0
				brackete = 0
				nct = 0
				sta = 1
				slen = len( str1t)
				while (nct < slen):#找出最内层括号序号
					if(nct>nct1):
						strn = str1t[nct]
						if(strn == '(') :
							bracketnt = nct
						elif(strn==')') :
							bracketb = bracketnt
							brackete = nct
							break
					nct +=1
				sta=brackete-bracketb-1
#				print("\n第",k1,"层括号开始于：",bracketb,"\t结束于",brackete,"\t净字符数：",sta)
				prestr = str1t[0:bracketb]
				midstr = str1t[(bracketb+1):brackete]
				endstr = str1t[(brackete+1):]
#				print("\n第",k1,"层括号分解后，前串：",prestr,"\t中串：",midstr,"\t后串：",endstr)
				if(strcacup!=0):
#					print("判断为需计算")
					if (len(midstr)!= 0):
#						print("alt中间字串：",midstr)
						if(midstr[0]=='@'):
				#			print("AltStr准备弹出框运行")
							str1t = self.PopList(midstr,strcacup)
				#			print("AltStr弹出框获得输入：",str1t)
						elif(not self.IsNumber(midstr)):
							Indexpath=os.path.join(os.getcwd(),self.IndexFile)
							fh1=open(Indexpath,mode='r',encoding='UTF-8')
							if fh1:
								data=fh1.read()
								filelist=data.split("\n")
							fh1.close()
							if(data.find(midstr)>=0):
				#				print("AltStr搜寻索引文件:",Indexpath,"找到字串赋值变量（",midstr,")=",end="")
								for linedata in filelist:
									if linedata.find(midstr)>=0:
										linestr=linedata
								midstr=self.psplit(linestr,'"','"')[-1][1:-1]
								#midstr=linestr.split()[-1][1:-1]
				#				print(midstr)
							else:
								print("AltStr搜寻索引文件:",Indexpath,"未找到字串赋值！")
						#else:
						#	midstr=strt
							self.mystr=midstr
							self.strcacu(midstr)
							str1t=prestr+self.mystr
							str1t=str1t+endstr
							self.mystr=str1t
				#		print("\n第",k1,"层括号运算后，成为串：",str1t)
#				if (midstr != NULL):
				else:
				#	print("判断为不需计算")
					#str1t = midstr
					if(not self.IsNumber(str1t)):#!self.IsNumber(str1t)):
						Indexpath=os.path.join(os.getcwd(),self.IndexFile)
						#indxfile = strlink(dpath,"mindwaytemp.txt",MAXCHAR)
						#if(indexfile)indxfile=indexfile
						#fp1 = fopen (Indexpath,"r+t")
						fh1=open(Indexpath,mode='r',encoding='UTF-8')
						if fh1:
							data=fh1.read()
							filelist=data.split("\n")
						fh1.close()
						if(data.find(str1t)>=0):
				#			print("AltStr搜寻索引文件:",Indexpath,"找到字串赋值变量（",str1t,")=",end="")
							for linedata in filelist:
								if linedata.find(str1t)>=0:
									linestr=linedata
							str1t=linestr.split[-1]
							print(str1t)
						else:
							print("AltStr搜寻索引文件:",Indexpath,"未找到字串赋值！")

				k1+=1	
#			print("运算前，字串为：",self.mystr)#v0.85
			self.strcacu(self.mystr)
#			print("运算后，成为串：",str1t)
			#v0.60
			if(self.IsNumber(self.mystr)):
			#	if(self.floatfmt(self.mystr)!=0):#v0.7
				value=float(self.mystr)
			#	print("Alt实数运算结果：",value)
				if(digit_num<0):
					if((abs(value)<1e5) and (abs(value) >1e-3)):
						if(self.floatfmt(self.mystr)!=0):#v0.7
			#				self.mystr=str(value)
			#				print("Alt整数输出：",self.mystr)
			#			else:
							self.mystr=str(round(value,self.fmt))
			#				print("Alt实数输出：",self.mystr)
				else:					
					if((abs(value)<1e5) and (abs(value) >1e-3)):
						self.mystr=str(round(value,digit_num))

				strlist[itt]=self.mystr
			else:
				strlist[itt]=str1t
			#print("\n第",itt,"表项运算后，成为串：",strlist[itt])
			if(itt==0):
				str1=strlist[itt]
			else:
				str1=str1+" "+strlist[itt]
			itt+=1

			self.mystr=str1
			self.FirstLine(self.mystr)
#			self.ui.lineEdit_3.setText(self.mystr)#1014
			#print("\n第",k1,"层括号运算后，成为串：",self.mystr)
			return str1t

# 153 497 (2433)

	def strcacu (self,mystr):#算式串计算转化
		caculist1=["sin","cos","tg","ctg","arcsin","arccos","arctg","sinh","cosh","tgh","abs","rand"]
		caculist2=["^", "ln", "lg"]
		caculist3=["*","/"]
		caculist4=["+", "-"]
		listn = 12
		passt = 0
#		self.mystr=self.ui.lineEdit_2.text()
		found1 = len(self.mystr)
		rank =listn
		inow=0#1014
		i1=0
		value=""
		#print("\n进入字符串计算strcacu，字符串为：",self.mystr)

		while i1<listn:
			foundt = self.mystr.find(caculist1[i1],inow)#1014
			if(foundt>=0): 
#				print("计算字符串[ ",self.mystr," ]中发现一级优先计算符(",caculist1[i1],")位于",foundt)
				if(foundt <= found1):
					rank = i1
					found1 =foundt
				passt = 1
			i1 +=1
#		print("\n位置1发现")#,self.mystr,"第[",rank,"]运算串",caculist1[rank])
		while(passt ==1):
			numbers = 0
			i5=0
#			print("\t一级前strcacu->ArrangStr中一级运算符:",caculist1[rank],",found1=",found1)
			if(found1>=0):self.ArrangStr(self.mystr,caculist1[rank])#1014
			value=""#1014
			if(self.numt1id[1]==1):#1014
				if(self.numt1[2]=="sin"):
					
					cacustrt = self.numt1[1]
					self.numt1[1]=""
					self.numt1id[1]=0
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.sin (para1)
						numbers = 1
#					print("\tself.IsNumber(cacustrt)值：",self.IsNumber(cacustrt))
					
#					else:print("\tcacustrt.isalnum()值：",cacustrt.isalnum())
				if(self.numt1[2]=="cos" ):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.cos (para1)
						numbers = 1
				if(self.numt1[2]=="tg"):
				
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.tan (para1)
						numbers = 1
				if(self.numt1[2]=="ctg"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = 1.0/math.tan (para1)
						numbers = 1
				if(self.numt1[2]=="arcsin"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.asin (para1)
						numbers = 1
				if(self.numt1[2]=="arccos"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.acos (para1)
						numbers = 1
				if(self.numt1[2]=="arctan"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.atan (para1)
						numbers = 1
				if(self.numt1[2]=="asinh"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.asinh (para1)
						numbers = 1
				if(self.numt1[2]=="acosh"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.acosh (para1)
						numbers = 1
				if(self.numt1[2]=="atanh"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.atanh (para1)
						numbers = 1
				if(self.numt1[2]=="abs"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.fabs (para1)
						numbers = 1
				if(self.numt1[2]=="rand"):
					
					cacustrt = self.numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						value = radom.randint()
						numbers = 1
				else:
					passt=0

			if(value != ""):#滚动输出
				if(self.numt1id[0]==1):
					self.mystr=self.numt1[0]+str(value)
					self.numt1id[0]=0
					if(self.numt1id[4]==1):
						self.mystr=self.mystr+self.numt1[4]
						self.numt1id[4]=0
				else:
					self.mystr=str(value)
					if(self.numt1id[4]==1):
						self.mystr=self.mystr+self.numt1[4]
						self.numt1id[4]=0
#				print("一级运算",cacustrt,")","\t计算结果值：",value,"mystr=",self.mystr)
			else:#1014
				inow+=found1+1

				#self.ui.lineEdit_3.setText(self.mystr)
#		print("\n位置2",self.mystr)
		listn = 3
		passt = 0
		found1 = len(self.mystr)
		rank =listn
		inow=0#1014
		i1=0
		while (i1<listn):
			foundt = self.mystr.find(caculist2[i1],inow)#1014
#			print("\t遍历一级计算串[",i1,"]=",caculist2[i1],"foundt=",foundt)
			if(foundt>=0): 
#				print("计算字符串[ ",self.mystr," ]中发现二级优先计算符(",caculist2[i1],")")
				if(foundt <= found1):
					rank = i1
					found1 =foundt
				passt = 1
			i1+=1
		while(passt ==1):
			numbers = 0
			i3=rank
#			print("\t二级前strcacu->ArrangStr中运算符:",caculist2[rank])
			self.ArrangStr(self.mystr,caculist2[rank])#1014
			value=""#1014
			if(self.numt1id[1]==1):#1014
				if( self.numt1[2]=="^"):
					if(self.numt1id[1]==1):
						cacustrt1 = self.numt1[1]
						self.numt1id[1]=0
#						print("\tstrcacu函数输入值",cacustrt1)
					if(self.numt1id[3]==1):					
						cacustrt2 = self.numt1[3]
						self.numt1id[3]=0
#						print("\tstrcacu函数输入值",cacustrt1)
					if(self.IsNumber(cacustrt2)):
						para2= float (cacustrt2)
						self.numt1id[3]=0
					if((cacustrt1[0] == 'e') or (cacustrt1[0] == 'E')):
						self.numt1id[1]=0
						value = math.exp (para2)
					else :
						para1= float (cacustrt1)
						self.numt1id[1]=0
						value = math.pow (para1,para2)
						#print(cacustrt1,"^",cacustrt2,"=",value)
				if( self.numt1[2]=="ln"):
					if(self.numt1id[1]==1):
						
						cacustrt = self.numt1[1]
#						print("\tstrcacu函数ln输入值：",cacustrt)
						para1= float (cacustrt)
						numbers =1
						value = math.log (para1)
						self.numt1id[1]=0
						#print("\tln",cacustrt,"=",value)
				if( self.numt1[2]=="lg"):
					if(self.numt1id[1]==1):
						
						cacustrt = self.numt1[1]
#						print("\tstrcacu函数ln输入值：",cacustrt)
						para1= float (cacustrt)
						numbers =1
						value = math.log10 (para1)
						self.numt1id[1]=0
						#print("\tlg",cacustrt,"=",value)
#					self.mystr=str(value)
#					print("\n\t***mystr值更新为",self.mystr)

			if(value != ""):#滚动输出
				if(self.numt1id[0]==1):
					self.mystr=self.numt1[0]+str(value)
					self.numt1id[0]=0
					if(self.numt1id[4]==1):
						self.mystr=self.mystr+self.numt1[4]
						self.numt1id[4]=0
				else:
					self.mystr=str(value)
					if(self.numt1id[4]==1):
						self.mystr=self.mystr+self.numt1[4]
						self.numt1id[4]=0
#				print("二级运算计算结果值：",value,"\tmystr=",self.mystr)
				#self.ui.lineEdit_3.setText(self.mystr)
			else:
				inow+=found1+1#1014

	
			passt = 0
			found1 = len(self.mystr)
			rank =listn
			i2=0
			while(i2<listn):
				foundt = self.mystr.find(caculist2[i2],inow)#1014
				#foundt = found(caculist2[i1],str)
				if(foundt>=0): 
					if(foundt <= found1):
						rank = i2
						found1 =foundt
					passt = 1
				i2+=1

#		print("\n位置3",self.mystr)
		listn = 2
		passt = 0
		found1 = len(self.mystr)
		rank =listn
		inow=0#1014
		i1=0
		while(i1<listn):
			foundt = self.mystr.find(caculist3[i1],inow)#1014
			if(foundt>=0): 
#				print("计算字符串[ ",self.mystr," ]中发现三级优先计算符(",caculist3[i1],")")
				if(foundt <= found1):
					rank = i1
					found1 =foundt
				passt = 1
			i1+=1
		while(passt ==1):
			numbers = 0
			i3=rank
#			i5=0
#			print("\t三级前strcacu->ArrangStr中运算符:",caculist3[rank])
			self.ArrangStr(self.mystr,caculist3[rank])#1014
			value=""#1014
			if(self.numt1id[3]==1):#1014
				if( self.numt1[2]=="*"):
					if(self.numt1id[1]==1):
						
						cacustrt1 = self.numt1[1]
#						print("\tstrcacu函数输入值*：",cacustrt1)
						if(self.floatfmt(cacustrt1)==0):
							para1= int (cacustrt1)
						else:
							para1= float (cacustrt1)
						#para1= float (cacustrt1)
						numbers +=1
						self.numt1id[1]=0
					if(self.numt1id[3]==1):
						
						cacustrt2 = self.numt1[3]
#						print("\tstrcacu函数输入值：%s\n",cacustrt2)
						if(self.floatfmt(cacustrt2)==0):
							para2= int (cacustrt2)
						else:
							para2= float (cacustrt2)
						#para2= float (cacustrt2)
						numbers +=1
						self.numt1id[3]=0
					if(numbers>1):
						value = para1 * para2
				if( self.numt1[2]=="/"):
					if(self.numt1id[1]==1):
						
						cacustrt1 = self.numt1[1]
#						print("\tstrcacu函数输入值/：%s\n",cacustrt1)
						if(self.floatfmt(cacustrt1)==0):
							para1= int (cacustrt1)
						else:
							para1= float (cacustrt1)
						#para1= float (cacustrt1)
						numbers +=1
						self.numt1id[1]=0
					if(self.numt1id[3]==1):
						
						cacustrt2 = self.numt1[3]
#						print("\tstrcacu函数/输入值：%s\n",cacustrt2)
						if(self.floatfmt(cacustrt2)==0):
							para2= int (cacustrt2)
						else:
							para2= float (cacustrt2)
						#para2= float (cacustrt2)
						numbers +=1
						self.numt1id[3]=0
					if(numbers>1):
						if(math.fabs(para2)<1e-10):
							print("除数不能为零！\n")
						else :
							value = para1 / para2
#					if(self.numt1id[0]!= 0):
#						str1 = self.numt1[0]+str1
#					if(self.numt1id[4]!= 0):
#						str1 = str1+self.numt1[4]
					
#					self.mystr = str(value)
	
			if(value != ""):#滚动输出
				if(self.numt1id[0]==1):
					self.mystr=self.numt1[0]+str(value)
					self.numt1id[0]=0
					if(self.numt1id[4]==1):
						self.mystr=self.mystr+self.numt1[4]
						self.numt1id[4]=0
				else:
					self.mystr=str(value)
					if(self.numt1id[4]==1):
						self.mystr=self.mystr+self.numt1[4]
						self.numt1id[4]=0
				#print("三级运算结果值：",value,"mystr=",self.mystr)
			else:
				inow+=found1+1#1014
					
					#self.ui.lineEdit_3.setText(self.mystr)
			passt = 0
			found1 = len(self.mystr)
			rank =listn
			i1=0
			while(i1<listn):
				foundt = self.mystr.find(caculist3[i1],inow)#1014
				#foundt = found(caculist3[i1],str)
				if(foundt>=0): 
					if(foundt <= found1):
						rank = i1
						found1 =foundt
					passt = 1
				i1+=1
#		print("\n位置4",self.mystr)#四级运算开始，＋，－
		listn = 2
		passt = 0
		found1 = len(self.mystr)
		rank =listn
		inow=0#1014
		i1=0
		while(i1<listn):
			foundt = self.mystr.find(caculist4[i1],inow)#1014
			if(foundt>=0): 
#				print("计算字符串[ ",self.mystr," ]中发现四级优先计算符(",caculist4[i1],")")
				if(foundt <= found1):
					rank = i1
					found1 =foundt
				passt = 1
			i1+=1
		while(passt ==1):
			numbers = 0
			i3=rank
			i5=0
#			print("\t四级前strcacu->ArrangStr中运算符:",caculist4[rank])
			self.ArrangStr(self.mystr,caculist4[rank])#1014
			value=""#1014
			if(self.numt1id[3]==1):#1014

				if( self.numt1[2]=="+" ):
					if(self.numt1id[1]==1):
						cacustrt1 = self.numt1[1]
						if(self.floatfmt(cacustrt1)==0):
							para1= int (cacustrt1)
						#	print("整数",para1)
						else:
							para1= float (cacustrt1)
						#	print("实数",para1)
						numbers +=1
						self.numt1id[1]=0
						#print("\tstrcacu函数输入值1：",cacustrt1)
					if(self.numt1id[3]==1):
						cacustrt2 = self.numt1[3]
						if(self.floatfmt(cacustrt2)==0):
							para2= int (cacustrt2)
						#	print("整数",para2)
						else:
							para2= float (cacustrt2)
						#	print("实数",para2)
						numbers +=1
						self.numt1id[3]=0
						#print("\tstrcacu函数输入值2：",cacustrt2)
					else :
						passt=1
						break
					if(numbers>1):
						value = para1 + para2
						numbers = 2
				if( self.numt1[2]=="-"):
					if(self.numt1id[1]==1):
						#i4=len(self.numt1[1])
						cacustrt1 = self.numt1[1]#v0.73
						if(self.floatfmt(cacustrt1)==0):
							para1= int (cacustrt1)
							#print("整数",para1)
						else:
							para1= float (cacustrt1)
						numbers +=1
						self.numt1id[1]=0
					if(self.numt1id[3]==1):
						#i4=len(self.numt1[3])
						cacustrt2 = self.numt1[3]
						if(self.floatfmt(cacustrt2)==0):
							para2= int (cacustrt2)
							#print("整数",para2)
						else:
							para2= float (cacustrt2)
						numbers +=1
						self.numt1id[3]=0
					else :
						passt=1
						break
					if(numbers>1):
						value = para1 - para2
						numbers = 2
	
					passt = 0
					found1 = len(self.mystr)
					rank =listn
					i1=0
					while(i1<listn):
						foundt = self.mystr.find(caculist4[i1],inow)#1014
						if(foundt>=0): 
							if(foundt <= found1):
								rank = i1
								found1 =foundt
							passt = 1
						i1+=1
				else:
					passt=0


			if(value != ""):#滚动输出
				if(self.numt1id[0]==1):
					self.mystr=self.numt1[0]+str(value)
					self.numt1id[0]=0
					if(self.numt1id[4]==1):
						self.mystr=self.mystr+self.numt1[4]
						self.numt1id[4]=0
				else:
					self.mystr=str(value)
					if(self.numt1id[4]==1):
						self.mystr=self.mystr+self.numt1[4]
						self.numt1id[4]=0
				#print("四级运算计算结果值：",value,"mystr=",self.mystr)
				#self.ui.lineEdit_3.setText(self.mystr)
			else:#1014
				inow+=found1+1

			#print("\n位置5",self.mystr)
			listn = 2
			passt = 0
			found1 = len(self.mystr)
			rank =listn
			i1=0
			while(i1<listn):
				foundt = self.mystr.find(caculist4[i1],inow)#1014
				if(foundt>=0): 
					if(foundt <= found1):
						rank = i1
						found1 =foundt
						passt = 1
#					print("计算字符串[ ",self.mystr," ]中发现四级优先计算符(",caculist4[i1],")","foundt=",foundt,",found1=",found1,",passt=",passt)
				i1+=1

# 497 221 (2587)

	def ArrangStr (self,lstr,symb):#字串数、符分拆至五位列表
		#lstr为字串，symb为运算符,五位列表：符、数、符、数、符
		state = 0
		statet = 0
		n5=[]
		i1=0
#		print("\n进入ArrangStr,运算符为：[ ",symb," ]字符串为：[",lstr,"]\n")#30+50+70
		bracketn = 0
		slen = len (symb)
		xlen = len (lstr)
		ncs = 0
		nct = 0
		nct1 = 0
		pd0 = 0
		pd1 =0 
		founds=0
		pd3 = 0 
		strt = ""#'\0'
		numtt=numt=""
		self.numt1=["","","","",""]
		self.numt1id=[0,0,0,0,0]
		founds=lstr.find(symb)
		numberp=self.IsNumber(lstr)
#		print("\n字串中发现运行符的位置为 ",founds,"是否数字:",numberp)
		if(founds>=0 and (not numberp)):
			while(nct < xlen):
				strnl = lstr[nct]#字串遍历 10+30^2*sinln4
	#			strns = symb[ncs] 
#				print("\n循环中,运算符为：[ ",symb," ]字符串为：[",lstr,"]\n")#30+50+70
#				print("\nnct=",nct,"\txlen=",xlen,"\tnct1=",nct1,"\tstrnl=",strnl)
#				print("\nnumt1[]",self.numt1,"\nnumt1id[]",self.numt1id,"\n")
				#字串是数字？#正负号#科学计数
				if (strnl.isdigit( ) or (strnl == '.') or (strnl == 'e')  or (strnl == 'E') or 
						(((strnl == '-')or(strnl=='+')) and (nct==0)) or 
						(((strnl == '-')or(strnl=='+'))	and ((lstr[nct-1] == 'e')or(lstr[nct-1] == 'E')))
					):
					state = 1
				else: state=0
#				print("状态参数：statet=",statet,"\tstate=",state)
				if(statet == state):#数与非数状态不变
					#print("\n\t数与非数状态不变")
					#print("\tnumt：",numt,"\tnumtt=",numtt,"\tnct1=",nct1)
					if(nct == (xlen-1)):#末字符时
						numt=numt+strnl#字串追加
						numtt=numt#记录字串
						if(state==1):#是数字
							if(self.numt1id[1]==0):
								self.numt1[1]=numtt#写入“数1串”栈[前串，数1串,运算串,数2串，后串]
								self.numt1id[1]=1#标记有“数1串”
								#print("\n\t分支1-1-1列表numt1：",self.numt1)
								#print("\n\t分支1-1-1列表numt1id：",self.numt1id)
							else:
								self.numt1[3]=numtt#已有“数1串”时写入“数2串”栈
								self.numt1id[3]=1#标记有“数2串”
								#print("\n\t分支1-1-2列表numt1：",self.numt1)
								#print("\n\t分支1-1-2列表numt1id：",self.numt1id)
						else:#不是数字
							if(self.numt1id[4]==0):
								self.numt1[4]=numtt#写入“后串”
								self.numt1id[4]=1#标记有“后串”
								#print("\n\t分支1-1-3列表numt1：",self.numt1)
								#print("\n\t分支1-1-3列表numt1id：",self.numt1id)
	
						break

					elif(nct==founds):#非末字#运算符处10+30^2*sinln4 1+2^3					
						numtt=numt #记录之前串符
						numt=strnl
						if(self.numt1id[0]==0):#"前串"栈空时，压栈
							numtp=lstr[0:nct]
							self.numt1[0]=numtp#列表第1格记录"前串"
							self.numt1id[0]=1#标记有"前串"
							self.numt1[2]=symb#列表第3格记录"运算串"
							self.numt1id[2]=1#标记有"运算串"
							nct+=slen-1
							state=0
							nct1=0
							numt=numtt=""
							#print("\n\t分支1-2高级运算符前串:",numtp)

					elif (strnl=="-"):#1014非末字为-号
						if(lstr[nct-1]!='e' and lstr[nct-1]!='E'):#v0.60
							if(nct<xlen-1):
								if(lstr[nct+1].isdigit( )):
									numtt=numt #记录之前串符
									numt=strnl
									#print("\t分支1-3数与非数状态未改变，但为‘-’号")
									#print("\tnumt：",numt,"\tnumtt=",numtt,"\tnct1=",nct1)
									nct1=0
									state=1
						else:#v0.60
							numt=numt+strnl					

					else:#非末字非运算符处
						numt=numt+strnl					
					nct1+=1
				else :#数与非数状态改变	
					numtt=numt #记录之前串符
					numt=strnl
					#print("\t分支２数与非数状态改变")
					#print("\tnumt：",numt,"\tnumtt=",numtt,"\tnct1=",nct1)
					nct1=0
					if(state==0):#分割串非数字时+
						#print("\t分支2-1为非数字状态")
						if(nct == 0):#首字时
							numt=strnl
							#print("\n\t分支2-1-1首字串numt：",numt,"\tnct1=",nct1)
							nct1+=1#设置变化位置
	
						else:
							#numtt=numt #记录之前数符v0.6
							#numt=strnl#v0.6
							if (nct == (xlen-1)):#末字时
								#print("\n\t分支2-1-3末字串numt：",numt,"\t串长nct1=",nct1,"\tnumtt=",numtt)
								if(self.numt1id[1]==0):#"数1"栈空时，压栈
									self.numt1[1]=numtt#列表第2格记录运算串
									self.numt1id[1]=1#标记有"数1"
								elif (self.numt1id[3]==0):#"数2"栈空时，压栈
									self.numt1[3]=numtt#列表第4格记录运算串
									self.numt1id[3]=1#标记有"数2"

								if (self.numt1id[4]==0):
									numt=numt+strnl
									self.numt1[4]=numt#字串追加压入[后串栈]
									self.numt1id[4]=1#标记有后串
	
							elif(nct==founds) :#中字达到高级运算符时压栈数据
								#print("\n\t分支2-1-2中字串numt：",numt,"\tnumtt=",numtt)
								#print("\n\t\t分支2-1-2-1“数1串”空,压栈",numtt)
								self.numt1[1]=numtt#压栈列表第2格
								self.numt1id[1]=1#标记有“数1串”
								self.numt1[2]=symb#压栈列表第3格
								self.numt1id[2]=1#标记有“运算串”
								nct1=len(numtt) #临时借用nct1变量							
								if(nct1<nct+1):
									self.numt1[0]=lstr[0:founds-nct1]#压栈列表第1格
									self.numt1id[0]=1#标记有“前串”
								nct+=slen-1
								nct1=0
							elif(nct>founds+slen):
								#print("\n\t分支2-1-4中运算串后numtt：",numtt)						
								if(self.numt1id[1]==0) :#运算符后时，检查“数２串”栈
									#print("\n\t分支2-1-4-1中数2串压栈")	
									#if(IsNumber(numtt)):
										#print("\n\t分支2-1-4-1-1中运算串后有数")						
									self.numt1[1]=numtt#压栈列表第2格
									self.numt1[4]=lstr[nct:]#压栈列表第5格
									self.numt1id[1]=1#标记有“数1串”
									self.numt1id[4]=1#标记有“后串”
								elif(self.numt1id[3]==0) :#运算符后时，检查“数２串”栈
									#print("\n\t分支2-1-4-1中数2串压栈")	
									#if(self.IsNumber(numtt)):
										#print("\n\t分支2-1-4-1-1中运算串后有数")						
									self.numt1[3]=numtt#压栈列表第4格
									self.numt1[4]=lstr[nct:]#压栈列表第5格
									self.numt1id[3]=1#标记有“运算串”
									self.numt1id[4]=1#标记有“后串”
								#print("\n\t分支2-1-4列表numt1：",self.numt1)
								#print("\n\t分支2-1-4列表numt1id：",self.numt1id)
								break	
					else:#分割串数字时5
#						print("\t分支２－２为数字状态")
						if(nct == 0):#首字时
							numt=strnl
#							print("\n\t分支2-2-1首字串numt：",numt,"\tnct1=",nct1)
							nct1+=1#设置变化位置
						else:#非首字时5
	#						numtt=numt
	#						numt=strnl
							if (nct == (xlen-1)):#末字时
#								print("\n\t分支2-2-2末字串numt：",numt,"\t串长nct1=",nct1,"\tnumtt=",numtt)
								if(self.numt1id[2]==0):#"运算串"栈空时，压栈
									self.numt1[2]=numtt#列表第3格记录运算串
									self.numt1id[2]=1#标记"运算串"
								if(self.numt1id[1]==0):
									self.numt1[1]=numt#列表第2格记录"数1"串
									self.numt1id[1]=1#标记"数1"
								else:
									self.numt1[3]=numt#列表第4格记录"数2"串
									self.numt1id[3]=1#标记"数2"
							elif(nct==founds) :#运算符时
#								print("\n\t分支2-2-3中运算串numtt：",numtt)						
								if(numtt==symb):#判断是"运算串"
#									print("\n\t分支2-2-3-1是运算串！")						
									if(self.numt1id[2]==0):#“运算串”栈空时
#										print("\n\t分支2-2-3-1-1运算串空 ，压栈")						
										self.numt1[2]=numtt#压栈列表第2格
										self.numt1id[2]=1#标记有“运算串”
									else:#“运算串”满时,压入后串栈
#										print("\n\t分支2-2-3-1-1运算串满，压入后串退出！")						
										self.numt1[4]=lstr[nct-1:]#列表第5格记录后串
										self.numt1id[4]=1#标记有“后串”
										nct=xlen#退出
								else:#判断非"运算串"
#									print("\n\t分支2-2-3-2非运算串！")						
									if(self.numt1id[0]==0):#“前串”栈空时，压栈
										self.numt1[0]=numtt#列表第3格记录“前串”
										self.numt1id[0]=1#标记有“前串”
							elif(nct>founds+slen):
#								print("\n\t分支2-2-４中运算串后numtt：",numtt)						
								if(self.numt1id[3]==0) :#运算符后时，检查“数２串”栈
									if(self.IsNumber(numtt)):
#										print("\n\t分支2-2-4-1中运算串后有数")						
										self.numt1[3]=numtt#压栈列表第2格
										self.numt1[4]=lstr[nct]#压栈列表第5格
										self.numt1id[3]=1#标记有“运算串”
										self.numt1id[4]=1#标记有“后串”
									else:	
#										print("\n\t分支2-2-4-2中运算串后无数")						
										self.numt1[4]=lstr[nct-len(numtt)]#压栈列表第5格
										self.numt1id[4]=1#标记有“后串”
								break	
	
#				print("\n字串栈：",self.numt1)
#				print("\n字串栈标记：",self.numt1id)
								
				nct+=1
				strt = strnl
				statet =state 

# 221 33 (3085)

	def IsNumber(self,localstr):#检测字串是否实数
#		print("进入IsNumber",localstr)
		lens=len(localstr)
		i1=0
		state=0
		while(i1<lens):
			if(i1==0):
				if (localstr[i1].isdigit( )or (localstr[i1] == '.') or #字串是数字？
					(localstr[i1] == '-')or(localstr[i1]=='+')):
					state+=0
#					print(i1)
				else:
					state+=1
#					print("state=",state)
			else :
				if((localstr[i1] == 'e')or(localstr[i1] == 'E')or (localstr[i1] == '.')or 			localstr[i1].isdigit( )):#科学计数
					state+=0
#					print(i1)
					#continue
				else:
					state+=1
#					print("state=",state)
			
			i1+=1
		if state>0:
#			print("IsNumber state=",state)
			justnumber=False
		else: 
#			print("IsNumber state=",state)
			justnumber=True
		return justnumber

# 33 16

	def handle(self):
#		self.mystr=self.ui.lineEdit_2.text()
		i=self.OnOpNumber()#1016
		self.mystr=self.model.item(i).index().data()
#		print("self.mystr=",self.mystr)
		numberp=self.IsNumber(self.mystr)
		if(numberp):	
			self.FirstLine(self.mystr)
#			self.ui.lineEdit_3.setText(self.mystr)#1014
#			print("numberp=",numberp)
		else:
#			print("numberp=",numberp)
			self.AltStr(self.mystr,-1,1)
#			self.strcacu(self.mystr)

# 16 37 (3341)
	
	def floatfmt(self,lstr):#获取浮点小数位
		#print("检测字串：",lstr,"的小数位数->")
		ll=len(lstr)
		i0=lstr.find('.',0)
		imax=0
		if(i0>=0):
			#print("第",i0,"位为小数点.")
			#imax=0
			while (i0>=0):
				i1=lstr.find('.',i0+1)
				#print("搜索.至第",i1,"位")
				if(i1>i0):
					it=0
					for i in range(i0,i1):
						if(lstr[i+1].isdigit()):
							#print(lstr[i+1])
							it+=1
							if(it>imax):
								imax=it
						else:
							it=0
				else:
					it=0
					for i in range(i0,ll):
						if(i<ll-1):
							if(lstr[i+1].isdigit()):
								#print(lstr[i+1])
								it+=1
								if(it>imax):
									imax=it
							else:
								it=0
				i0=i1
		#print("字串：",lstr,"的小数位数为：",imax)
		return imax

# 37 7 (3403)

if __name__ == '__main__':  #主程序
      
	app = QApplication(sys.argv)
	w=MindWay()
	app.exec_()

# 7 0

