#!/usr/bin/python3 #0 3
# -*- coding:utf-8 -*-
#author: Jacky.Shi distribute under General Public License v3 http://www.gnu.org/licenses/quick-guide-gplv3.html
#E-mail: 625052847@qq.com 欢迎ＱＱ打赏，留下QQ号方便邮件收获更新信息
''' 3 5 (0 0 0 10)

标准构架
功能方法（函数）


# 5 9 (0 0 80 4913 95 131 137)

模块导入 from import
主程序			
类声明 class MindWay(QDialog)
初始化模式 __init__(self)
界面初始化 initMindWay(self)



# 9 10 (6 0 0 19 31 43 56)

界面操作方法
文件操作方法
计算相关方法
分页相关方法
分页格式方法




# 10 18 (0 0 3750 3718 3565 3535 3528 3513 3470 3401 3394 3442 3350 3342 3103 2856 2741 2317)

显示下栏文件 slot_btn3_openFile
显示上栏文件 slot_btn_openFile(self)
表项响应 ViewOp(self)
获取最新勾选的行号 JustCheckedNumber(self)
顶行更新 FirstLine(self,myStr)
顶显点选行或结果 CopyText(self)
编辑框显示摘录displayextract(self)
删除表显项 DelItemView(self,lnum)
删除点选项 DelItem(self)
手动摘录 Extract(self)
顶行添至点选行后 AddItemView(self,lnum,lstr)
点选行后增加行 AddItem(self)
列表搜索 SearchRow(self,n,FullStep,ss)
列表搜索响应 SearchLow(self)
文件及列表搜索响应 SearchUp(self)
记录点选表项 OnOpNumber(self)v0.94重改为多选项

# 18 11 (11 0 3688 3669 3631 3577 2857 2574 2378)

本页列表更新进文件 UpListtoFile(self,mylist,lpath)
整列表转文件	WListtoFile(self,mylist,lpath)
行更新进文件 WLinetoFile(self,llist,lpath,lnum)
库文件操作 slot_btn_chooseFile(self)
文件搜索 SearchFile(self,lpath,ss)
文件打开准备 myfileopen(self,slecstr,n)
撤消一步 Undo(self)



# 11 11 (30 0 3748 4508 3991 4835 4745 814 856)

分层拆解括号串 AltStr(self,slecstr,digit_num,expbnow)
字串数、符分拆至五位列表	ArrangStr(self,lstr,symb)
算式串计算转化 strcacu(self,mystr)
获取浮点小数位 floatfmt (self,lstr)
检测字串是否实数 IsNumber(self,localstr)
分离出表格数字 PickNum(self,string)
确定表项 PickList(self,string,expbnow)



# 11 12 (42 0 2534 2445 2309 2237 1940 1860 1725 1684)

判断括号成对 Listp(self,localstr)
索引摘录显示 EIDisp(self)
索引摘录 EIndex(self)
配对分割字串 psplit(self,string,p1,p2)
注释摘录 AutoE(self,string)
分页显示 ExpView(self,top,bot)
分页前跳 forward(self)
分页回跳 backward(self)



# 12 12 (54 0 1572 703 650 485 466 350 145)

@调出弹出框 PopList(self,string,expbnow)
格式文件操作 FFOpen(self)
新建段落格式 PFormat(self)
增配段落 APForm(self)
数字括号项位 DLFmt(self,datastr)
链接格式编辑 JFormat(self)
增删行格式调整 PJCheck(self)


'''

# 12 14 (77)

#模块导入
#from MWsp098 import *  #pyuic5 -o MWsp098.py MWsp098.ui ui文件转换py文件

from PyQt5.uic import loadUi #直接导用ui文件
from tempfile import TemporaryFile,NamedTemporaryFile
import sys,math,random  
from PyQt5 import QtWidgets    #导入相应的包
from PyQt5.QtWidgets import QMessageBox #导入弹出框v0.62
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QInputDialog, QLineEdit, QDialog,QApplication,QFileDialog
import sys, os

# 14 35 (90)
class MindWay(QDialog):#类声明
	fileName_choose=""#全局变量
	Ignore=0 #兼容如意软件变量，此版因为考虑python及C等编程语言模式，数字括号设为第2，3位，如意是第1，2位
	PicSize=600
	FormatShow=False
	FFname=""
	NOpIdx=[]#v0.94恢复
	ViewList=[]
	AutoMode=False
	Expdic={}
	ExpMode=False
	RedoList=[]
	Expitem=-1
	Expbnow=0
	Expfnow=0
	Expbackstep=0
	Expforestep=0
	FullStep=0
	lViewList=0
	MyOutput=""
	CheckedRowNuber=[]
	JustNum=-1
	mystr=""
	PosFound=-1
	numt1=["","","","",""]
	numt1id=[0,0,0,0,0]
	fmt=3
	PMark='♢'
	JMark='♡'
	promptstr1="特殊字符：☯图片⌇续行♢分页♡链接"
	prompstr="***多文件搜索,逻辑摘录***本页为文件目录页，点中下边文件名，再点上方[上栏]按钮进入内容页，点下方[下栏]按钮，在下栏打开该文件。多文件搜索请在本页操作，双击本行,输入搜索关键字；或点[v]将粘贴点中行内容；多条件关键字由';'分隔，多内容由空格或'、'分隔，精确数字匹配在第一个字输入'｀'。点中本行后，可勾选整页或(第2次)消勾；勾选进行摘录；点[计算]按钮计算点中行算式，结果显示在本行；点[文库]按钮可增加文件。本软件是自由软件，遵循GPL v3.0许可，见http://www.gnu.org/licenses/quick-guide-gplv3.html，您可以发扬自由而再发布（包括要求有偿），但没有担保。"
	OftenFiles="oftenfiles.set"#库文件名
	FruitFile="Fruit.txt"#搜索结果文件名
	IndexFile="Fruit.idx"#搜索结果索引文件名

# 35 5 (105)

	def __init__(self):#初始化模式
		QDialog.__init__(self)
		self.initMindWay()

# 5 69 (141)
		
	def initMindWay(self):#界面初始化
		self.cwd = os.getcwd() # 获取当前程序文件位置
#		self.resize(1000,750)   # 设置窗体大小

#		self.ui = Ui_MainWindow()
#		self.ui.setupUi(self) #前两行调入后缀为py的界面与下行效果一致

		self.ui = loadUi('MWsp098.ui')#调入对话框界面

		#self.ui.listView.setFixedSize(700,400)

		self.ui.toolButton_1.setFixedSize(20,100)
		self.ui.toolButton_2.setFixedSize(40,20)
		self.ui.toolButton_3.setFixedSize(220,20)
		self.ui.toolButton_4.setFixedSize(220,20)
		self.ui.toolButton_5.setFixedSize(220,20)
		self.ui.toolButton_6.setFixedSize(40,20)

		self.ui.toolButton_7.setFixedSize(20,100)
		self.ui.toolButton_8.setFixedSize(40,20)
		#self.ui.toolButton_9.setToolTip("定位文件")
		self.ui.toolButton_9.setFixedSize(220,20)
		self.ui.toolButton_10.setFixedSize(220,20)
		#self.ui.toolButton_11.setToolTip("打开文件")
		self.ui.toolButton_11.setFixedSize(220,20)
		#self.ui.toolButton_12.setToolTip("计算")
		self.ui.toolButton_12.setFixedSize(40,20)

		self.model = QStandardItemModel()
		self.model2 = QStandardItemModel()
		self.ui.listView.clicked.connect(self.ViewOp)

		self.ui.toolButton_9.clicked.connect(self.slot_btn_chooseFile)#选择文件

		self.ui.toolButton_10.clicked.connect(self.AddItem)#增加项

		self.ui.toolButton_4.clicked.connect(self.DelItem)#删除项

		self.ui.toolButton_11.clicked.connect(self.slot_btn_openFile)#打开文件
		self.ui.toolButton_3.clicked.connect(self.slot_btn3_openFile)#打开下部文件

		self.ui.toolButton_6.clicked.connect(self.SearchUp)#搜索上栏字符
		self.ui.toolButton_5.clicked.connect(self.SearchLow)#搜索下栏字符

		self.ui.toolButton_8.clicked.connect(self.CopyText)#V

		self.ui.toolButton_12.clicked.connect(self.handle)#计算

		self.ui.toolButton_24.clicked.connect(self.Undo)#撤消一步摘录索引
		self.ui.toolButton_7.clicked.connect(self.backward)#往回浏览
		self.ui.toolButton_25.clicked.connect(self.Redo)#恢复一步撤消

		self.ui.toolButton.clicked.connect(self.EIndex)#本页摘录索引
		self.ui.toolButton_1.clicked.connect(self.forward)#往前浏览
		self.ui.toolButton_2.clicked.connect(self.Extract)#摘录显示DelItemView

		self.ui.toolButton_14.clicked.connect(self.RunNow)#右栏文件操作
		self.ui.toolButton_16.clicked.connect(self.FFOpen)#右栏文件操作
		self.ui.toolButton_19.clicked.connect(self.PJCheck)#调整增删行

		self.ui.toolButton_17.clicked.connect(self.PFormat)#新建段落格式
		self.ui.toolButton_15.clicked.connect(self.APForm)#增配段落格式
		self.ui.toolButton_18.clicked.connect(self.JFormat)#新建跳跃格式

		self.ui.toolButton_13.clicked.connect(QCoreApplication.instance().quit)#退出
		self.myfileopen("",2)
		self.myfileopen(self.OftenFiles,1)

# 69 17 (70)
	def RunNow(self):
		bnowstr=self.model.item(0).index().data()#获取listView的0行字符
		if(self.Listp(bnowstr)):#初步检查有无浏览跳转链接项
			plist=self.psplit(bnowstr,"(",")")
			liste=plist[-1][1:-1].split()#提取最后一个括号项字符
			if(not liste[0].isdigit()):#括号项首项为数字，表示有链接
				stra=plist[-1][1:-1]
			if(len(plist)==3):#包括了浏览链接和程序表
				#提取倒数第2个括号项字符为程序表
				stra=plist[-2][1:-1]#self.psplit()[1:]
	#			print("\n\t\t\tautofore前跳后程序表共3项，摘引串为：",stra)
			if(len(stra)>0):
				self.AutoE(stra)
		else:
			print("请检查格式，可能括号不匹配错误")


# 17 204 (140)

	def PJCheck (self):#增删行格式调整
		#self.JMark='♡'
		data=self.ui.textEdit.toPlainText()#读取编辑框中字符
		i1=len(data)
		stepf=stepb=0
		ifmt=oldfmt=0
		i3 = 0
		in1 =0#起点行
		in2=0#终点行
		ih=0	
		Peditp=False#调整段格式
		Elist=Elinl=[]
		if(i1>0):
			self.DLFmt(data)
			mylist=data.split('\n')
			lm=len(mylist)
			for i in range(lm):
				#print("浏览至行",i)
				if(i==ifmt):#只对格式行检索
					#print("检索",i,"格式行：",mylist[i])
					linelist=mylist[i].split()
					ll=len(linelist)
					if(ll>=self.Ignore+3):#初步判断格式行
						if(linelist[self.Ignore+2]!='0'):#前跳格式不为0
							if(ifmt+1+int(linelist[self.Ignore+2])<=lm):
								ifmt=ifmt+1+int(linelist[self.Ignore+2])#准备下一步要检索的行距
								oldfmt+=1+int(linelist[self.Ignore+2])
								#print("原行号：",oldfmt,"预计下一个格式行为:",ifmt)
								linelist1=mylist[ifmt].split()
							if(len(linelist1)>=self.Ignore+2):#预读行为格式行
								if(linelist1[self.Ignore+1]!=linelist[self.Ignore+2]) or (not linelist1[self.Ignore+2].isdigit()):
									Peditp=True
							else:
								Peditp=True
							if Peditp:
				#				print(ifmt,"行检测不符合数字括号格式，开始逐行扫描定位格式行")
								for ir in range(i+2,lm):#从下面第2行开始逐行检验
				#					print("\t",ir,"行：",mylist[ir])
									if(len(mylist[ir].split())>=self.Ignore+2):
										if(mylist[ir].split()[self.Ignore+1]==linelist[self.Ignore+2]) and (mylist[ir].split()[self.Ignore+2].isdigit()):
											ifmt=ir
											stepf=ir-i-1#计算步长
											dlta=stepf-int(linelist[self.Ignore+2])#计算行增删偏差
											ito=i+int(linelist[self.Ignore+2])+1
											Elinl=[i,ifmt,oldfmt-int(linelist[self.Ignore+2])-1,oldfmt,int(linelist[self.Ignore+1]),int(linelist[self.Ignore+2]),dlta]
											Elist.append(Elinl)#将误差存入编辑列表
											ss=""
											for i4 in range(self.Ignore+2):
												ss+=linelist[i4]+" "
				#							print(i,"上格式行前缀字串",ss)
											ss=ss+str(stepf)#ss=linelist[0]+" "
											if(ll>=self.Ignore+3):
												for i4 in range(self.Ignore+3,ll):
													ss+=" "+linelist[i4]
											#print(i,"格式行调整后",ss)
											#if(ll>2):
											#	for ir1 in range(2,ll):
											#		ss=ss+" "+linelist[ir1]
											mylist[i]=ss
				#							print("\t上格式",i,"行更新为：",mylist[i])
										
											linelist=mylist[ifmt].split()
											ll=len(linelist)
											ss=""
											for i4 in range(self.Ignore+1):
												ss+=linelist[i4]+" "
											#print(ifmt,"下格式行前缀字串",ss)
											ss=ss+str(stepf)#ss=linelist[0]+" "
											if(ll>=self.Ignore+2):
												for i4 in range(self.Ignore+2,ll):
													ss+=" "+linelist[i4]
											#print("\t下格式",ifmt,"行调整为",ss)
											#ss=str(stepf)+" "+linelist[self.Ignore+2]
											#if(ll>2):
											#	for ir1 in range(2,ll):
											#		ss=ss+" "+linelist[ir1]

											mylist[ifmt]=ss
				#							print("\t下格式行",ifmt,"更新为：",mylist[ifmt],"\n\n")
											Peditp=False
											break
						else:#前跳格式不为0，文件已至尾部
				#			print("\t前跳值为0，文件已至尾部")
							break

			#显示到textedit
			self.ui.textEdit.clear()
			for data in mylist:
				self.ui.textEdit.append(data)

			#调整链接格式
	#		print("\n===调整链接格式===\n")
			#print(Elist)
			ifmt=oldfmt=0
			le1=len(Elist)
			for i in range(lm):
				#print("\t\t调整至行",i,)
				if(i==ifmt):#只对格式行检索
#					print("\n检索",i,"格式行：",mylist[i])
					linelist=mylist[i].split()
					ll=len(linelist)
					if(ll>=self.Ignore+3):#初步判断格式行
						if(i==0):#0行特殊判断
							stepb=int(linelist[self.Ignore+1][-1])
						else:
							stepb=int(linelist[self.Ignore+1])
						stepf=int(linelist[self.Ignore+2])
						if(linelist[self.Ignore+2]!='0'):#前跳格式不为0
							if(ifmt+1+int(linelist[self.Ignore+2])<=lm):
								ifmt=ifmt+1+int(linelist[self.Ignore+2])#准备下一步要检索的行距
								#print("\t\t\t预计下一个格式行为:",ifmt)
						if(self.Listp(mylist[i])):#检查有无表（链接）
							jlstr=self.psplit(mylist[i],'(',')')[-1]
							lenstr=len(jlstr)
							jlist=jlstr[1:-1].split()#获取最末列表
							lj=len(jlist)
							editp=False
							if(jlist[0].isdigit()):#当表首项为数字时，判断为数字括号链接格式
								for i1 in range(lj):#检查各链接值是否有非0
									if(int(jlist[i1])>0):editp=True
								if editp:
									dltab=0
									dltaf=0
									for i3 in range(le1):
										if(i<=Elist[i3][1]):
											dltab=Elist[i3][2]-Elist[i3][0]#v0.966+=
							#				print("\t\t遍历各调整段确定回跳名义偏差dltab",dltab)
											break#v0.966
	
										elif(i3==le1-1):
											if(i>Elist[i3][1]):
												dltab=Elist[i3][3]-Elist[i3][1]#v0.966
	
									for i3 in range(le1):
										if(i>=Elist[i3][0]):
											dltaf=Elist[i3][3]-Elist[i3][1]
							#				print("\t\t遍历各调整段确定前跳名义偏差dltaf",dltaf)
							#		print("\t",i,"行名义格式增补： 回跳dltab",dltab,"行,前跳dltaf",dltaf,"行")
									for i1 in range(lj):#检查各链接值是否与调整段交叉
										if(i1==0):
											i4=int(jlist[i1])
											i3=i4
							#				print("\t\t回跳行数[",i3,"]")
											if(i3>0):
												for i2 in range(le1):#遍历各调整段
													#检查回跳行是否至本行名义格式(未调整前格式)前=
													stepb1=stepb+1
													if(stepb==0):stepb1=0
													njumpb=i+dltab-stepb1
							#						print("\t回跳点计算：当前行",i,"+名义格式增补回值",dltab,"-回步长",stepb1,"-回跳步长",i3)
							#						print("\t\t结果=",njumpb-i3,"<=调整前原回步点",Elist[i2][2],"?(关键因素1)")
							#						print("\t回跳点计算：当前行",i,"+名义格式增补回值",dltab,"-回步长",stepb1)
							#						print("\t\t结果=",njumpb,">=调整前原回步点",Elist[i2][3],"?(关键因素2)")
													if ((njumpb-i3) <= Elist[i2][2]) and (njumpb >= Elist[i2][3]):
													#if (njumpb-i3 <= Elist[i2][2]) and (njumpb >= Elist[i2][3]):#v0.966
							#							print(Elist)
							#							print(i,"行[",mylist[i],"]行回跳跃链接跨越",Elist[i2][0],"至",Elist[i2][1],"行","调整",Elist[i2][6])
														i4=i4+Elist[i2][6]
							#							print("\t\t\t回跳格式调整值",i4)
												ss=str(i4)
							#					print("\t\t\t0项",ss,"\n")
											else:
												ss="0"
	
										else:
											i4=int(jlist[i1])
											i3=i4
							#				print("\t\t前跳",i3,"行")
											if(i3>0):
												for i2 in range(le1):#遍历各调整段
													#检查前跳行是否至本行名义格式(未调整前格式)后
													njumpf=i+dltaf+stepf+1
#													print("\t前跳点计算：当前行",i,"+名义格式增补前值",dltaf,"+前步长",stepf+1)#v0.966,"+前跳步长",i3
#													print("\t\t结果=",njumpf,">调整前原前步",Elist[i2][3],"?(关键因素)")
#													print("\t前跳点计算：当前行",i,"+名义格式增补前值",dltaf,"+前步长",stepf+1,"+前跳步长",i3)
#													print("\t\t结果=",njumpf+i3,">=调整前原前步",Elist[i2][3],"?(关键因素)")
													#print("\t\t回跳点计算：当前行",i,"+名义格式增补前值",dltaf,"+前步长",stepf+1,"=",njumpf)
													#print("\t\t\t结果=",njumpf,"<=调整前原回步",Elist[i2][2],"?(无关因素)\n")
													#if ((njumpf+i3) >= Elist[i2][3]) and (njumpf <= Elist[i2][2]):#v0.966
													if (njumpf < Elist[i2][3]) and ((njumpf+i3) >= Elist[i2][3]):
										#				print(Elist)
#														print(i,"行[",mylist[i],"]前跳跃链接跨越原",Elist[i2][2],"至",Elist[i2][3],"行","调整",Elist[i2][6])
														i4=i4+Elist[i2][6]
#														print("\t\t\t后跳格式调整值",i4)
												ss+=" "+str(i4)
										#		print("\t\t调整后",ss)
											else:
												ss+=" 0"
									mylist[i]=mylist[i][:-lenstr]+'('+ss+')'
							#		print("\t",i,"行调整后:[",mylist[i],"]\n")
			#显示到textedit
#			fh2=TemporaryFile('w+t',encoding='utf-8' )
#			for data in mylist:
#				fh2.write(data+"\n")
#			fh2.seek(0)			
#			data=fh2.read()
#			fh2.close()
#			self.ui.textEdit.setPlainText(data)

			self.ui.textEdit.clear()
			for data in mylist:
				self.ui.textEdit.append(data)

# 204 115 (158)

	def JFormat (self):#链接格式编辑
		#self.JMark='♡'
		data=self.ui.textEdit.toPlainText()#读取编辑框中字符
		i1=len(data)
		stepf=0
		stepb=0
		ifmt=0
		i3 = 0
		in1 =0#起点行
		in2=0#终点行
		ih=0	
		if(i1>0):
			self.DLFmt(data)
			mylist=data.split('\n')
			lm=len(mylist)

			for i in range(lm):
				#print("运行行",i)
				if(i==ifmt):#只对格式行检索
					#print("检索",i,"格式行：",mylist[i])
					linelist=mylist[i].split()
					if(len(linelist)>=self.Ignore+3):#初步判断格式行
						if(linelist[self.Ignore+2]!='0'):
							ifmt+=1+int(linelist[self.Ignore+2])#准备下一步要检索的行距
							#print("\t计算下一个格式行为:",ifmt)
						else:
							#print("\t前跳值为0")
							break
						if(self.Listp(mylist[i])):#有无括号格式
							jumpstr=self.psplit(mylist[i],'(',')')[-1]
							#print("\t\t发现括号字串",jumpstr)#最后一个括号项为跳跃格式
							if(jumpstr.find(self.JMark)>=0):#整体浏览有链接标记
								jumplist=jumpstr[1:-1].split()
								i2=0
								for jumpit in jumplist:#搜索标记符，确定前半标记
									if(jumpit.find(self.JMark)<0):#子项没有发现链接标记
										if(i2==0):
											strt=jumpit
										else:
											strt=strt+" "+jumpit
									else:	#子项有发现链接标记
										markstr=jumpit
										stepf=int(linelist[self.Ignore+2])
										ifmt1=i+stepf+1
										for i3 in range(i+stepf+1,lm):#搜索配对标记，直到发现替换
											if(i3==ifmt1):#只对格式行检索
												#print("\t\t\t配对标记检索",i3,"格式行：",mylist[i3])
												linelist1=mylist[i3].split()
												if(len(linelist1)>=self.Ignore+3):#初步判断格式行
													if(linelist1[self.Ignore+2]!='0'):
														ifmt1+=1+int(linelist1[self.Ignore+2])
														#print("\t\t寻找配对链接计算下一个格式行为:",ifmt1)
													f3=mylist[i3].find(markstr)
													if(f3>=0):
														stepb=int(linelist1[self.Ignore+1])
														ifstr=str(i3-(i+stepf+1))
														ibstr=str(i3-(stepb+1)-i)
														strt=strt+" "+ifstr
														#print(i3,"行配对链接标记：",markstr,"前跳",ifstr,"回跳",ibstr,"跳跃格式",strt)
														if(self.Listp(mylist[i3])):
														#	print(i3,"行有括号，准备替换")
															jumpstr1=self.psplit(mylist[i3],'(',')')[-1][1:-1]
															jumplist1=jumpstr1.split()
															i4=0
															for jumpit1 in jumplist1:
																if(jumpit1!=markstr):
																	if(i4==0):
																		strt1=jumpit1
																	else:
																		strt1=strt1+" "+jumpit1
																else:
																	if(i4==0):
																		strt1=ibstr
																	else:
																		strt1=strt1+" "+ibstr
																i4+=1
															if(len(self.psplit(mylist[i3],'(',')'))==2):
																mylist[i3]=self.psplit(mylist[i3],'(',')')[0]+'('+strt1+')'#更新后半表项
														#		print(i3,"行跳跃格式替换更新为：",mylist[i3])
															else:
																mylist[i3]=self.psplit(mylist[i3],'(',')')[0]+self.psplit(mylist[i3],'(',')')[1]+'('+strt1+')'#更新后半表项
														#		print(i3,"行跳跃格式替换更新为：",mylist[i3])

														else:#无括号格式时丢弃
															if(f3+1+len(markstr)==len(mylist[i3])):#串末
																strt1=mylist[i3][:f3-1]
															else:#非串末
																strt1=mylist[i3][:f3-1]+mylist[i3][f3+len(markstr):]
															mylist[i3]=strt1#更新表项
														#	print(i3,"行丢弃跳跃标记更新为：",mylist[i3])
														break
											i3+=1
									i2+=1
								if(len(self.psplit(mylist[i],'(',')'))==2):
									mylist[i]=self.psplit(mylist[i],'(',')')[0]+'('+strt+')'#更新前半表项
								#	print(i,"行跳跃格式替换更新为：",mylist[i])
								else:
									mylist[i]=self.psplit(mylist[i],'(',')')[0]+self.psplit(mylist[i],'(',')')[1]+'('+strt+')'#更新前半表项
								#	print(i,"行跳跃格式替换更新为：",mylist[i])
					else:
						print("格式行错误")

			self.ui.textEdit.clear()
			for data in mylist:
				self.ui.textEdit.append(data)

#			fh2=TemporaryFile('w+t',encoding='utf-8' )
#			for data in mylist:
#				fh2.write(data+"\n")
#			fh2.seek(0)			
#			data=fh2.read()
#			fh2.close()
#			self.ui.textEdit.setPlainText(data)

# 115 18 (363)
	def DLFmt (self,datastr):#数字括号前缀项位数，设定全局变量Ignore
		#print("进入数字括号项数判定模块")
		mylist=datastr.split('\n')
		lie=mylist[0].split()
		ll=len(lie)
		if(ll>=2):
		#	print("首项转成列表：\t",lie)
			i1=0
			for lstr in lie:#判断数字括号格式项序号
				if(i1<=ll-1):
		#			print("列项末符：",lstr[-1])
					if(lstr[-1]=='0'):
						if(lie[i1+1].isdigit()):
							self.Ignore=i1-1
#							print("格式项self.Ignore=",self.Ignore)
							break
				i1+=1

# 18 164 (479)
	def APForm (self):#增配段落格式，有链接时更新
		#self.PMark='♢'
		#self.PJCheck()#先调用格式增删检查，确保现有格式行准确
		data=self.ui.textEdit.toPlainText()#读取编辑框中字符
		i1=len(data)
		stepf=0
		stepb=0
		ifmt=0
		i3 = 0
		in1 =0#起点行
		in2=0#终点行
		ih=0	
		if(i1>0):
			self.DLFmt(data)
			mylist=data.split('\n')
			lm=len(mylist)
			loclist=[]
			for i in range(lm):
				#print("\t增配运行行",i)
				pi1=mylist[i].find(self.PMark)
				if(pi1>=0):#找到段落标记
			#		print("\t增配检索",i,"行[",mylist[i],"]发现段落标记：",pi1)
					in1=i
					mpstr=mylist[i][:pi1]
					mkstr=mylist[i][pi1:pi1+3]
					mhstr=mylist[i][pi1+3:]
			#		print("\t分拆为前串[",mpstr,"]中串[",mkstr,"]后串[",mhstr,"]")
					foundp=False
					for i3 in range(i+1,lm):#搜索配对标记，直到发现替换
						pi2=mylist[i3].find(mkstr)
						if(pi2>=0):
							foundp=True
							in2=i3
							step=in2-in1-1
			#				print(i3,"行[",mkstr,"]",pi2,"位发现配对链接标记,行距步长",step)
							break
					mylist[i]=mpstr+" "+str(step)+" "+mhstr
			#		print(i,"段前格式行[",mylist[i],"]")
					loclist.append(i)
					if(pi2==0):
						mpstr=""
						mkstr=mylist[i3][pi2:pi2+3]
						if(len(mylist[i3])>=pi2+4):
							mhstr=mylist[i3][pi2+4:]
						else:
							mhstr=""
					else:
						mpstr=mylist[i3][:pi2]
						mkstr=mylist[i3][pi2:pi2+3]
						if(len(mylist[i3])>=pi2+4):
							mhstr=mylist[i3][pi2+4:]
						else:
							mhstr=""
			#		print("\t",i3,"行",pi2,"位分拆为前串[",mpstr,"]中串[",mkstr,"]后串[",mhstr,"]")
					if(pi2==0):
						mylist[i3]=str(step)+" "+mhstr
					else:
						mylist[i3]=mpstr+" "+str(step)+" "+mhstr
			#		print(i3,"段后格式行[",mylist[i3],"]")

	#		print("\n===检查调整链接格式===\n")
			ifmt=0
			oldfmt=0
			Peditp=False
			Linkp=False
			for i in range(lm):
				#print("浏览至行",i)
				if(i==ifmt):#只对格式行检索
					#print("检索",i,"格式行：",mylist[i])
					linelist=mylist[i].split()
					ll=len(linelist)
					if(ll>=self.Ignore+3):#初步判断格式行
						if(linelist[self.Ignore+2]!='0'):#前跳格式不为0
							if(ifmt+1+int(linelist[self.Ignore+2])<=lm):
								ifmt=ifmt+1+int(linelist[self.Ignore+2])#准备下一步要检索的行距
								oldfmt+=1+int(linelist[self.Ignore+2])
					#			print("前跳步长：",oldfmt,"预计下一个格式行为:",ifmt)
								linelist1=mylist[ifmt].split()
							if(len(linelist1)>=self.Ignore+2):#预读行为格式行
								if(linelist1[self.Ignore+1]!=linelist[self.Ignore+2]) or (not linelist1[self.Ignore+2].isdigit()):
									Peditp=True
							else:
								Peditp=True
							if Peditp:
								jpstr=""
								if(self.Listp(mylist[i])):#
					#				print(i,"行检测到括号对，初判为链接格式,提取括号对分割的最后一项")
									jlstr=self.psplit(mylist[i].split(),'(',')')[-1]
									jlist=jlstr[1:-1].split()#获取最末列表
									if(jlist[0].isdigit()):#当表首项为数字时，判断为数字括号链接格式
					#					print(i,"行检测到括号内数字，链接格式确认")
										Linkp=True
										lj=len(jlstr)
										j0=len(mylist[i].split())-lj-1
										i0=mylist[i].find(linelist[self.Ignore+2])+len(linelist[self.Ignore+2])
										if(j0>i0):
											jpstr=mylist[i][i0:j0]
											lj=len(jlist)
					#						print(i,"行链接格式前字串[",jpstr,"]分割为",lj,"项表",jlist)
					#			print(ifmt,"行检测不符合数字括号格式，开始逐行扫描定位格式行")
								for ir in range(i+2,lm):#从下面第2行开始逐行检验
									#print("\t",ir,"行：",mylist[ir])
									if(len(mylist[ir].split())>=self.Ignore+2):
										if(mylist[ir].split()[self.Ignore+1]==linelist[self.Ignore+2]) and (mylist[ir].split()[self.Ignore+2].isdigit()):
											ifmt=ir#下格式行号
											linelist1=mylist[ifmt].split()#下格式列表
											ll1=len(linelist1)
											stepf=ir-i-1#计算步长
											dlta=int(linelist[self.Ignore+2])-stepf#计算行增删偏差
					#						print(i,"上格式行调整前为[",mylist[i])
											ss=""
											for i4 in range(self.Ignore+2):
												ss+=linelist[i4]+" "
											#print("\t",i,"上格式行前缀字串",ss)
											ss=ss+str(stepf)
											if(Linkp):
												ss+=jpstr+" ("
												if(lj==3):
													i4str=str(int(jlist[2])+dlta)
													ss+=i4str+")"
												elif(lj>3):
													i4str=str(int(jlist[2])+dlta)
													ss+=i4str
													for i4 in range(4,lj):
														i4str=str(int(jlist[i4])+dlta)
														ss+=" "+i4str
													ss+=")"
											else:
												if(ll>=self.Ignore+3):
													for i4 in range(self.Ignore+3,ll):
														ss+=" "+linelist[i4]
											#print("\t",i,"上格式行调整后",ss)
											mylist[i]=ss
					#						print("\t",i,"上格式行更新为：",mylist[i])
										
					#						print(ifmt,"下格式行调整前为[",mylist[ifmt])
											ss=""#下格式行调整
											for i4 in range(self.Ignore+1):
												ss+=linelist1[i4]+" "
											#print("\t",i,"下格式行前缀字串",ss)
											ss=ss+str(stepf)
											if(ll1>=self.Ignore+2):
												for i4 in range(self.Ignore+2,ll1):
													ss+=" "+linelist1[i4]
											#print("\t",ifmt,"下格式行调整后",ss)
											mylist[ifmt]=ss
					#						print("\t",ifmt,"下格式行更新为：",mylist[ifmt])
											break
						else:#前跳格式不为0，文件已至尾部
					#		print("\t前跳值为0，文件已至尾部")
							break

			self.ui.textEdit.clear()
			for data in mylist:
				self.ui.textEdit.append(data)

#			fh2=TemporaryFile('w+t',encoding='utf-8' )
#			for data in mylist:
#				fh2.write(data+"\n")
#			fh2.seek(0)			
#			data=fh2.read()
#			fh2.close()
#			self.ui.textEdit.setPlainText(data)

# 164 52 (498)

	def PFormat (self):#段落格式编辑
		#self.PMark='♢'
		data=self.ui.textEdit.toPlainText()#读取编辑框中字符
		i2=-1
		i3 = 0
		in1 =0#起点行
		in2=0#终点行
		ih=0	
		ss=""
		if(len(data)>0):
			ss=self.model.item(0).index().data()#获取listView的0行字符作为格式前缀
			i1=len(data)
			fh2=TemporaryFile('w+t',encoding='utf-8' )
			for i in range(i1):
				#print(data[i],end="")
				if(data[i]!=self.PMark):#检查非标记字符
					if (data[i]=='\n'):#统计行数
						in2+=1#终点行计数
						ih=0#行字符计数供判断是否行首
						#print("in2=",in2)
					
					else:
						ih+=1
					
				else:#检查是标记字符
					#print("in2=",in2)
					if(ih == 0):#标记为行首时
						in2+=1
						fh2.write(ss+str(in1)+" "+str(in2)+"\n")
						fh2.write(data[i2+1:i]+"\n")
						in1=in2
						in2=0
						i2 = i
					
					else :#标记非行首时
						in2+=1
						fh2.write(ss+str(in1)+" "+str(in2+1)+"\n")
						fh2.write(data[i2+1:i]+"\n\n")
						in1=in2+1
						in2=0
						i2 = i
						ih+=1
			fh2.write(ss+str(in1)+" "+str(in2+1)+"\n")
			fh2.write(data[i2+1:i]+"\n\n")
			fh2.write(ss+str(in2+1)+" "+"0\n")
			fh2.seek(0)
			data=fh2.read()
			fh2.close()
			self.ui.textEdit.setPlainText(data)


# 52 40 (663)
	
	def FFOpen (self):#格式文件操作
		filet=self.FFname
		locFname,filetype = QFileDialog.getOpenFileName(self,
			"选择需编辑或更新的文件",self.cwd,# 起始路径 
			"All Files (*);;Setfiles(*.set);;Pthon Files (*.py);;Text Files (*.txt);;向导文件(*.xdf)")
			# 设置文件扩展名过滤,用双分号间隔
		data=self.ui.textEdit.toPlainText()#看编辑框中有没有字符

		if(len(data)==0):#(not filet.strip()):#编辑框无字符，打开文件，准备编辑
			fh=open(locFname,mode='r+t',encoding='UTF-8')
			if fh:
				fh.seek(0)#注意读取文件时候要将文件指针指向第一个
				data=fh.read()
				fh.close()
				mylist = data.split("\n")
				#print("完成打开文件，准备读取->",locFname,"。文件字符:\n",data,"转列表为：\n",mylist)
				for ss in mylist:
					self.ui.textEdit.append(ss)#v0.76
				self.FFname=locFname
		else:#编辑框有字符，看是否已有此文件，准备覆盖更新
			if(locFname==filet):
				reply = QMessageBox.information(self,"文件覆盖提示", 
					"文件："+filet+" 将被更新覆盖，你确定吗？",
					QMessageBox.Yes | QMessageBox.No)  
				if(reply==QMessageBox.Yes):#消息弹出框
					fh=open(locFname,mode='w+t',encoding='UTF-8')
					fh.write(data)
			else:
				reply = QMessageBox.information(self,"文件保存提示",
					"文件["+locFname+"]所作修改将被保存，你确定吗？",
					QMessageBox.Yes | QMessageBox.No)  
				if(reply==QMessageBox.Yes):
					fh=open(locFname,mode='w+t',encoding='UTF-8')
					fh.write(data)
				
			fh.close()
		self.ui.show()
#		self.show()

# 40 43 (592)
	def EngInt(self,string):#工程取整，有小数则+1
	#	print("\n\t进入EngInt方法")
		if(type(eval(string))== float):
			ls=len(string)
			ep0=string.find('.')
			ep1=string.find('e')
			ep2=string.find('E')
			en=0
			fmt=self.floatfmt(string)
			if(ep1>0):
				strlist=string.split('e')
				en=int(string[ep1+1:])
			elif(ep2>0):
				strlist=string.split('E')
				en=int(string[ep2+1:])
			if(en>0):
				if(ep0>0):
					if(fmt>en):
						fmt1=en+ep0#取到个位数
						strt=strlist[0][:fmt1]+'e'+strlist[1]
						if(int(string[fmt1+1])>0):
							strt=str(int(strt)+1)
					else:
						strt=string
			else:
				if(ep0>0):
					if(ep1>2):
						strt=string[:ep0-1]
					else:
						strt=string[0]
	#				print("实数",string,".前符",strt)
					if(fmt>0):
						if(int(string[ep0+1])>0):
							if(strt=='0'):
								strt='1'
							else:
								strt=str(int(strt)+1)
				elif(ep0==0):
					if (int(string[1])>0):
						strt='1'
			return strt


# 43 41 (782)

	def PickNum (self,string):#从数文混杂表项中提取数字
		nlist=[]
		ln=len(string)
		nstr=""
		State=False#数字状态
		Change=False
		for i in range(ln):
			#print("i=",i," ? ",ln)
			if(string[i].isdigit() or string[i]=='.' or (string[i]=='-' and i==0)):
				if not State:
					Change=True
				else:
					Change=False
				State=True
			else:
				if State:
					Change=True
				else:
					Change=False
				State=False
			if Change:
				if(i==0):
					nstr+=string[i]
					if(i==ln-1):
						nlist.append(nstr)
				else:
					nlist.append(nstr)
					nstr=string[i]
			elif(i==ln-1):
					nstr+=string[i]
					nlist.append(nstr)
			else:
				nstr+=string[i]
		rnstr=""
		for nstr1 in nlist:
			if(self.IsNumber(nstr1)):
				rnstr=nstr1
		return nstr1


# 41 741 (826)

	def PickList (self,string,expbnow):#v0.975调整返回列表参数顺序
#确定字符串寻找的行，string不带括号,expbnow本页首行在主列表文件中的位置；
#有问号时，返回归类行(行末:)无?时返回关键字行，多结果时弹出框选择
		print("\n\t进入PickList[",string,"]操作参照行：",expbnow)
		rslist=[]
		ie=int(self.ViewList[expbnow].split()[self.Ignore+2])
		ib=1
		cb=0
		ce=0
		stepl=1
		stepc=1
		prompt=""
		keystr=""
		keyattrstr=""
		kAi=0
		GetAttr=False
		GetStr=False
		GetRow=False
		GetCol=False
		Lessp=False
		lrangp=False
		crangp=False
		Redun=1#默认行冗余号，即取符合条件的第1个值
		#RedunC=1#列冗余号
		#GetRedunL=False
		#GetRedunC=False
		GetRedun=False
		icol=string.find(',')
		#it=string.find('~')
		subper='0'
		if(icol>=0):
			loclist=string.split(',')
			linstr=loclist[0]
			colstr=loclist[1]
			it=linstr.find('~')
			if(it>=0):
				lrangp=True
			it=colstr.find('~')
			if(it>=0):
				crangp=True
			if(linstr.find('#')>=0):#行有#分离出冗余值，更新行字串
				strfix=linstr.split('#')[1]
				linstr=linstr.split('#')[0]
				if(strfix[0]=='-'):
					subper=strfix[1:]
				if(strfix.isdigit()):
					GetRedun=True#GetRedunL
					Redun=int(strfix)
#取之后数代表序号的结果值，比如#3表示有三个结果时取第3个，少于三结果时取最接近于3的结果
#				print("\t\t行字串中发现#符，分离为行字串[",linstr,"]，冗余值[",Redun,"]关键字值下浮[",subper,"]%")
			if(colstr.find('#')>=0):#列有#分离出冗余值，更新列字串
				strfix=colstr.split('#')[1]
				colstr=colstr.split('#')[0]
				if(strfix[0]=='-'):#冗余的负号表示数值下浮的百分数
					subper=strfix[1:]
				if(strfix.isdigit()):
					#GetRedunC=True
					GetRedun=True
					Redun=int(strfix)
				print("\t\t列字串中发现#符，分离为列字串[",colstr,"]，冗余值[",Redun,"]关键字值下浮[",subper,"]%")
			if crangp: #(colstr.find('~')>=0):
				#crangp=True
				if(colstr.find(':')>=0):
					crangstr=colstr.split(':')[0]#列号范围由:分隔
					colstr=colstr.split(':')[1]
				else:
					crangstr=colstr

			if(linstr[0]=='-'):#由,分隔的行值首为-时，列值判断小于等于
				Lessp=True
				if (linstr[1:].isdigit()):
					#v0.967当行为负整数时，取满足小于等于关键字的列值
					linstr=linstr[1:]
					row=int(linstr[1:])
		#			print("行为负数[",linstr,"],取为[",row,"]行，求取列值小于关键字的行号")
			if(linstr.isdigit()):
				row=int(linstr)
				print("\t\t行为正整数",linstr)
				if (not crangp):
					if(colstr.isdigit()):
						colnum=int(colstr)
						lcol=len(self.ViewList[expbnow+int(linstr)].split())
						print("\t\t\t列值为正整数[",colnum,"]时，比较是否小于行[",self.ViewList[expbnow+int(linstr)],"]项数[",lcol,"]")
						if(not GetRedun):#GetRedunC
							if(colnum<lcol):#当列号小于该行列数时，返回列内容
								print("\t\t\t\t行[",linstr,"]、列[",colnum,"均为数字，返回内容",self.ViewList[expbnow+int(linstr)].split()[colnum])
								rslist.append(self.ViewList[expbnow+int(linstr)].split()[colnum])
								rslist.append(str(colnum))
								return rslist
						else:
							print("\t\t\t求取列序号")
							GetCol=True
					elif(colstr[0]=='-'):#由,分隔的列值首为-时，列值判断小于等于
						Lessp=True
						if (colstr[1:].isdigit()):
							#v0.967当列为负整数时，取满足小于等于关键字的列值
							colnum=int(colstr[1:])
							print("\t\t\t列为负数[",colstr,"],取为[",colnum,"]列，求取列值小于关键字的行号")
					elif (self.IsNumber(colstr)):#如果列内容是实数
						GetCol=True
					else:#如果列内容是字符
			#			print("确定",linstr,"行符合条件[",colstr,"]的列号")
						colist=self.ViewList[expbnow+int(linstr)].split()
			#			print(colist)
						lc=0
						for cols in colist:
							print("\t\t\t\t第",lc,"列[",cols,"]")#,end=""
							if(cols.find(colstr)>=0):
								print("\t\t\t发现返回[",lc,"]项:",cols)
								break
								#return str(lc)
							lc+=1
						rslist.append(str(lc))
						rslist.append(cols)
						print("\t\t\t行为正整数，列为字符，搜索返回[列号，内容]表",rslist)
						return rslist
				else:
					GetCol=True
					
			elif (self.IsNumber(linstr)):#如果行内容是实数
				print("\t\t行关键字为实数",linstr)
				GetRow=True
				if (not crangp):
					if(colstr.isdigit()):
						colnum=int(colstr)
					elif(colstr[0]=='-'):#由,分隔的列值首为-时，列值判断小于等于
						Lessp=True
						if (colstr[1:].isdigit()):
							colnum=int(colstr[1:])
							print("\t\t\t列为负数[",colstr,"],取为[",colnum,"]列，求取列值小于关键字的行号")
			else:#如果行内容是字符
				print("\t\t行关键字为变量运算字符",linstr)
				GetRow=True
				if (not crangp):
					if(colstr.isdigit()):
						if(int(colstr)>=0):#当列为正数时，取满足大于等于关键字的列值
							colnum=int(colstr)
	
					elif(colstr[0]=='-'):
						Lessp=True
						if (colstr[1:].isdigit()):
							#v0.967当列为负整数时，取满足小于等于关键字的列值
							colnum=int(colstr[1:])
			#				print("列为负数[",colstr,"],取为[",colnum,"]列，求取列值小于关键字的行号")
					elif (self.IsNumber(colstr)):#如果列内容是实数
						GetCol=True
					else:#如果列内容是字符
						print("\t\t\t列号应为整数，或为整数的变量，负整数表示≤该列，请修正")

			if GetCol:
				print("\t确定",linstr,"行符合列值大于等于列字符数值[",colstr,"]的列号")#行为固定正整数时，只返回一个列值
				fcol=float(colstr)
				colist=self.ViewList[expbnow+row].split()
				formp=False
				if(colstr.isdigit()):#当为正整数时，取该数行的算式
					print("\t\t列值关键字",colstr,"为正整数，检测格式行[",self.ViewList[expbnow],"]能否调出相应行")
					print("\t\t格式行前步长为[",self.ViewList[expbnow].split()[self.Ignore+2],"]")
					if(GetRedun):#GetRedunC
						print("\t\t\t以冗余判定方式进行列值比较",GetRedun)
						if(int(colstr)<=int(self.ViewList[expbnow].split()[self.Ignore+2])):
							print("\t\t\t\t\t根据有冗余，及列值小于本页行数判断，该列值为指向行内容，进行Altstr字串解析->")
							colstr1=self.AltStr(self.ViewList[expbnow+int(colstr)],-1,self.Expbnow).split()[0]
							if(self.IsNumber(colstr1)):
								colstr=colstr1
								fcol=float(colstr)*(1.0-float(subper)/100.0)
								print("\t\t提取列整数对应行字串,Altstr替换为[",colstr,"]化为实数：",fcol)
							else:
								colstr1=self.ViewList[expbnow+int(colstr)]
								print("\t\t提取列整数对应行字串[",colstr1,"]")
								formp=True#一元变量代换以简化公式转化难度
		#			else:
		#				print("不进行列值比较GetRedun",GetRedun)#GetRedunC
				#lc=0
				rc=1#冗余计数
	#			print(colist)

				cols=len(colist)
				
				if(crangp):#当列号有范围时
					print("\t\t列字串有范围")
					if(crangstr[0]=='~'):
						cb=0
					elif(crangstr.split('~')[0].isdigit()):
						cb=int(crangstr.split('~')[0])
					else:
						alti=self.AltStr(crangstr.split('~')[0],-1,self.Expbnow).split()[0]
						if (alti.isdigit()):
							cb=int(alti)
						else:
							print("\t\t\t列号范围下界限应为整数，或为整数的变量，请修正")
					fto=crangstr.find('~')
					print("\t\t",fto,"位<==>",len(crangstr)-1,"串长，则列号终步同项数",ce)
					if(len(crangstr)>fto+1):
						if(not crangstr[fto+1].isdigit()):
							ce=cols
						else:
							crangstr1=crangstr.split('~')[1]
							if(crangstr1.isdigit()):
								ce=int(crangstr1)
							elif(crangstr1.find('@')):
								if(crangstr1.split('@')[0].isdigit()):
									ce=int(crangstr1.split('@')[0])
								else:
									alti=self.AltStr(crangstr1.split('@')[0],-3,self.Expbnow).split()[0]
									if(alti.isdigit()):
										ce=int(alti)
									else:
										print("\t\t\t列号范围上界限应为整数，或为整数的变量，请修正")
								stepca=crangstr1.split('@')[1]
								if(stepca.isdigit()):
									stepc=int(stepca)
								else:
									if(stepca[0]=='-' and stepca[1:].isdigit()):#过滤多余的-号
										stepc=int(stepca[1:])
									else:
										alti=self.AltStr(stepca,-3,self.Expbnow).split()[0]
										if(alti.isdigit()):
											stepc=int(alti)
										else:
											print("\t\t\t列号范围步长应为整数，或为整数的变量，请修正")
					if(cb>ce):
						stepc=-stepc
				else:#当列号无范围时
					cb=0
					ce=cols

				print("\t\t列起步",cb,"终步",ce,"步长",stepc)
				#for cstr in colist:
				for lc in range(cb,ce+1,stepc):
					cstr=colist[lc]
					print("\t固定行操作列",lc,"字串[",cstr,"]")
					pstr=self.PickNum(cstr)
					if formp:
						if(colstr1.find('$')>=0):#$代表列值变量替换
							nf=colstr1.find('$')
							flist=colstr1.split('$')#准备列值替换表
							if (nf==0):#$+4*(qsum)/(3141.59*$^2)-2.5
								fstring=""
								for i1f in range(len(flist)):
									fstr=flist[i1f]
									fstring+=pstr+fstr
							else:#4*(qsum)/(3141.59*$^2)-2.5+$+5
								fstring=flist[0]
								for i1f in range(1,len(flist)):
									fstr=flist[i1f]
									fstring+=pstr+fstr
		#					print("变量替换",cstr,"成为",fstring)
							pstr=self.AltStr(fstring,-1,self.Expbnow).split()[0]
							if(self.IsNumber(pstr)):
		#						print("提取列整数对应行字串,Altstr替换为[",pstr,"]")
								if Lessp:
									if(float(pstr)<=0):
										rc+=1
		#								print(expbnow+row,"行发现返回[",lc,"]项:",pstr,"满足小于等于条件")
										if(rc>Redun):
											rslist.append(str(lc))
											rslist.append(cstr)
											return rslist
											#return str(lc)
								else:
									if(float(pstr)>=0):
										rc+=1
		#								print(expbnow+row,"行发现返回[",lc,"]项:",pstr,"满足大于等于条件")
										if(rc>Redun):
											rslist.append(str(lc))
											rslist.append(cstr)
											return rslist
											#return str(lc)
					elif(self.IsNumber(colstr)):#当为实数时，比较表中列值与该实数
						print("\t\t列字串是实数")
						if Lessp:
							print("\t\t比较",lc,"列字串值",pstr,"是否小于等于算式值")
							if(len(pstr)>0):
								if(float(pstr)<=fcol):
									rc+=1
									print("\t\t",expbnow+row,"行发现返回[",lc,"]项:",pstr,"满足小于等于",colstr)
									if(rc>Redun):
										if(rc>Redun):
											rslist.append(str(lc))
											rslist.append(cstr)
											return rslist
										#return str(lc)
						else:
							print("\t\t比较",lc,"列字串值",pstr,"是否大于等于算式值")
							if(len(pstr)>0):
								if(float(pstr)>=fcol):
									rc+=1
									print("\t\t",expbnow+row,"行发现返回[",lc,"]项:",pstr,"满足大于等于",colstr)
									if(rc>Redun):
										if(rc>Redun):
											rslist.append(str(lc))
											rslist.append(cstr)
											return rslist
										#return str(lc)
					else:
						print("\t\t",expbnow+row,"行[",colstr1,"]应为带$符代入列值的方程式，或算式，请检查修正")

					#lc+=1

		else:#没有列信息
			linstr=string
			it=linstr.find('~')
			if(it>=0):
				lrangp=True
			if(linstr.find('#')>=0):#行有#分离出冗余值，更新行字串
				strfix=linstr.split('#')[1]
				linstr=linstr.split('#')[0]
				if(strfix[0]=='-'):
					subper=strfix[1:]
				if(strfix.isdigit()):
					GetRedun=True#GetRedunL
					Redun=int(strfix)
			#取之后数代表序号的结果值，比如#3表示有三个结果时取第3个，少于三结果时取最接近于3的结果

	#		if(linstr.find('#')>=0):
	#			if(linstr.split('#')[1].isdigit()):
	#				GetRedun=True#GetRedunL
	#				Redun=int(linstr.split('#')[1])
	#				linstr=linstr.split('#')[0]

#行为非固定值的范围时，返回双数列表，顺序：行号在前列号在后；求属性时属性在前，求关键字时关键字在前
		if lrangp:#(it>=0):#linstr[0]!='~'):
			ib=int(linstr.split('~')[0])
			print("发现始行字符,转整数为",ib)
			if(len(linstr)>it+1):
				if(linstr[it+1]!=':'):
					ie=int(self.psplit(linstr,'~',':')[1][1:-1])
					print("发现末行字符,转整数为",ie)
			if(linstr.find("?")>=0):
				GetStr=True
				keystr=self.psplit(linstr,':','?')[1][1:-1]#linstr.split(':')[1].split('?')[0]
				#keyattrstr=linstr.split('?')[1]
#				print("关键字位于:?之间为[",keystr,"]共",len(keystr),"个字")
				if(linstr.strip()[-1]==':'):
					GetAttr=True
					if(linstr.strip()[-2]=='?'):#求归类字符
		#				prompt="请选择归类"
						keyattrstr=":"
#						print("\t\t?后与:之间为归类字,置空意为搜索归类")
					else:#求归类下关键字字符
						#prompt=linstr.split('?')[1]#提示归类名称
						#keyattrstr=self.psplit(linstr,'?',':')[1][1:-1]#
						prompt=self.psplit(linstr,'?',':')[1][1:-1]#v962linstr.split('?')[1]
						keyattrstr=":"#v970self.psplit(linstr,'?',':')[1]
#						print("\t\t?后与:之间为归类关键字[",keyattrstr,"],搜索该归类下条目")
				else:#求归类下关键字字符
					keyattrstr=linstr.split('?')[1]
					prompt=keyattrstr
				print("\t行格式~:?时关键字[",keystr,"]归类关键字[",keyattrstr,"]")
			else:
				loclist=linstr.split(':')
				ll=len(loclist)
				if(ll==1):
					keystr=loclist[0]#colstr
					keyattrstr=""
				elif(ll==2):
					keystr=loclist[1]#linstr.split(':')[1]
					keyattrstr=""
				elif(ll==3):
					keystr=loclist[1]#linstr.split(':')[1]
					keyattrstr=loclist[2]
				print("\t行格式~:时关键字[",keystr,"]归类关键字[",keyattrstr,"]")

		else:#没有~
			if(linstr.find("?")>=0):#求字符
				GetStr=True
				keystr=linstr.split('?')[0]#v0.970
				keyattrstr=linstr.split('?')[1]
#				print("关键字位于?前为[",keystr,"]共",len(keystr),"个字,归类：",keyattrstr)
				if(linstr.strip()[-1]==':'):#求归类
					GetAttr=True
					if(linstr.strip()[-2]=='?'):#没有具体提示求归类字符
						prompt="请选择带:的归类项"
						keyattrstr=":"
			#			print("\t\t?后与:之间为归类关键字,置空意为搜索归类")
					else:#具体提示求归类字符
						prompt=self.psplit(linstr,'?',':')[1][1:-1]#v962linstr.split('?')[1]
						keyattrstr=":"#v970self.psplit(linstr,'?',':')[1]
#						print("\t\t?后与:之间为归类关键字[",keyattrstr,"],搜索该归类下条目")
				else:#求归类下关键字字符
					keyattrstr=linstr.split('?')[1]
					prompt=keyattrstr
#				print("?:时关键字[",keystr,"]归类关键字[",keyattrstr,"]")
			
			elif(linstr.find(":")>=0):#求序号,用:分隔
				templist=linstr.split(':')
#				print("由:分隔的表为",templist)
				keystr=linstr.split(':')[0]
			#	if GetRow:
			#		keyattrstr=self.psplit(linstr,':',',')[1][1:-1]
			#	else:
				keyattrstr=linstr.split(':')[1]
#				print("关键字位于:前为[",keystr,"]共",len(keystr),"字,归类于[",keyattrstr,"]")
				if(linstr.strip()[-1]==':'):#求归类
					GetAttr=True
					if(linstr.strip()[-2]==':'):#求归类序号
						prompt="请选择归类项"
						keyattrstr=":"
#						print("\t\t:与:之间为归类关键字,置空意为搜索归类")
					else:#求归类下关键字字符
						prompt=linstr.split(':')[1]
						keyattrstr=prompt
#						print("\t\t:与:之间为归类关键字[",keyattrstr,"],搜索该归类下条目",keystr)
	#			print("::时关键字[",keystr,"]归类关键字[",keyattrstr,"]")
			else:
				keystr=linstr
				keyattrstr=""
	#			print("裸奔时关键字[",keystr,"]归类关键字[",keyattrstr,"]")
		#求行时确认特定归类行范围
		ibt=ib
		iet=ie
		i1=ib
		foundA=False
		if ((not GetAttr) and (len(keyattrstr)>0)):#已知归类找关键字行范围
			for i in range(expbnow+ibt,expbnow+iet+1):
				#print("\t\t",i,"行字符->",self.ViewList[i])
				if foundA:
					if self.ViewList[i].strip():
						#if((self.ViewList[i].find(':')>=0) or (self.ViewList[i].find('：')>=0)):
						if((self.ViewList[i][-1]==':') or (self.ViewList[i][-1]=='：')):
							ie=i1-1
#							print(i1,"行发现末尾为':'的新关键字归类，设上一行为结束行",ie)
							break
				if(self.ViewList[i].find(keyattrstr)>=0):#找到归类行
					ib=i1
#					print(i1,"行发现归类关键字",keyattrstr)
					foundA=True
				i1+=1
#		print("\t格式行",expbnow,"所在页获取符合归类[",keyattrstr,"]的行号[",ib,"~",ie,"],关键字[",keystr,"]")
		#查找符合归类及关键字条件的行
		strList=[]#存放发现的归类关键字行字符，归类行末带':',返回值剔除
		numList=[]#存放发现的归类关键字行序号
		i1=ib
		if(crangp):#当列号有范围时
			if(crangstr[0]=='~'):
				cb=0
			elif(crangstr.split('~')[0].isdigit()):
				cb=int(crangstr.split('~')[0])
			else:
				alti=self.AltStr(crangstr.split('~')[0],-1,self.Expbnow).split()[0]
				if (alti.isdigit()):
					cb=int(alti)
				else:
					print("列号范围下界限应为整数，或为整数的变量，请修正")

		for i in range(expbnow+ib,expbnow+ie+1):
	#		print("\t\t",i,"行字符->",self.ViewList[i])
			if self.ViewList[i].strip():
				#if((self.ViewList[i].strip()[-1]==':') or (self.ViewList[i].strip()[-1]=='：')):
				if((self.ViewList[i].strip().split()[-1]==':') or (self.ViewList[i].strip().split()[-1]=='：')):#归类:前面需加空格
					if(len(self.ViewList[i].strip().split())>1):
						keyattrstr=self.ViewList[i].strip().split()[-2]#实际的归类关键字
					else:
						keyattrstr=self.ViewList[i].split()#实际的归类关键字
					kAi=i1#实际的归类关键字行号
#					print("\t\t\t本页",kAi,"行为关键字归类->",self.ViewList[i])
			if(not self.IsNumber(keystr)):
				if(keystr.find(';')<0):
					if(self.ViewList[i].find(keystr)>=0):#记录关键字及归类
#						print("\t\t\t",i,"行[",self.ViewList[i],"]找到关键字[",keystr,"]")
						strList.append(self.ViewList[i])
						strList.append(keyattrstr)#记录字串，#v970舍弃最后：[:-1]
	
						numList.append(str(i1))
						numList.append(str(kAi))#记录行号
				else:#v0.967
					kslist=keystr.split(';')
					ksandp=True
					for ks in kslist:
						if(self.ViewList[i].find(ks)<0):
							ksandp=False#有关键字不符合时，不记录
		#					print("\t\t\t",i,"行[",self.ViewList[i],"]未找到关键字[",ks,"]")
		#				else:
		#					print("\t\t\t",i,"行[",self.ViewList[i],"]找到关键字[",ks,"]")
					if ksandp:
						strList.append(self.ViewList[i])
						strList.append(keyattrstr[:-1])#记录字串，舍弃最后：
	
						numList.append(str(i1))
						numList.append(str(kAi))#记录行号
			elif(GetRow):#关键字是数字，且列为数字时，比较列数值求值
				cols=len(self.ViewList[i].split())
				
				if(crangp):#当列号有范围时
					fto=crangstr.find('~')
					if(fto==len(crangstr)-1):
						ce=cols
					else:
						crangstr1=crangstr.split('~')[1]
						if(crangstr1.isdigit()):
							ce=int(crangstr1)
						elif(crangstr1.find('@')):
							if(crangstr1.split('@')[0].isdigit()):
								ce=int(crangstr1.split('@')[0])
							else:
								alti=self.AltStr(crangstr1.split('@')[0],-3,self.Expbnow).split()[0]
								if(alti.isdigit()):
									ce=int(alti)
								else:
									print("列号范围上界限应为整数，或为整数的变量，请修正")
							stepca=crangstr1.split('@')[1]
							if(stepca.isdigit()):
								stepc=int(stepca)
							else:
								if(stepca[0]=='-' and stepca[1:].isdigit()):#过滤多余的-号
									stepc=int(stepca[1:])
								else:
									alti=self.AltStr(stepca,-3,self.Expbnow).split()[0]
									if(alti.isdigit()):
										stepc=int(alti)
									else:
										print("列号范围步长应为整数，或为整数的变量，请修正")
					if(cb>ce):
						stepc=-stepc
				else:#当列号无范围时
					cb=colnum
					ce=cb
				if(cols>=ce):#检查列数是否大于所求列号
				#if(len(self.ViewList[i].split())>colnum):#检查列数是否大于所求列号
					for colnum in range(cb,ce+1,stepc):
						colcell=self.PickNum(self.ViewList[i].split()[colnum])
						print("\t\t数文混搭",colnum,"列[",self.ViewList[i].split()[colnum],"]滤出数[",colcell,"]比较关键字值",keystr)
						subduc=float(keystr)*(1.0-float(subper)/100.0)#百分削减后值
						if(Lessp):
							if(float(colcell)<=subduc):
								print("\t记录",i1,"行[",self.ViewList[i],"]中",colnum,"列[",colcell,"]数值小于等于关键字",keystr,"下浮",subper,"%值后",subduc,"的结果")
								#strList.append(keyattrstr)#记录归类字串：
								strList.append(self.ViewList[i])
								strList.append(colcell)#记录列值数据
			
								numList.append(str(i1))
								numList.append(str(colnum))#colnum)#记录列号
						else:
							if(float(colcell)>=subduc):
								print("\t记录",i1,"行[",self.ViewList[i],"]中",colnum,"列[",colcell,"]数值大于等于关键字",keystr,"下浮",subper,"%值后",subduc,"的结果")
								#strList.append(keyattrstr)#记录归类字串：
								strList.append(self.ViewList[i])
								strList.append(colcell)#记录列值数据
		
								numList.append(str(i1))#记录列号
								numList.append(str(colnum))#记录行号

			i1+=1
		print("\t归类、关键字结果表：",strList)
		print("\t归类、关键字行号表：",numList)
		ll=len(strList)
		
		if(ll==2):#结果唯一时
			if(GetStr):
				if(GetAttr):
#					print("返回关键字归类[",strList[1],"]")
					print("\t\tGetAttr下1返回表",strList)
					strList.reverse()
					print("\t\tGetAttr下2返回表",strList)
					return strList
					#return strList[1]#v0.977
				else:
#					print("返回关键字[",strList[0],"]")
					print("\t\t非GetAttr下1返回表",strList)
					return strList
					#return strList[0]#v0.977
			else:
				if(GetAttr):
#					print("返回关键字归类序号",str(numList[1]))
					print("\t\tGetAttr下1返回表",numList)
					numList.reverse()
					print("\t\tGetAttr下2返回表",numList)
					return numList
					#return str(numList[1])
				else:
#					print("返回关键字序号",str(numList[0]))
					print("\t\t非GetAttr下1返回表",numList)
					return numList
					#return str(numList[0])
		elif (ll>=4):#多结果时冗余取值，或非冗余取值时弹出框选择
			if GetRedun:#GetRedunL
				if(ll>=Redun+Redun):
					if(GetStr):
						rslist.append(strList[Redun-1+Redun])
						rslist.append(strList[Redun-1+Redun-1])
						if(GetAttr):
							#print("\t\t冗余",Redun,"返回关键字归类",rslist)#strList[Redun-1+Redun],"]")
							return rslist
							#return strList[Redun-1+Redun]
						else:
							#print("\t\t冗余",Redun,"返回关键字",rslist.reverse())#,strList[Redun-1+Redun-1],"]")
							rslist.reverse()
							return rslist
							#return strList[Redun-1+Redun-1]
					else:
						#print("\t\t冗余",Redun,"返回关键字归类序号",str(numList[Redun-1+Redun]))
						rslist.append(numList[Redun-1+Redun])
						#print("\t\t冗余",Redun,"返回关键字序号",str(numList[Redun-1+Redun-1]))
						rslist.append(numList[Redun-1+Redun-1])
						#print(rslist)
						if(GetAttr):
							#print("\t\tGetAttr下返回表",rslist)
							#print("\t\t冗余",Redun,"返回关键字归类序号",rslist)#,str(numList[Redun-1+Redun]))
							return rslist
							#return str(numList[Redun-1+Redun])
						else:
							#print("\t\t非GetAttr下1返回表",rslist)
							rslist.reverse()
							#print("\t\t非GetAttr下2返回表",rslist)
							#print("\t\t冗余",Redun,"返回关键字序号",rslist)#,str(numList[Redun-1+Redun-1]))
							return rslist
							#return str(numList[Redun-1+Redun-1])
				else:
					if(GetStr):
						rslist.append(strList[round(ll/2)])
						rslist.append(strList[round(ll/2)-1])
						if(GetAttr):
		#					print("不足冗余",Redun,"返回关键字归类[",strList[round(ll/2)],"]")
							return rslist
							#return strList[round(ll/2)]
						else:
		#					print("不足冗余",Redun,"返回关键字[",strList[round(ll/2)-1],"]")
							rslist.reverse()
							return rslist
							#return strList[round(ll/2)-1]
					else:
						rslist.append(numList[round(ll/2)])
						rslist.append(numList[round(ll/2)-1])
						if(GetAttr):
		#					print("不足冗余",Redun,"返回关键字归类序号",str(numList[round(ll/2)]))
							return rslist
							#return str(numList[round(ll/2)])
						else:
		#					print("不足冗余",Redun,"返回关键字序号",str(numList[round(ll/2)-1]))
							rslist.reverse()
							return rslist
							#return str(numList[round(ll/2)-1])
			else:
				if(GetStr):
					if(GetAttr):
						linestr,ok = QInputDialog.getItem(self,"选择表项或双击输入归类",prompt,strList,3,True)
						if ok:
							rslist.append(linestr)
						linestr,ok = QInputDialog.getItem(self,"选择表项或双击输入关键字",prompt,strList,3,True)
						if ok:
							rslist.append(linestr)
							return rslist
		#					print("\t结果不单一，选择归类字串：",linestr)
						#	return linestr
						#else:
						#	return ""
					else:
						linestr,ok = QInputDialog.getItem(self,"选择表项或双击输入关键字",prompt,strList,3,True)
						if ok:
							rslist.append(linestr)
						linestr,ok = QInputDialog.getItem(self,"选择表项或双击输入归类",prompt,strList,3,True)
						if ok:
							rslist.append(linestr)
							return rslist
		#					print("\t结果不单一，选择关键字串：",linestr)
						#	return linestr
						#else:
						#	return ""
				else:
					linestr,ok = QInputDialog.getItem(self,"多项归类选择",prompt,strList,3,False)
					if ok:
						linei=strList.index(linestr)
						if(linei%2==1):
							rslist.append(str(numList[linei]))
							rslist.append(str(numList[linei-1]))
						else:
							rslist.append(str(numList[linei+1]))
							rslist.append(str(numList[linei]))
					if(GetAttr):
						return rslist
					else:
						rslist.reverse()
						return rslist
		else:#全页选择
			print("\t\t自动搜索未找到符合结果，手动选择，从",ib,"行到",ie,"行")
			strList=[]
			numList=[]
	#		ie=int(self.ViewList[expbnow].split()[self.Ignore+2])#ie=self.model.rowCount()
	#		rows=ie
	#		ib=0
			i1=1
			for i in range(expbnow+ib,expbnow+ie+1):
				strList.append(self.ViewList[i])
				numList.append(i1)
		#	print(strList)
			if(GetStr):
				if(GetAttr):
					titlestr="选择关键字["+keystr+"]的归类"
					linestr,ok = QInputDialog.getItem(self,titlestr,prompt,strList,3,True)
					if ok:
						rslist.append(linestr)
					titlestr="选择["+keyattrstr+"]归类下关键字["+keystr+"]"
					linestr,ok = QInputDialog.getItem(self,titlestr,prompt,strList,3,True)
					if ok:
						rslist.append(linestr)
					return rslist
				else:
					titlestr="选择["+keyattrstr+"]归类下关键字["+keystr+"]"
					linestr,ok = QInputDialog.getItem(self,titlestr,prompt,strList,3,True)
					if ok:
						rslist.append(linestr)
					titlestr="选择关键字["+keystr+"]的归类"
					linestr,ok = QInputDialog.getItem(self,titlestr,prompt,strList,3,True)
					if ok:
						rslist.append(linestr)
					return rslist
			else:
				if(GetAttr):
					titlestr="选择关键字["+keystr+"]的归类项"
					linestr,ok = QInputDialog.getItem(self,titlestr,prompt,strList,3,False)
					if ok:
						linei=strList.index(linestr)
						rslist.append(str(linei))
					titlestr="选择["+keyattrstr+"]归类下关键字["+keystr+"]项"
					linestr,ok = QInputDialog.getItem(self,titlestr,prompt,strList,3,False)
					if ok:
						linei=strList.index(linestr)
						rslist.append(str(linei))
					return rslist
				else:
					titlestr="选择关键字["+keystr+"]的归类项"
					linestr,ok = QInputDialog.getItem(self,titlestr,prompt,strList,3,False)
					if ok:
						linei=strList.index(linestr)
						rslist.append(str(linei))
					titlestr="选择["+keyattrstr+"]归类下关键字["+keystr+"]项"
					linestr,ok = QInputDialog.getItem(self,titlestr,prompt,strList,3,False)
					if ok:
						linei=strList.index(linestr)
						rslist.append(str(linei))
					return rslist
			#if ok:
			#	if(GetStr):
			#		return linestr
			#	else:		
			#		linei=strList.index(linestr)
			#		return str(linei)
			#else:
			#	return ""

# 741 98 (843)

	def PopList (self,string,expbnow):#@调出弹出框，字符串
#string不带括号,expbnow本页首行在主列表文件中的位置
#调出弹出框格式，如@9~10,意为本页9~10行组成一个弹出框,如@9~10?姓名,则将?后字符‘姓名’作为提示；
#赋值格式，(1 9 0 (@9~10) 0),意为将弹框选择赋给第9行末项为名的变量
#		print("进入弹出框模块")
		Indexpath=os.path.join(os.getcwd(),self.IndexFile)
		CheckedRowNuber=[]
		ib=1
		ie=int(self.ViewList[expbnow].split()[self.Ignore+2])
		GetRow=False#判断获取表中列值>=关键字的行号
		if(string[0]=='@'):#初判格式符合
			if(string.find('~')>0):#再判格式符合
				if(string.find(',')>0):#将行与列分开
					linstr=string.split(',')[0][1:]
					colstr=string.split(',')[1]
#					print("\n\t行字串[",linstr,"]列字串[",colstr,"]")
					#取行的值作弹出框兼容如意(1 9 0 (@9~10:$?姓名,0) 0)
					if(colstr.isdigit()):#colstr=='0'):
						GetRow=True#返回列字符
						if(string.find('?')>=0):
							if(string.find(',')>=0):
								pstr=string.split(',')[0].split('?')[-1]
								if(string.find(':')>0):
									ie=int(linstr.split(':')[0].split('~')[-1])+expbnow
									ib=int(linstr.split(':')[0].split('~')[0])+expbnow
								else:
									ie=int(linstr.split('?')[0].split('~')[-1])+expbnow#起行为0行
									ib=int(linstr.split('~')[0])+expbnow
							else:
								pstr=string.split('?')[-1]
						else:
							pstr=""
							if(string.find(':')>0):
								ie=int(linstr.split(':')[0].split('~')[-1])+expbnow
								ib=int(linstr.split(':')[0].split('~')[0])+expbnow
							else:
								ie=int(linstr.split('~')[-1])+expbnow#起行为0行
								ib=int(linstr.split('~')[0])+expbnow
					#	print("行数据弹出框提示：[",pstr,"]，起始行：",ib,"，终止行：",ie)
						locList=[]
						for i in range(ib,ie+1):
							locList.append(self.ViewList[i])
					#	print("\t弹出框初始化前表：",locList)
					else:#取列的值作弹出框字符兼容如意(1 9 0 (@2,3~6:$?数值) 0)
						if(string.find('?')>=0):
							#GetStr=True
							pstr=colstr.split('?')[-1]
							colstr=colstr.split('?')[0]
						else:
							pstr=""
						if(string.find(':')>0):
							ie=int(colstr.split(':')[0].split('~')[-1])
							ib=int(colstr.split(':')[0].split('~')[0])
						else:
							ie=int(colstr.split('~')[1])
							ib=int(colstr.split('~')[0])
					#	print("列数据弹出框提示：[",pstr,"]，起始行：",ib,"，终止行：",ie)
						collist=self.ViewList[expbnow+int(linstr)].split()
						locList=[]#self.
						for i in range(ib,ie+1):
							locList.append(collist[i])
					#	print("\t弹出框初始化前表：",locList)
				else:#取行的值作弹出框字符#格式(1 9 0 (@9~10?姓名) 0)
					if(string.find('?')>=0):
						pstr=string.split('?')[-1]
						datastr=string.split('?')[0][1:]
					else:
						pstr=""
						datastr=string[1:]
					ie=int(datastr.split('~')[-1])+expbnow#起行为0行
					ib=int(datastr.split('~')[0])+expbnow#
					#print("简格式无逗号，行弹出框提示：[",pstr,"]，起始行：",ib,"，终止行：",ie)
					locList=[]#self.
					for i in range(ib,ie+1):
						locstr=self.ViewList[i]
						locList.append(locstr)
						if(self.Listp(locstr) and len(locstr.split())==1):
							altstr=self.AltStr(locstr,8,expbnow).split()[0]
							if not (altstr==locstr):
								locList.append(altstr)
					#print("\t弹出框初始化前表：",locList)#self.
				line,ok = QInputDialog.getItem(self,"选择表项或双击输入",pstr,locList,3,True)
				if ok:
					string=line
				else:
					string=""
#				print("\t处理后字串成为：",string)
				if GetRow:
					if(len(string.split())>int(colstr)):
						string=string.split()[int(colstr)]
#						print("\t要求输出列字串，处理为：",string)
			else:
				print("字符串[",string,"]弹出框格式错误，应包含~符")
		else:
			print("字符串[",string,"]弹出框格式错误，首字应为@")
		return string

# 98 40 (1598)

	def backward (self):#分页回跳 
		#print("\n进入回跳模块backward->",self.NOpIdx)
		self.NOpIdx=[]#清空多选项表
		#print("\n清空选中表",self.NOpIdx)
		if self.ExpMode and self.Expbnow>0:#在myfileopen兼容模式中已赋值
			self.EIndex()#显示上页摘录成果

			bnowstr=self.ViewList[self.Expbnow]#获取当前格式行
			#print("\n＝＝＝\n\t＝＝＝回跳当前",self.Expbnow,"行：",bnowstr)
			lie=bnowstr.split()#转成表

			lcol=len(lie)
			if(lcol>self.Ignore+2):#格式检查
				jumpp=False
				autop=False
				if(self.Listp(bnowstr)):#初检有无浏览跳转链接项
					plist=self.psplit(bnowstr,"(",")")
					liste=plist[-1][1:-1].split()#提取最后一个括号项字符
					if(liste[0].isdigit()):#括号项首项为数字，表示有链接
			#			print("\n\t\t\t浏览链接表为：",liste)
						jumpp=True
					else:
			#			print("\n\t\t\t程序摘引串为：",liste)
						autop=True
				if jumpp:#有浏览跳转链接
					itemn=int(liste[0])#提取回跳链接步长
			#		print("\t\t\t\t链接表第",self.Expitem,"项所提取链接步长为：\t",itemn)
				else:
					itemn=0
				self.Expbnow=self.Expbnow-int(lie[self.Ignore+1])-1-itemn
				ljump=self.ViewList[self.Expbnow].split()#获取链接跳转后的格式行表
				if(len(ljump)>self.Ignore+2):
					if (ljump[self.Ignore+2].isdigit()):
						self.Expfnow=self.Expbnow+int(ljump[self.Ignore+2])+1
						self.ExpView(int(self.Expbnow),int(self.Expfnow))
			else:
				print(self.Expbnow,"行格式错误")
			self.Expitem=-1

# 40 134 (1697)
			
	def forward (self):#分页前跳
		#print("\n进入前跳模块forward->",self.NOpIdx)#,end=""
		self.Expitem=-1
		if self.ExpMode and self.Expfnow< self.lViewList-2:#在myfileopen兼容模式中已赋值
			#print("\n向前步长",self.Expfnow,"\n")
			if(self.Expfnow==0):
				i=self.model.item(0).checkState()#检测顶行是否勾选，决定是人工模式或程序模式
				#print("\n\t检测顶行勾选与否：",i)
				if(i>0):
					self.AutoMode=True#程序模式
				#	print("\n\t进入注释摘录模式，AutoMode：",self.AutoMode)
				else:
					self.AutoMode=False#人工模式
			self.EIndex()#显示上页摘录成果
				
			if not self.AutoMode:#非注释摘录模式下从屏幕获取，程序模式由AutoE赋值
				self.NOpIdx=[]#清空多选项表#v0.94
				self.Expitem=-1
				self.Expitem=self.OnOpNumber() 
				#print(self.NOpIdx,"前跳选中行",self.Expitem)
				bnowstr=self.ViewList[self.Expbnow]#获取当前格式行
				#print("\n＝＝＝\n\t＝＝＝前跳当前",self.Expbnow,"行：",bnowstr)
				lie=bnowstr.split()#转成表
				lcol=len(lie)
				#if(self.Expitem>=0):
				if(lcol>self.Ignore+2):#格式检查
				#	print("\t",self.Expbnow,"行初判为格式行；")
					jumpp=False
					if(self.Expitem>0):#浏览链接有选中
				#		print("\t\t","跳转浏览链接选中第",self.Expitem,"项；")
						if(self.Listp(bnowstr)):#初步检查有无浏览跳转链接项
							plist=self.psplit(bnowstr,"(",")")
							liste=plist[-1][1:-1].split()#提取最后一个括号项字符
							if(liste[0].isdigit()):#括号项首项为数字，表示有链接
				#				print("\n\t\t\t浏览链接表为：",liste)
								le=len(liste)#获取链接表项数
								jumpp=True
						if jumpp:#有浏览跳转链接
							if(self.Expitem<=le-1 ):#v0.76选中表项合规检查
								itemn=int(liste[self.Expitem])#提取链接步长
					#			print("\t\t\t\t链接表第",self.Expitem,"项所提取链接步长为：",itemn)
								self.Expbnow=self.Expbnow+int(lie[self.Ignore+2])+1+itemn
								ljump=self.ViewList[self.Expbnow].split()#获取链接跳转后的格式行表
								if(len(ljump)>=self.Ignore+2 and ljump[self.Ignore+2].isdigit()):
									self.Expfnow=self.Expbnow+int(ljump[self.Ignore+2])+1
									self.ExpView(int(self.Expbnow),int(self.Expfnow))#***
					if(not jumpp):#浏览链接没有选中向前项self.Expitem<=0 or 
					#	print("\t\t","没有选中跳转浏览链接，步进显示下一页：")
						self.Expbnow=self.Expfnow
						bnowstrb=self.ViewList[self.Expbnow]#获取当前格式行
						self.Expfnow=self.Expbnow+int(bnowstrb.split()[self.Ignore+2])+1
						self.ExpView(int(self.Expbnow),int(self.Expfnow))#***
			else:#注释摘录模式
				bnowstr=self.ViewList[self.Expbnow]#获取当前格式行
#				print("\n＝＝＝\n\t＝＝＝autofore当前",self.Expbnow,"行：",bnowstr)
				lie=bnowstr.split()#转成表
				lcol=len(lie)
				jumpp=False
				autop=False
				if(lcol>self.Ignore+2):#格式检查
#					print("\t",self.Expbnow,"行autofore初判为格式行；选中项：",self.Expitem)

					if(self.Listp(bnowstr)):#初步检查有浏览跳转链接项
#						print("初步检查有浏览跳转链接项")
						plist=self.psplit(bnowstr,"(",")")
						liste=plist[-1][1:-1].split()#提取最后一个括号项字符
						if(liste[0].isdigit()):#括号项首项为数字，表示有链接
#							print("\n\t\t\tautofoe浏览链接表为：",liste)
							le=len(liste)#获取链接表项数
							jumpp=True
							if(len(plist)==3):#包括了浏览链接和程序表
								autop=True
								#提取倒数第2个括号项字符为程序表
								stra=plist[-2][1:-1]#self.psplit()[1:]
#								print("\n\t\t\tautofore程序表共3项，摘引串为：",stra)
						else:
							autop=True
							#提取最后括号项字符为程序表
							stra=plist[-1][1:-1]#self.psplit()[1:]
#							print("\n\t\t\tautofore提取末项程序表摘引串为：",stra)

					if(self.Expitem>=0):#浏览链接有选中
#						print("\t\tautofore跳转浏览链接选中第",self.Expitem,"项；")
						if jumpp:#有浏览跳转链接
							if(self.Expitem<=le-1 ):#v0.76选中表项合规检查
								itemn=int(liste[self.Expitem])#提取链接步长
				#				print("\t\t\t\tautofore链接表第",self.Expitem,"项步长为：",itemn)
								self.Expbnow=self.Expbnow+int(lie[self.Ignore+2])+1+itemn
								ljump=self.ViewList[self.Expbnow].split()#获取链接跳转后的格式行表
								if(len(ljump)>=self.Ignore+2 and ljump[self.Ignore+2].isdigit()):
									self.Expfnow=self.Expbnow+int(ljump[self.Ignore+2])+1
									#self.Expitem=-1	
									self.ExpView(int(self.Expbnow),int(self.Expfnow))#***

									bnowstr=self.ViewList[self.Expbnow]#获取当前格式行
									if(self.Listp(bnowstr)):#初步检查有无浏览跳转链接项
										plist=self.psplit(bnowstr,"(",")")
										liste=plist[-1][1:-1].split()#提取最后一个括号项字符
										if(liste[0].isdigit()):#括号项首项为数字，表示有链接
				#							print("\n\t\t\tautofore前跳后浏览链接表为：",liste)
											le=len(liste)#获取链接表项数
											jumpp=True
										else:
											jumpp=False
										if(len(plist)==3):#包括了浏览链接和程序表
											autop=True
											#提取倒数第2个括号项字符为程序表
											stra=plist[-2][1:-1]#self.psplit()[1:]
				#							print("\n\t\t\tautofore前跳后程序表共3项，摘引串为：",stra)
										else:
											autop=False											
									else:
										autop=True
										#提取最后括号项字符为程序表
										stra=plist[-1][1:-1]#self.psplit()[1:]
				#						print("\n\t\t\tautofore前跳后提取末项程序表摘引串为：",stra)

					if autop:
#						print("\n\t---> autofore执行程序摘引串")
						self.AutoE(stra)
					else:#浏览链接没有选中
#						print("\t\tautofore没有选中跳转浏览链接、接引串，步进显示下一页：")
						self.Expbnow=self.Expfnow
						bnowstrb=self.ViewList[self.Expbnow]#获取当前格式行
						self.Expfnow=self.Expbnow+int(bnowstrb.split()[self.Ignore+2])+1
						self.ExpView(int(self.Expbnow),int(self.Expfnow))#***
						#else:
						#	print(self.Expbnow,"auto行无跳转链接")

					#if not jumpp:	
				else:
					print(self.Expbnow,"autofore格式行有误")

# 134 57 (1738)

	def ExpView (self,top,bot):#分页显示
	#显示self.ViewList第top行到第bot行
		#print("\n进入专用格式显示模块ExpView->")
		bnowstr=self.ViewList[top]#获取当前格式行
		#print("顶",top,"行字符：",bnowstr)
		lie=bnowstr.split()#转成表
		#print("转成表",lie)
		#bot=int(lie[self.Ignore+2])+1
		#print("bot",bot)
		lcol=len(lie)
		lp0=0
		le=0
		jumpp=False
		autop=False
		le=0
		if(self.Listp(bnowstr)):#检查有无浏览链接项
			plist=self.psplit(bnowstr,"(",")")
			lp0=len(plist[0].split())#去除括号项后的列表项数
			liste=plist[-1][1:-1].split()#提取最后一个括号项字符
			if(liste[0].isdigit()):#确定为跳转链接表
				le=len(liste)#获取链接表项数

		i1=0
		for i in range(top,bot):
			if(i==top):#格式行
				#print(" 格式行",i,end="")
				if self.FormatShow:
					item = QStandardItem(self.ViewList[i])
				else:
					item = QStandardItem("")
				
				item.setCheckState(False)
				item.setCheckable(True)
				self.model.clear()
				self.model.appendRow(item)
				#if(le>0):#有链接表时，显示小手图标v0.979
				#	if((i1<=le-1) and liste[i1]!='0'):
				#		self.model.item(i1).setIcon(QIcon("click.png"))
			else:#非格式行
				item = QStandardItem(self.ViewList[i])
				item.setCheckState(False)
				item.setCheckable(True)
				self.model.appendRow(item)
				if(le>0):#有链接表时，显示小手图标
					if((i1<=le-1) and liste[i1]!='0'):
						self.model.item(i1).setIcon(QIcon("click.png"))
				if self.ViewList[i].strip(): #v0.56插入图片☯xx.jpg
					if (self.ViewList[i][0]=='☯') :
						picname=os.path.join("src",self.ViewList[i][1:]+".jpg")
						self.model.item(i1).setIcon(QIcon(picname))
						self.ui.listView.setIconSize(QSize(self.PicSize,self.PicSize))
			i1+=1
		self.ui.listView.setModel(self.model)
		self.ui.show()
#		self.show()

# 57 21 (1899)
	def ForJump(self,Expbnow,Expitem):#当前页首行Expbnow,选择Expitem行前跳的处理
		#print("\t\tForJump自动浏览准备,当前页首行[",Expbnow,"]链接行[",Expitem,"]")
		bnowstr=self.ViewList[Expbnow]
		if(len(bnowstr.split())>self.Ignore+2):
			jumpp=False
			Expforestep=int(bnowstr.split()[self.Ignore+2])
			if(len(self.psplit(bnowstr,'(',')'))>=2):
				linklist=self.psplit(bnowstr,'(',')')[-1][1:-1].split()
				if(linklist[0].isdigit()):
					if(Expitem<len(linklist)):
						jumpp=True
						jump=int(linklist[Expitem])
						Expbnow=Expbnow+Expforestep+1+jump#v959
	#					print("\t\t准备forward,前步长",Expforestep,"跳行",jump,"跳至",Expbnow)
			if(not jumpp):
				Expbnow=Expbnow+Expforestep+1
			return Expbnow
		else:
			print("ForJump检测",Expbnow,"行[",bnowstr,"]格式错误")


# 21 296 (1931)

	def AutoE (self,string):#注释摘录
		print("\n\n进入自动摘录模块AutoE,操作字串[",string,"]")#string为去掉括号的字符串
		Indexpath=os.path.join(os.getcwd(),self.IndexFile)
		if(len(string)==1):
			with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
				i1=1
				for i in range(self.Expbnow,self.Expfnow):
					f.write(str(self.Expbnow)+" "+str(i1)+" "+"\n")
					i1+=1

				f.write("\n")#方便undo操作
			
		else:
			AElist=self.psplit(string,"(",")")
			#print("\t自动摘录",self.Expbnow," 行转化操作列表：",AElist)
			#print("=================",self.Expbnow,"=================")
			la=len(AElist)
			for i in range(1,la):
				stril=AElist[i][1:-1].split()
				lsl=len(stril)
				print("\n==注释摘录：",AElist[i])
				Expforestep=int(self.ViewList[self.Expbnow].split()[self.Ignore+2])
				if(lsl==1):
#					print("\n\t**单项注释摘录：",AElist[i])
					with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
						stri=AElist[i][1:-1]#去括号
						if(stri.isdigit()):#如果是数字
							if(stri=='0'):
#									print("\t\t\t摘引项(0)")
									f.write(str(self.Expbnow)+" "+stri+" \"\"\n")
							else:
								if(int(stri)<Expforestep):#大小在行号之间摘引该行
									f.write(str(self.Expbnow)+" "+stri+"\n")
						else:	#非数字的检索若有变量含此字符，提取字符,-3表示算式字串不计算
							if(stri=='A' or stri=='a' ):#全选本页
								for i1 in range(1,Expforestep+1):
									f.write(str(self.Expbnow)+" "+str(i1)+"\n")
							else:
								alti=self.AltStr(stri,-3,self.Expbnow).split()[0]
#								print("\t\t单项注释摘录字符检索变量后为：",alti)
								if(alti.isdigit()):#如果是数字
#									print("\t\t\t变量替换后是数字",alti,"?",Expforestep)
									if(int(alti)<Expforestep):
#										print("\t\t\t摘引数字",self.Expbnow," ",alti)
										f.write(str(self.Expbnow)+" "+alti+"\n")
								else:#非数字
#									print("\t\t\t变量替换后为字符串[",alti,"]，搜索本页含此字符的行")
									getlinep=False
									i1=1
									for i in range(Expforestep):
										if(self.ViewList[self.Expbnow+i1].find(alti)>=0):
											f.write(str(self.Expbnow)+" "+str(i1)+"\n")
											getlinep=True
	#										print(i1,"行",self.ViewList[self.Expbnow+i1],"含字符[",alti,"]")
											break
										i1+=1
									if not getlinep:
#										print("没有找到变量替换字符后的行,写入该字符")
										f.write(str(self.Expbnow)+" 0 "+alti+"\n")
							f.write("\n")#方便undo操作
						#f.close()
				elif(lsl==2):
#					print("\n\t**双项注释摘录表AElist[",i,"]：",AElist[i])
					if(stril[0]=="0"):#后台程序浏览模式
						jumpp=False
#						print("\t两项式",AElist[i],"注释摘录->")
						if(str(self.Expbnow) in self.Expdic):#检查本列表项运行过
							i1=self.Expdic[str(self.Expbnow)]#运行过的提取该行序号
							if(i>=i1):
			#					print("\n\t\t\t\t=>已历自动浏览行：",self.Expbnow,"运项序号 ",i1," 当前循环i=",i)
								self.Expdic[str(self.Expbnow)]=i
								if(i==la):
			#						print(self.Expbnow,"行自动摘录表共",la,"项，已运行至",i,"项，该行从字典中删除。")
									self.Expdic.pop(str(self.Expbnow))#各项运行后，删除字典该行							
								if(stril[1]=="0"):
									self.backward()
								elif(stril[1].isdigit()):
									self.Expitem=int(stril[1])
									self.Expbnow=self.ForJump(self.Expbnow,self.Expitem)
									self.forward()
								else:
									alti=self.AltStr(stril[1],0,self.Expbnow).split()[0]
#									print("\t\talstr变量替换为字符",alti)
									if(not alti.isdigit()):
#										print("\t\t非数字时，Picklist开始查找相关字符行号->")
										alti=self.PickList(alti,self.Expbnow)[0]#stril[1]
#										print("\t\tPicklistr返回行号",alti)
									if(alti.isdigit()):
										self.Expitem=int(alti)
										self.Expbnow=self.ForJump(self.Expbnow,self.Expitem)
										self.forward()
									else:
										print(string," 中 ",AElist[i]," 第二项应为数字，请纠正：",stril[1])
						else:#检查本列表项没有运行过
							self.Expdic[str(self.Expbnow)]=i							
			#				print("\n\t\t\t\t->发现自动浏览行：",self.Expbnow,"初次运行项序号i=",i)
							if(stril[1]=="0"):
								self.backward()
							elif(stril[1].isdigit()):
								self.Expitem=int(stril[1])
								self.Expbnow=self.ForJump(self.Expbnow,self.Expitem)
								self.forward()
							else:
								alti=self.AltStr(stril[1],0,self.Expbnow).split()[0]
#								print("\t\talstr变量替换为字符",alti)
								if(not alti.isdigit()):
#									print("\t\t非数字时，Picklist开始查找相关字符行号->")
									alti=self.PickList(alti,self.Expbnow)[0]#stril[1]
#									print("\t\tPicklistr返回行号",alti)
								if(alti.isdigit()):
									self.Expitem=int(alti)
									self.Expbnow=self.ForJump(self.Expbnow,self.Expitem)
									self.forward()
								else:
									print(string," 中 ",AElist[i]," 第二项应为数字，请纠正：",stril[1])
					elif(stril[0].isdigit()):
						if(stril[1].isdigit()):
							toi=int(stril[1])
							fri=int(stril[1])-int(stril[0])+1
#							print("\t\t两项式",AElist[i],"注释摘录，从",fri,"到",toi)
							with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
								i1=fri
								for i in range(int(stril[0])):
									f.write(str(self.Expbnow)+" "+str(i1)+"\n")
									i1+=1
								f.write("\n")#方便undo操作
							f.close()
						else:
							alti=self.AltStr(stril[1],0,self.Expbnow).split()[0]
							if(alti.isdigit()):
								toi=int(stril[1])
								fri=int(stril[1])-int(stril[0])+1
#								print("\t\t两项式",AElist[i],"注释摘录，从",fri,"到",toi)
								with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
									i1=fri
									for i in range(int(stril[0])):
										f.write(str(self.Expbnow)+" "+str(i1)+"\n")
										i1+=1
									f.write("\n")#方便undo操作
							else:
								print(string," 中 ",AElist[i]," 第二项应为数字，请纠正：",stril[1])
					else:
						alti=self.AltStr(stril[1],0,self.Expbnow).split()[0]
						if(alti.isdigit()):
							print("\t\t两项式",AElist[i],"赋值[",alti,"]于变量[",stril[0],"]")
							with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
								f.write(str(self.Expbnow)+" 0 \""+alti+"\" "+stril[0]+"\n")
								f.write("\n")#方便undo操作
				elif(lsl==3):
#					print("\n\t**参项注释摘录：",AElist[i])
					#v0.975引入双变量赋值，第一第二项为字符串时设为变量名
					dual1p=False
					dual2p=False
					if (not stril[0].isdigit()):
						dual1p=True
						#print("第1项应为整数或整数变量，请修正")#v0.975

					if (not stril[1].isdigit()):
						dual2p=True
						#print("第2项应为整数或整数变量，请修正")#第二项为字符串时设为变量名

					if(stril[2].isdigit()):#第三项为数字时，调出该行字串
						string3=self.ViewList[self.Expbnow+int(stril[2])]#取整行，若取列用,分隔声明
					else:
						string3=stril[2]#第三项非数字时，本身作为字串

					if(not dual1p):
						if(stril[1].isdigit()):
							toi=int(stril[1])
						else:
							alti=self.AltStr(stril[1],0,self.Expbnow).split()[0]
#							print("\t\talstr变量替换为字符",alti)
							if(not alti.isdigit()):
#								print("\t\t非数字时，Picklist开始查找相关字符行号->")
								alti=self.PickList(alti,self.Expbnow)[0]#stril[1]
#								print("\t\tPicklistr返回行号",alti)
							if(alti.isdigit()):
								toi=int(alti)
#								print("参项摘录第二项转化为整数",toi)
							else:
								print(string," 中 ",AElist[i]," 第二项应为数字，请纠正：",stril[1])
						fri=toi-int(stril[0])+1
				#		print("\t\t三项注释摘录，从",fri,"到",toi)
						Indexpath=os.path.join(os.getcwd(),self.IndexFile)
						if(self.Expbnow==0):#v0.74
							with open(Indexpath,mode='w+t',encoding='UTF-8') as f:
								f.write(self.fileName_choose+"\n")
						else:
							with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
	
								i1=fri
								for i in range(int(stril[0])):
									if(stril[2]=='0'):
										f.write(str(self.Expbnow)+" "+str(i1)+"\n")
										#print("换行")
									else:
										f.write(str(self.Expbnow)+" "+str(i1)+" \"⌇\"\n")
										#print("不换行")
									i1+=1
								f.write("\n")#方便undo操作
						

					if (dual2p and dual1p):
						with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
							strt=self.AltStr(string3,0,self.Expbnow)#第四项字括号或计算式化解
							if(len(strt.split())>1):
								strt1=strt.split()[0]
								strt2=strt.split()[-1]
							f.write(str(self.Expbnow)+" 0 \""+strt1+"\" "+stril[1]+"\n")
							f.write(str(self.Expbnow)+" 0 \""+strt2+"\" "+stril[0]+"\n")
							f.write("\n")#方便undo操作
				elif(lsl==4):
#					print("\n\t**肆项注释摘录：",AElist[i])
					#肆项摘录不计算，在有括号时变量替换；第三项负数时将第四项赋值于第二项，0时换行，非0不换行
					toi=int(stril[1])
					fri=int(stril[1])-int(stril[0])+1					
					if(stril[3].isdigit()):#第四项为数字时，调出该行字串
						string4=self.ViewList[self.Expbnow+int(stril[3])]
						if(self.Listp(string4)):
							#strt=self.psplit(string4,'(',')')[0]
							#print(string4,"括号内容：",strt,end="")
							string4=self.AltStr(string4,-3,self.Expbnow).split()[0]#-3表示不计算
#							print("经Altstr转化第四项为串：",string4)
					else:
						string4=self.AltStr(stril[3],-3,self.Expbnow).split()[0]#-3表示不计算stril[3]
#						print("经Altstr转化第四项为串：",string4)
					if(stril[2][0]=='-'):
						string2=self.ViewList[self.Expbnow+toi]
						lstring2=string2.split()
						if(len(lstring2)>=2):
							laststr2=lstring2[-1]#如果目标行为空格多项，取首项赋值
						else:
							laststr2=string2#如果目标行为空格单项，整取赋值
	
				#		lstring4=string4.split()#v0970改为整行取值
				#		if(len(lstring4)>=2):
				#			primstr4=lstring4[0]#如果目标行为空格多项，取首项赋值
				#		else:
				#			primstr4=string4#如果目标行为空格单项，整取赋值
				#		print("\t\t四项注释摘录，从",fri,"到",toi,"第4项字串[",string4,"]")
					with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
					#if f:
						i1=fri
						for i in range(int(stril[0])):
							if(stril[2]=='0'):
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+string4+"\"\n")
							elif(stril[2][0]!='-'):
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+string4+"⌇\"\n")
							elif(stril[2][0]=='-'):#赋值
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+string4+"⌇\" "+laststr2+"\n")
								#f.write(str(self.Expbnow)+" "+str(i1)+" \""+primstr4+"⌇\" "+laststr2+"\n")
							i1+=1
						f.write("\n")#方便undo操作
					#f.close()
				elif(lsl==5):
#					print("\n\t**伍项注释摘录：",AElist[i])#五项时计算，小数位按第五项，负值和0进行赋值
					i3=int(stril[2])
					i5=int(stril[4])
					if i5<0:
						i5=-i5
					if(stril[3].isdigit()):#第四项为数字时，调出该行字串
						string4=self.ViewList[self.Expbnow+int(stril[3])]#取整行，若取列用,分隔声明
					else:
						string4=stril[3]#第四项非数字时，本身作为字串
					fri=int(stril[1])-int(stril[0])+1
					toi=int(stril[1])
					string2=self.ViewList[self.Expbnow+toi]#-1
					lstring2=string2.split()
					if(len(lstring2)>=2):
						laststr2=string2.split()[-1]#如果目标行为空格多项，取最后一项为赋值变量
					else:
						laststr2=string2#如果目标行为空格单项，整取为赋值变量
#					print("\t\t五项注释摘录，从",fri,"到",toi,"第2项末串[",laststr2,"]为变量名，赋值第4项字串[",string4,"]")
					with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
						i1=fri
						for i in range(int(stril[0])-1):
							f.write(str(self.Expbnow)+" "+str(i1)+" "+"\n")
							i1+=1
						strt=self.AltStr(string4,i5,self.Expbnow).split()[0]#第四项字括号或计算式化解，取首项
						#if(strt.isdigit() and int(strt)<=Expforestep):
						#	strt=self.ViewList[self.Expbnow+int(strt)]
						if(stril[2]=='0'):#第三项0时换行(i3>0):
							if(int(stril[4])>0):#第五项>0，不赋值,但计算
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+strt+"\"\n")
							elif (int(stril[4])<=0):#第五项<0，赋值
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+strt+"\" "+laststr2+"\n")							
						else:#(i3>0):第三项非0时不换行
							if(int(stril[4])>0):#第五项>0，不赋值,但计算
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+strt+"⌇\"\n")
							elif (int(stril[4])<=0):#第五项<0，赋值
								f.write(str(self.Expbnow)+" "+str(i1)+" \""+strt+"⌇\" "+laststr2+"\n")							
						f.write("\n")#方便undo操作

		self.EIDisp()

# 296 42 (1953)

	def psplit (self,string,p1,p2):#配对分割字串
	#配对p1,p2字符分割字串string
		i=ib=0
		ls=len(string)
		#print("进入psplit,字串",string,",串长",ls)
		res=[]
		s=""
		unlock=True
		for i in range(ls):
			#print("i=",i,"unlock=",unlock,"ib=",ib)
			if(unlock):
				if(string[i]==p1):#"("
					#print("发现左边界 ",p1,end="")#括号
					if(s.strip()):
						res.append(s)
					#print(" ,左边界前字串：",s)#括号
					unlock=False
					s=p1 #"("
					ib=1
				else:
					s=s+string[i]
					if(i==ls-1):
						if(s.strip()):
							res.append(s)

			else:
				s=s+string[i]
				if(string[i]==p2):#")"
					ib-=1
				if(p1 != p2):
					if(string[i]==p1):#"("
						ib+=1
				if(ib==0 or i==ls-1):
					res.append(s)
					#print("双界内字串：",s)#括号
					unlock=True
					s=""
				#print(s)
		#print(res)
		return res

# 42 28 (2293)

	def OnOpNumber (self):#记录点选表项
		#print("\n进入操作行定位OnOpNumber\n")
		ic=self.ui.listView.currentIndex()
		i1=-1
		i=0
		for i in range(self.model.rowCount()):
			i0=self.model.item(i).index()
			if(ic==i0):
				if i not in self.NOpIdx:
					self.NOpIdx.append(i)
		#			print("正在操作第",i,"行，状态选中，添加到列表self.NOpIdx->",self.NOpIdx)
				else:
					#llast=self.NOpIdx[-1]
					#print("正在操作第",i,"行，列表最后项->",llast)
					if(i!=self.NOpIdx[-1]):
						self.NOpIdx.remove(i)
		#				print("正在操作第",i,"行……非列表最后项，取消选择，从列表删除->",self.NOpIdx)
				i1=i
				#break

			i = i + 1
		if(len(self.NOpIdx)>0):
			i1=int(self.NOpIdx[-1])
		else:
			i1=-1
		return i1

# 28 43 (2293)
	def EIndex (self):#索引摘录
		#print("\n\t进入索引摘录　EIndex")
		CheckedRowNuber=[]
		self.RedoList=[]#摘引时清空恢复表
		n=self.model.rowCount()
		for i in range(0,n):#(1,n):#v0.86
			if self.model.item(i).checkState():
				#print("\t\t共",n,"行，检索第",i,"行已勾选")
				if(i not in CheckedRowNuber ):#0.33
					CheckedRowNuber.append(i)
		if(len(CheckedRowNuber)>0):
		#	print("\t\tEIndex中self.Expbnow=",self.Expbnow,"行，选中行数：",len(CheckedRowNuber),self.RedoList)
			Indexpath=os.path.join(os.getcwd(),self.IndexFile)
			if(self.Expbnow==0):#v0.74
				f=open(Indexpath,mode='w+t',encoding='UTF-8')
				f.write(self.fileName_choose+"\n")
			else:
				f=open(Indexpath,mode='a+t',encoding='UTF-8')
			if f:
				for i in CheckedRowNuber:
					if i< self.lViewList and i!=0:#V0.94
						fi=self.ViewList[self.Expbnow+i]#获取原文件中i行字符
						si=self.model.item(i).index().data()#获取listView的i行字符
						if(self.Expfnow==0):
							Is1=str(i-1)
						else:
							Is1=str(i)
						if(i in self.NOpIdx):
#							print("勾中行",i,"同时为点中行")
							if(si==fi):#v0.94
								f.write(str(self.Expbnow)+" "+Is1+" \"⌇\"\n")
							else:
								f.write(str(self.Expbnow)+" 0 "+"\""+si+"⌇\"\n")#记录修改整行
						else:
#							print("勾中行",i,"不是点中行")
							if(si==fi):#v0.94
								f.write(str(self.Expbnow)+" "+Is1+"\n")
							else:
								f.write(str(self.Expbnow)+" 0 "+"\""+si+"\"\n")#记录修改整行
					f.write("\n")#方便undo操作
				f.close()
				self.EIDisp()

# 43 91 (2346)
	def Redo (self):#撤消恢复
	#	print("\n进入恢复Redo")
		myList=[]
		redolist=self.RedoList
		redolist.reverse()
		lr=len(self.RedoList)
		if(lr>0):
			wp=True
			while wp:
				if (lr>0):
					s1=redolist[lr-1]
	#				print("\tRedo检测字串行至[",s1,"]")
					if(s1.strip()):
						myList.append(s1)
						lr-=1
						wp=True
					else:
						wp=False
				else:
					wp=False
	#		print("\tRedo检测字串行后表",myList)

			wp=True
			wrp=False
			while wp:
				if(lr>0):
					s1=redolist[lr-1]#self.RedoList[lr-1]
	#				print("\tRedo检测空行至[",s1,"]")
					if((not s1.strip()) and (not wrp)):
						myList.append(s1)
						wrp=True
						#self.RedoList.pop()
						lr-=1
						wp=True
					else:
						wp=False
				else:
					wp=False
	#		print("\tRedo检测空行后表",myList,"RedoList",self.RedoList)
	
			redolist=redolist[:lr]
			redolist.reverse()
			Indexpath=os.path.join(os.getcwd(),self.IndexFile)
			with open(Indexpath,mode='a+t',encoding='UTF-8') as f:
				f.seek(2)#文件指针指向末尾
				for s in myList:
	#				print("\t\t\t写入Redo字符串[",s,"]")
					f.write(s+"\n")
			self.RedoList=redolist
	#		print("\n全局Redo恢复操作表",self.RedoList)
			self.EIDisp()
					

	def Undo (self):#撤消一步
	#	print("\n进入撤消Undo")
		redolist=[]
		Indexpath=os.path.join(os.getcwd(),self.IndexFile)
		with open(Indexpath,mode='r+t',encoding='UTF-8') as f:
		
			f.seek(0)#注意读取文件时候要将文件指针指向第一个
			s=f.read()
			mylist = s.split("\n")#含完整的文件路径
			lm=len(mylist)
			state=False
			for i in range(lm-1,0,-1):
				s=mylist[i]	
				if state:
					if(not s.strip()):
						ic=i
	#					print("总行数",lm,"最后",ic,"行为空行,作为Undo边界")
						break
				if(s.strip()):
					state=True

		with open(Indexpath,mode='w+t',encoding='UTF-8') as f:
			f.seek(0)#文件指针指向文件首
			for i in range(lm-1):
				s=mylist[i]	
				if(i<=ic):
					f.write(s+"\n")
				else:
					redolist.append(s)#mylist[i])
	#				print("Undo表添加元素",s)

	#		print("\n局部Undo恢复操作表",redolist)
		redolist+=self.RedoList
		self.RedoList=redolist
	#	print("\n全局Undo恢复操作表",self.RedoList)
			
		self.EIDisp()

# 91 88 (2366)
	def EIDisp (self):#索引摘录显示
		global DlgStr
		#print("\n进入摘引显示　EIDisp")
		Indexpath=os.path.join(os.getcwd(),self.IndexFile)
		CheckedRowNuber=[]
		f=open(Indexpath,mode='r+t',encoding='UTF-8')
		#print("打开摘引文件：",Indexpath)
		if f:
			f.seek(0)#注意读取文件时候要将文件指针指向第一个
			s=f.read()
			mylist = s.split("\n")#含完整的文件路径
			lm=len(mylist)
			f.close()
			f1=open(self.fileName_choose,mode='r+t',encoding='UTF-8')
			s=f1.read()
			f1.close()
			#print("打开文件：",self.fileName_choose)
			mylist1 = s.split("\n")#含完整的文件路径
			self.ui.textEdit.clear()
			linefeed=True#
			ss=""
			for i in range(1,lm):
				s=mylist[i]#从摘引文件成表中读项
				if(s.strip()):
					list2=s.split()
					l2=len(list2)#空格项数
					if(i<lm-1):
						#print("摘引文件第",i,"行:",s)
						i1=int(list2[0])+int(list2[1])
						if(l2>=3):#有附加字串self.Ignore+
							plist2=self.psplit(s,"\"","\"")
							#print("\t三以上项字串： ",s,"配对分割表：",plist2)
							if(len(plist2)>=2):#字串格式为第三项，有字符时项数为2
								sse=plist2[1][1:-1]#将字串剔除引号
							#	print("第",i,"行摘引：",s,"化整后：",int(list2[0])," ",int(list2[1]),"附加输入：",sse)
							else:
								sse=""
						if(l2>=3):
							#ss = ss+mylist1[i1]+sse
							if(list2[1]=='0'):#第二数为0时，特别处理
								if(len(list2)==3):
									ss = sse	
								elif(len(list2)==4):
									ss="⌇"							
							else:#第二数非0时，提取原文件该行字符，附加字串
								ss = mylist1[i1]+sse
							#print("\t提取",list2[0],"+",list2[1],"行，附加字串[",sse,"]后字串->",ss)
						else:#两项时只提取原文件该行字符
							#ss = ss+mylist1[i1]
							if(list2[1]=='0'):#第二数为0时，特别处理
								ss = ""								
							else:#第二数非0时，提取原文件该行字符，附加字串
								ss = mylist1[i1]
							#print("\t提取",i1,"行:",ss)
						if linefeed:#有回车符时
							if(ss.strip()):
								if(ss[-1]=='⌇'):
							#		print("\n\t",i1,"行末有⌇",ss,"去除成为：",ss[:-1])
									self.ui.textEdit.append(ss[:-1])#v0.76
								else:
									self.ui.textEdit.append(ss)#v0.76
							elif(l2>=3):#v0.961
									self.ui.textEdit.append(ss)#v0.76

						else:#无回车符时
							if(ss.strip()):
								if(ss[-1]=='⌇'):
							#		print("\n\t",i1,"行末有⌇",ss,"去除成为：",ss[:-1])
									self.ui.textEdit.moveCursor(QTextCursor.End)
									self.ui.textEdit.insertPlainText(ss[:-1])
								else:
									self.ui.textEdit.moveCursor(QTextCursor.End)
									self.ui.textEdit.insertPlainText(ss)#[:-1])
							elif(l2>=3):#v0.961
									self.ui.textEdit.append(ss)#v0.76
				if ss.strip(): #v0.55插入图片☯xx.jpg
					if (ss[0]=='☯') :
						picname=ss[1:]+'.jpg'
						self.ui.textEdit.append("<img src=\"file://"+os.path.join(os.getcwd(),"src",picname)+"\" width=\"600\">")#for Ubuntu
						#self.ui.textEdit.append("<img src=\""+os.path.join(os.getcwd(),"src",picname)+"\" width=\"600\">")#for windows
				if(ss.strip()):
					if(ss[-1]=='⌇'):
						linefeed=False
					else:
						linefeed=True#
					ss=""
		#print("退出摘引显示　EIDisp")

# 88 14 (2458)

	def Listp (self,localstr):#判断括号成对
		i2=i3=0
		n1=len(localstr)
		for i1 in range(n1):
			if(localstr[i1]=='('):
				i2+=1
			elif(localstr[i1]==')'):
				i3+=1
		if((i2 == i3) and (i2>0)):
			return True
		else:
			return False

# 14 154 (2571)

	def myfileopen (self,slecstr,n): #文件打开准备
		#print("\n进入myfileopen->",n,"新开文件名： ",slecstr)
		ExpMode=False
		mypath=os.path.join(os.getcwd(),self.OftenFiles)
		fh=False
		model=QStandardItemModel()
		if(slecstr.strip()):		
			fh=open(slecstr,mode='a+t',encoding='UTF-8')
			#if not fh:
			#	fh=open(mypath,mode='r',encoding='UTF-8')
		else:
			if(n==2):
				if(not self.fileName_choose.strip()):
					#print("首次打开……")
					self.fileName_choose=mypath#v0.60-
					picname='微信打赏.jpg'
					item = QStandardItem("欢迎随宜打赏鼓励……软件源代码公开，服务收费是自由软件的通行模式，支持有偿服务请QQ625052847，参考标准$5/分钟。"+self.promptstr1)
					#item.setCheckState(False)
					#item.setCheckable(True)
					model.clear()
					model.appendRow(item)						
					model.item(0).setIcon(QIcon(os.path.join(os.getcwd(),"src",picname)))

					self.ui.listView_2.setIconSize(QSize(300,300))
					self.ui.textEdit.append("<img src=\"file://"+os.path.join(os.getcwd(),"src",'搜笈互助群.png')+"\" width=\"280\">")#for Ubuntu
					#self.ui.textEdit.append("<img src=\""+os.path.join(os.getcwd(),"src",'搜笈互助群.png')+"\" width=\"280\">")#for windows
		if fh:
			fh.seek(0)
			data=fh.read()
			#print("完成打开文件->",slecstr)
			#print("<-。文件字符：\n",data)
			fh.close()
			self.DLFmt(data)#v0.89
			mylist = data.split("\n")
			model = QStandardItemModel()
			#print("self.fileName_choose=",self.fileName_choose," ? mypath=",mypath)
			lie=mylist[0].split()
			lcol=len(lie)
			if(lcol>=2):
				#print("首项转成列表：\t",lie)
				if(lie[self.Ignore+1][-1]=='0' and lie[self.Ignore+2].isdigit()):
					self.ExpMode=True
					self.lViewList=len(mylist)
					self.ViewList=mylist
					self.Expbackstep=0
					self.Expforestep=int(lie[self.Ignore+2])
					self.Expbnow=0#V0.75
					self.Expfnow=0
					#print(slecstr,"判断为专用模式文件！")
			#		print("文件初打开，回跳位置",self.Expbnow,"回跳步长：",self.Expbackstep,"前跳位置",self.Expfnow,"前跳步长：",self.Expforestep)		
				else:
					self.ExpMode=False
					#print(slecstr,"判断为非专用模式文件！")
			else:
				self.ExpMode=False
				#print(slecstr,"为非专用模式文件！")

			i=0
			i1=0#格式行
			if not self.ExpMode:#非专用文件
				for task in mylist:
					#print("i=",i,",i1=",i1)
					if(self.fileName_choose==mypath):#当打开oftenfiles.set文件时
						lstr=os.path.split(task)[1]#忽略路径，只取文件名，成文库目录
						item = QStandardItem(lstr)
						item.setCheckState(False)
						item.setCheckable(True)
					else:	
						item = QStandardItem(task)
						item.setCheckState(False)
						item.setCheckable(True)
					if i == 0 :
						item1 = QStandardItem(self.prompstr)
						item1.setCheckState(False)
						item1.setCheckable(True)
						model.clear()
						model.appendRow(item1)
						model.appendRow(item)
					else:
						model.appendRow(item)
						if task.strip(): #v0.56插入图片☯xx.jpg
							if (task[0]=='☯') :
								picname=os.path.join("src",task[1:]+".jpg")
								model.item(i+1).setIcon(QIcon(picname))
								if(n==1):
									self.ui.listView.setIconSize(QSize(self.PicSize,self.PicSize))
								if(n==2):
									self.ui.listView_2.setIconSize(QSize(self.PicSize,self.PicSize))
					i=i+1
			else:#Expert mode专用文件
				for task in mylist:
					if(self.fileName_choose==mypath):#打开oftenfiles.set设置文件时
						lstr=os.path.split(task)[1]#取文件的名
						item = QStandardItem(lstr)
						item.setCheckState(False)
						item.setCheckable(True)
					else:	
						if(i==i1):#v0.73打开其它文件时，格式空置显示
							#print("i=",i,",i1=",i1)
							#item = QStandardItem("")
							if self.FormatShow:
								item = QStandardItem(self.ViewList[i])
							else:
								item = QStandardItem("")

						else:
							item = QStandardItem(task)
						item.setCheckState(False)
						item.setCheckable(True)

					if i == 0 :#首页首项显示提示
						item1 = QStandardItem(self.prompstr)
						item1.setCheckState(False)
						item1.setCheckable(True)
						model.clear()
						model.appendRow(item1)#兼容模式首页多此一行
	
						if(i==i1):#v0.73格式行
							if(i<self.lViewList-2):
								lie=mylist[i1].split()
								if(self.Ignore+2<len(lie)):
									i1=i+int(lie[self.Ignore+2])+1#定位下一个格式行
									#print("\t兼容首页当前格式行i=",i,",下一个格式行i1=",i1)
						model.appendRow(item)
					else:#i!=0兼容模式非首页首项
						if(i==i1):#v0.73
							if(i<self.lViewList-2):
								lie=mylist[i1].split()
								if(self.Ignore+2<len(lie)):
									i1=i+int(lie[self.Ignore+2])+1
									#print("\t当前格式行i=",i,",下一个格式行i1=",i1)
						model.appendRow(item)
						if task.strip(): #v0.56插入图片☯xx.jpg
							if (task[0]=='☯') :
								picname=os.path.join("src",task[1:]+".jpg")
								model.item(i+1).setIcon(QIcon(picname))
								if(n==1):
									self.ui.listView.setIconSize(QSize(self.PicSize,self.PicSize))
								if(n==2):
									self.ui.listView_2.setIconSize(QSize(self.PicSize,self.PicSize))
					i=i+1

		if(model):
			if(n==1):
				self.model=model
				self.ui.listView.setModel(self.model)
			elif(n==2):
				self.model2=model
				self.ui.listView_2.setModel(self.model2)
		self.NOpIdx=[]#v0.76清空多选项表
		self.ui.show()
#		self.show()

# 154 114 (2605)

	def SearchUp(self):#文件及列表搜索响应
#		print("进入SearchUp搜索->")
		FullStep=False
		ss=self.model.item(0).index().data()#获取listView的0行字符***
		if(self.Expfnow==0):
			i=self.model.item(0).checkState()
			if(i>0):
				FullStep=True
			localpath=os.path.join(os.getcwd(),self.OftenFiles)
			print("localpath=",localpath,"\nfileName_choose=",self.fileName_choose,"=?\t搜索关键字"	,ss)
			if(localpath==self.fileName_choose):
				if FullStep:
					self.SearchFile(localpath,ss)
				else:
					self.SearchRow(1,FullStep,ss)
			else:
				self.SearchRow(1,FullStep,ss)
			self.prompstr=ss#v0.54
		else:#if(self.ExpMode):
			self.SearchExp(ss)

	def SearchExp(self,ss):
		sslist2=[]
#		v0.54由空格及'、'表解构并行搜索项数
		sslistt=[]
		sslist1=[]
		sym=[' ','、']
		sslistt.extend(ss.split(sym[0]))
		i=0
		li=len(sslistt)
		for sp in  sym[1:]:
			for i in range(len(sslistt)):
				ss1=sslistt[i]
				if(ss1.find(sp)>=0):
					sslist1.extend(ss1.split(sp))
				else:
					if ss1.strip():
						sslist1.append(ss1)
				if(i==li-1):
					sslistt=sslist1
					li=len(sslistt)
					sslist1=[]
	#			print("i=",i,"\t列表变化：",sslist1)
		sslist1=sslistt
	#	print("\t关键字'、'拆分后列表结果：",sslist1)

		lenl1=len(sslist1)
		for i1 in range(lenl1):
			if(sslist1[i1].find(";")>=0):
	#			print("搜索关键字中含';'")
				sslist2=sslist1[i1].split(";")#";"解构多条件搜索	
	#			print("\n多条件关键字集sslist2=",sslist2)
			elif(sslist1[i1].find("；")>=0):
	#			print("搜索关键字中含中文'；'")
				sslist2=sslist1[i1].split("；")#中文"；"解构多条件搜索	
	#			print("\n多条件关键字集sslist2=",sslist2)
		lenl2=len(sslist2)

		if(self.PosFound<0):
			self.PosFound=-1
	#	print("搜索起始点",self.PosFound)
		exitp=False
		for i in range(self.PosFound+1,self.lViewList):
			print(" ",i," ",end="")
			s=self.ViewList[i]
			for i1 in range(lenl1):#并集搜索
				if(sslist2):
					i2p=0
					for i2 in range(lenl2):#交集搜索
						newpos2=s.find(sslist2[i2])
						#print("\t\t\t位置",i,"行，交集搜索第[",i2,"]项条件[",sslist2[i2],"]")
						if (newpos2>=0):
	#						print("交集搜索发现关键字",sslist2[i2])
							i2p+=1
					if(i2p>=len(sslist2)):
	#					print("\n\t\t",i,"行[",s,"]匹配交集搜索所有条件")
						self.PosFound=i
						exitp=True
						break
				if(exitp):
					break
				if(s.find(sslist1[i1])>=0):
					self.PosFound=i
	#				print("\n\t\t",i,"行[",s,"]发现并集搜索条件")
					exitp=True
					break
			if(exitp):
				break
			
	#	print("\n\n搜索锁定",self.PosFound)
		if(i==self.lViewList-1):
			self.PosFound=-1
		if(self.PosFound>self.Expbnow and self.PosFound<self.Expfnow):
			si=self.model.item(self.PosFound-self.Expbnow).index()
			self.ui.listView.setCurrentIndex(si)#定位
			
		if(self.PosFound>self.Expfnow or (self.PosFound<self.Expbnow and self.PosFound>0)):
	#		print("\n\t",self.PosFound,"行不在本页",self.Expbnow,"~",self.Expfnow,"，定位格式行准备显示该页")
			for i in range(self.PosFound,0,-1):#定位格式行
				print(" ",i," ",end="")
				if(len(self.ViewList[i].split())>self.Ignore+2):
					loclist=self.ViewList[i].split()
					if(loclist[self.Ignore+1].isdigit()):
						if(loclist[self.Ignore+2].isdigit()):
							self.Expbnow=i
							self.Expfnow=self.Expbnow+int(loclist[self.Ignore+2])+1
	#						print("\t\t搜索结果格式行位置",self.Expbnow,"行，本页至",self.Expfnow,"行")
							self.ExpView(self.Expbnow,self.Expfnow)#显示整页
							self.FirstLine(ss)#将搜索关键字显示于首行
							si=self.model.item(self.PosFound-i).index()#获取所在行的索引号
							self.ui.listView.setCurrentIndex(si)#定位索引号行
							break
			
# 114 12 (2760)

	def SearchLow(self):#列表搜索响应
		#print("进入SearchLow搜索->")
		FullStep=False
		i=self.model2.item(0).checkState()
		if(i>0):
			FullStep=True
		ss=self.model2.item(0).index().data()
		#print("\t搜索关键字ss=",ss,"\t连续搜索：",FullStep)

		self.SearchRow(2,FullStep,ss)

# 12 233 (2856)

	def SearchFile (self,lpath,ss):#文件搜索
		bratio=0.05 #0.49空行比，决定搜索结果是否扩展至空行
		Fruitpath=os.path.join(os.getcwd(),self.FruitFile)
		#print("进入SearchFile搜索->",ss,"\t当前打开文件：",self.fileName_choose)
		if((ss[0]=='`') or (ss[0]=='｀')) :
			Ltdp=True#v0.54
			ss=ss[1:]	
#			print("首字为`或｀进入有界搜索，关键字->",ss)
		else:
			Ltdp=False#v0.54
		sslist2=[]
#		v0.54由空格及'、'表解构并行搜索项数
		sslistt=[]
		sslist1=[]
		sym=[' ','、']
		sslistt.extend(ss.split(sym[0]))
		i=0
		li=len(sslistt)
		for sp in  sym[1:]:
			for i in range(len(sslistt)):
				ss1=sslistt[i]
				if(ss1.find(sp)>=0):
					sslist1.extend(ss1.split(sp))
				else:
					if ss1.strip():
						sslist1.append(ss1)
				if(i==li-1):
					sslistt=sslist1
					li=len(sslistt)
					sslist1=[]
#				print("i=",i,"\t列表变化：",sslist1)
		sslist1=sslistt
#		print("\t关键字'、'拆分后列表结果：",sslist1)

		lenl1=len(sslist1)
		for i1 in range(lenl1):
			if(sslist1[i1].find(";")>=0):
#				print("搜索关键字中含';'")
				sslist2=sslist1[i1].split(";")#","解构多条件搜索	
#				print("\n多条件关键字集sslist2=",sslist2)
			elif(sslist1[i1].find("；")>=0):
#				print("搜索关键字中含中文'，'")
				sslist2=sslist1[i1].split("，")#中文"，"解构多条件搜索	
#				print("\n多条件关键字集sslist2=",sslist2)
		lenl2=len(sslist2)
		fh1=open(lpath,mode='r+t',encoding='UTF-8')
		fh2=open(Fruitpath,mode='a+t',encoding='UTF-8')
#		fh2=TemporaryFile('w+t',encoding='utf-8' )
		if fh2:
			fh2.close
			fh2=open(Fruitpath,mode='w+t',encoding='UTF-8')
			fh2.write("搜索关键字：\t"+ss+"\n")

		if fh1:
			fh1.seek(0)#文件指针指向首位
			data=fh1.read()
			mylist = data.split("\n")#含完整的文件路径
		fh1.close()

#		if(self.PosFound==-1):
#			i=1
#		else:
#			i=self.PosFound
#		print("\n\ti=",i,"行发现,指针定位->",self.PosFound)
		it=len(mylist)
		for it1 in range(1,it):#按序打开文件
			if self.model.item(it1).checkState():
				if(mylist[it1-1].strip()):
					lfilename=os.path.join("src",mylist[it1-1])
					#linecount=len([ "" for line in open(lfilename,"r")])#统计文件行数黑客代码
	
					fh1=open(lfilename,mode='r+t',encoding='UTF-8')
					if fh1:
#						print("\t\t打开文件：",lfilename)
						fh1.seek(0)
						data=fh1.read()
						listt = data.split("\n")#含完整的文件路径
					fh1.close()
					it2=len(listt)#每个文件中的表项数
	
					blinecount=0
					for data in listt:#统计空行数
						if data=="":
							blinecount+=1

					if(blinecount/it2>bratio):#空行比是否较大
						srchexpand=True#扩展搜索结果
						ib=0#记录前一个空行号
					else:
						srchexpand=False
#					print("文件:",lfilename,"共",it2,"\t行，空行：",blinecount,"\t行，空行比",blinecount/it2)

					i=0
					ifirst=0
					slestate=False
					while (i<it2):
						s=listt[i]#获取文件字符
#						print("第",i,"行：",s)
	
						if not s.strip():
							ib=i
						if slestate:
#							print("入选字符：\t",s)
							if not s.strip():
								fh2.write(s+"\n")
								slestate=False
#								print("入选字符已至空行",i)
#						else:
#							print("未入选字符：\t",s)
						if slestate:
							fh2.write(s+"\n")
						else:	
							printed=False
							for i1 in range(lenl1):
								if(sslist2):
									i2p=0
									for i2 in range(lenl2):
										newpos2=s.find(sslist2[i2])
#										print("Search i2=",i2,"\t",sslist2[i2],"newpos2=",newpos2)
										if (newpos2>=0):
											#v0.54有界搜索
											if Ltdp:
												newpos2e=newpos2+len(sslist2[i2])-1
												if(newpos2==0):
													if(newpos2e<len(s)-1):
														if not (s[newpos2e].isdigit() and s[newpos2e+1].isdigit()):
															#print(i,"行右界数文转变")
															i2p+=1
													elif (newpos2e==len(s)-1):
														#print(i,"右界尽")
														i2p+=1
												else:
													if(newpos2e<len(s)-1):
														if not (s[newpos2e].isdigit() and s[newpos2e+1].isdigit()):
															#print(i,"行右界数文转变")
															if not (s[newpos2].isdigit() and s[newpos2-1].isdigit()):
																#print(i,"行左界数文转变")
																i2p+=1
													elif (newpos2e==len(s)-1):
														#print(i,"右界尽")
														if not (s[newpos2].isdigit() and s[newpos2-1].isdigit()):
															#print(i,"行左界数文转变")
															i2p+=1
	
											else:
												#print(i,"行发现无界搜索关键字->\t",sslist2[i2])
												i2p+=1
										if(i2p>=lenl2):
#											print("\n\t本行多条件匹配：",s)
											PosFound=i+1
										if(srchexpand):
											slestate=True
										if(not printed):#0.52
											if(ifirst==0):
												fh2.write("「 "+os.path.split(lfilename)[1]+" 」\t文件中搜索结果：\n")	
												ifirst=1
#											print("搜索[",ss,"]字符在",PosFound,"行发现,写入文件->",Fruitpath)	
											if slestate:
												for i3 in range(ib,i-1):
													fh2.write(listt[i3]+"\n")
												fh2.write("＝＝＝＝＝＝\n")
		
											fh2.write(s+"\n")
		
											if slestate:
												fh2.write("＝＝＝＝＝＝\n")
											printed=True#0.52
								else:
									newpos1=s.find(sslist1[i1])
									#print("搜索关键字中不含中英文','，字串",s,"位置",newpos1,"关键字：",sslist1[i1],"……开始有界检测")
									if(newpos1>=0):#发现搜索字符
										#v0.54有界搜索
										i2p=0
										if Ltdp:
											newpos1e=newpos1+len(sslist1[i1])-1
#											print(i,"行",newpos1,"~",newpos1e,"列发现无‘，’有界搜索关键字->\t",sslist1[i1])
											if(newpos1==0):
#												print("newpos1==0\tnewpos1e=",newpos1e)
												if(newpos1e<len(s)-1):
													if not (s[newpos1e].isdigit() and s[newpos1e+1].isdigit()):
														#print("右界数文转变")
														i2p+=1
												elif (newpos1e==len(s)-1):
													#print("右界尽",s[newpos1e])
													i2p+=1
											else:
												if(newpos1e<len(s)-1):
													if not (s[newpos1e].isdigit() and s[newpos1e+1].isdigit()):
														#print("右界数文转变")
														if not (s[newpos1].isdigit() and s[newpos1e-1].isdigit()):
															#print("左界数文转变")
															i2p+=1
												elif (newpos1e==len(s)-1):
													#print("右界尽",s[newpos1e])
													if not (s[newpos1].isdigit() and s[newpos1e-1].isdigit()):
														#print("左界数文转变")
														i2p+=1
										else:
#											print(i,"行发现无‘，’无界搜索关键字->\t",sslist1[i1])
											i2p+=1
										if(i2p>=1):
	
											PosFound=i+1
											if(srchexpand):
												slestate=True
											if(not printed):#0.52
												if(ifirst==0):
													fh2.write("\n\t「 "+os.path.split(lfilename)[1]+" 」\t文件中搜索结果：\n")	
													ifirst=1
#												print("搜索[",ss,"]字符在",PosFound,"行发现,写入文件->",Fruitpath)
												if slestate:
													for i3 in range(ib,i-1):
														fh2.write(listt[i3]+"\n")
													fh2.write("＝＝＝＝＝＝\n")
			
												fh2.write(s+"\n")
			
												if slestate:
													fh2.write("＝＝＝＝＝＝\n")
												printed=True#0.52
#										else:
#											print("无有界搜索结果，i2p=",i2p)
		
						i+=1
					if(i==it2):
						PosFound=1
						#print("\n***搜索文件：",lfilename,"到达尾部***\n")
	
		if fh2:
			fh2.close()
		self.displayextract()

# 233 238 (2888)

	def SearchRow (self,n,FullStep,ss):#列表搜索
#		print("进入SearchRow搜索->",n,"关键字： ",ss,"连续搜索",FullStep)
		if(n==1):#搜索上栏
			model=self.model
		elif (n==2):#搜索下栏
			model=self.model2
		sst=ss
		ls=len(sst)
		ik1=sst.find('(')
		ik2=sst.find(')')
		treatp=False
		if(ik1>=0):
			treatp=True
			while(ik1>=0):
				if(ik1>0):
					#print("发现左括号，开始去除……")
					if(ik2>=0):
						if(ik2>ik1):
							sst=sst[0:ik1]+sst[ik2+1:ls]
							#print("发现右括号，字符串去括号后成为:\t",sst)
						else:
							sst=sst[ik2+1:ik1]
							#print("未发现右括号，字符串去括号后成为:\t",sst)
					else:
						sst=sst[0:ik1]
					ik1=sst.find('(')
					ik2=sst.find(')')
			#print("处理小括号后关键字为： ",sst)
		ls=len(sst)
		ik1=sst.find('（')
		ik2=sst.find('）')
		if(ik1>=0):
			treatp=True
			while(ik1>=0):
				if(ik1>0):
					#print("发现左括号，开始去除……")
					if(ik2>=0):
						if(ik2>ik1):
							sst=sst[0:ik1]+sst[ik2+1:ls]
							#print("发现右括号，字符串去括号后成为:\t",sst)
						else:
							sst=sst[ik2+1:ik1]
							#print("未发现右括号，字符串去括号后成为:\t",sst)
					else:
						sst=sst[0:ik1]
					ik1=sst.find('（')
					ik2=sst.find('）')
			#print("处理大括号后关键字为： ",sst)
		if treatp:		
			ss=sst
			#print("括号处理后关键字为： ",ss)

		if((ss[0]=='`') or (ss[0]=='｀')) :
			Ltdp=True#v0.54
			ss=ss[1:]	
			#print("首字为`或｀进入有界搜索，关键字->",ss)
		else:
			Ltdp=False#v0.54

		sslist2=[]
#		v0.54由空格及'、'表解构并行搜索项数
		sslistt=[]
		sslist1=[]
		sym=[' ','、']
		sslistt.extend(ss.split(sym[0]))
		i=0
		li=len(sslistt)
		for sp in  sym[1:]:
			for i in range(len(sslistt)):
				ss1=sslistt[i]
				if(ss1.find(sp)>=0):
					sslist1.extend(ss1.split(sp))
				else:
					if ss1.strip():
						sslist1.append(ss1)
				if(i==li-1):
					sslistt=sslist1
					li=len(sslistt)
					sslist1=[]
#				print("i=",i,"\t列表变化：",sslist1)
		sslist1=sslistt
#		print("\t关键字'、'拆分后列表结果：",sslist1)

		lenl1=len(sslist1)
		for i1 in range(lenl1):
			if(sslist1[i1].find(";")>=0):
#				print("搜索关键字中含';'")
				slist2=sslist1[i1].split(";")#";"解构多条件搜索	
#				print("\n多条件关键字集sslist2=",sslist2)
			elif(sslist1[i1].find("；")>=0):
#				print("搜索关键字中含中文'，'")
				sslist2=sslist1[i1].split("；")#中文"；"解构多条件搜索	
#				print("\n多条件关键字集sslist2=",sslist2)
		lenl2=len(sslist2)
		slestate=False

		if(self.PosFound==-1):
			i=1
		else:
			i=self.PosFound
#		print("\n\ti=",i,"行已发现关键字,指针定位->",self.PosFound)

		it=model.rowCount()

		while (i<it):
			s=model.item(i).index().data()#获取字符
#			print("第",i,"项：",s)
			if slestate:
#				print("入选字符：\t",s)
				slestate=False
#				print("入选字符已至空行",i)
			else:
				print("未入选字符：\t",s)
			if slestate:
				itemc=model.item(i)
				itemc.setData(QVariant(Qt.Checked),Qt.CheckStateRole)#改变索引行勾选态***
				si=model.item(i).index()#获取所在行的索引号***
				if(n==1):
					self.ui.listView.setCurrentIndex(si)#定位索引号行***
				elif(n==2):
					self.ui.listView_2.setCurrentIndex(si)#定位索引号行***
			else:	
				for i1 in range(lenl1):
					if(sslist2):
						i2p=0
						for i2 in range(lenl2):
							newpos2=s.find(sslist2[i2])
#							print("Search i2=",i2,"\t",sslist2[i2],"newpos2=",newpos2)
							if (newpos2>=0):
								#print("交集搜索发现关键字",sslist2[i2])

								#v0.54有界搜索
								if Ltdp:
									newpos2e=newpos2+len(sslist2[i2])-1
									if(newpos2==0):
										if(newpos2e<len(s)-1):
											if not (s[newpos2e].isdigit() and s[newpos2e+1].isdigit()):
												#print("右界数文转变")
												i2p+=1
										elif (newpos2e==len(s)-1):
											#print(i,"到达右边界")
											i2p+=1
									else:
										if(newpos2e<len(s)-1):
											if not (s[newpos2e].isdigit() and s[newpos2e+1].isdigit()):
												#print("右界数文转变")
												if not (s[newpos2].isdigit() and s[newpos2-1].isdigit()):
													#print("左界数文转变")
													i2p+=1
										elif (newpos2e==len(s)-1):
											#print(i,"到达右边界")
											if not (s[newpos2].isdigit() and s[newpos2-1].isdigit()):
												#print("左界数文转变")
												i2p+=1
								else:
									#print(i,"行发现无界搜索关键字->\t",sslist2[i2])
									i2p+=1

						if(i2p>=len(sslist2)):
#							print("\n\t本行多条件匹配：",s)
							self.PosFound=i+1
	
							slestate=True
							print("搜索[",ss,"]字符在",i,"行发现,指针定位->",self.PosFound)
							itemc=model.item(i)
							itemc.setData(QVariant(Qt.Checked),Qt.CheckStateRole)#改变索引行勾选态***
							if not FullStep:
								si=model.item(i).index()#获取所在行的索引号***
								if(n==1):
									self.ui.listView.setCurrentIndex(si)#定位索引号行***
									self.ui.listView.scrollTo(si)#ScrollHint(i)#setSelection(i)
								elif(n==2):
									self.ui.listView_2.setCurrentIndex(si)#定位索引号行***
									self.ui.listView_2.scrollTo(si)#ScrollHint(i)#setSelection(i)
								i=it
								print("\n\t0行没有勾选,标记搜索位置后，搜索暂停\t")
								break
						
					else:
						print("搜索关键字中不含';'")
						newpos1=s.find(sslist1[i1])
						if(newpos1>=0):#发现0项字符
							print(s,"\t并集搜索发现关键字\t",sslist1[i1])
							i2p=0

							if Ltdp:
								newpos1e=newpos1+len(sslist1[i1])-1
								if(newpos1==0):
									if(newpos1e<len(s)-1):
										if not (s[newpos1e].isdigit() and s[newpos1e+1].isdigit()):
											#print("右界数文转变")
											i2p+=1
									elif (newpos1e==len(s)-1):
										#print(i,"到达右边界")
										i2p+=1
								else:
									if(newpos1e<len(s)-1):
										if not (s[newpos1e].isdigit() and s[newpos1e+1].isdigit()):
											#print("右界数文转变")
											if not (s[newpos1].isdigit() and s[newpos1-1].isdigit()):
												#print("左界数文转变")
												i2p+=1
									elif (newpos1e==len(s)-1):
										#print(i,"到达右边界")
										if not (s[newpos1].isdigit() and s[newpos1-1].isdigit()):
											#print("左界数文转变")
											i2p+=1

							else:
								print(i,"行发现无‘，’无界搜索关键字->\t",sslist1[i1])
								i2p+=1
							if(i2p>=1):

								self.PosFound=i+1
	
								slestate=True
								print("搜索[",ss,"]字符在",i,"行发现,指针定位->",self.PosFound)
								itemc=model.item(i)
								itemc.setData(QVariant(Qt.Checked),Qt.CheckStateRole)#改变索引行勾选态***
								if not FullStep:#如果0行没有勾选，到第一个搜索位置就中止，否则全文件搜索标记
									#self.ui.listView.setFocus()#v0.54
									si=model.item(i).index()#获取所在行的索引号***
									if(n==1):
										self.ui.listView.setCurrentIndex(si)#定位索引号行***
										self.ui.listView.scrollTo(si)#ScrollHint(i)#setSelection(i)
									elif(n==2):
										self.ui.listView_2.setCurrentIndex(si)#定位索引号行***
										self.ui.listView_2.scrollTo(si)#ScrollHint(i)#setSelection(i)
									i=it
									break

			i+=1
		print("\n搜索到达\t",i,"/",it)
		if(i==it):
			self.PosFound=1
			print("\n***搜索到达尾部***\n")

# 238 7 (3122)
	
	def AddItem (self):#点选行后增加行
#		print("进入AddItem")
		lnum=self.OnOpNumber()#1016
		lstr=self.model.item(0).index().data()#获取0行字符
		self.AddItemView(lnum,lstr)

# 7 43 (3361)

	def AddItemView (self,lnum,lstr):#顶行添至点选行后
#		print("进入AddItemView")
		mylist=[]
		for i in range(self.model.rowCount()):
			s=self.model.item(i).index().data()#获取字符
#			print("第",i,"项：",s)
			mylist.append(s)
			if(i==lnum):#操作行时，将0行字符插入列表
#				print("插入",i+1,"项：",lstr)
				mylist.append(lstr)
		i=0
		for task in mylist:
			item = QStandardItem(task)
			item.setCheckState(False)
			item.setCheckable(True)
			if i == 0 :
				self.model.clear()
				self.model.appendRow(item)
			else :
				self.model.appendRow(item)
			self.ui.listView.setModel(self.model)
			i=i+1
		i=0
		it=self.model.rowCount()
#		print("\tAddItem表有",it,"项")
		for i in range(it):
#			print("第",i,"项：")
			if(i<=lnum):
				if(i in self.CheckedRowNuber):
#					print("插入行前第",i,"行在选中表中")
					it=self.model.item(i)
					it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)
			if(i>lnum):
				if(i-1 in self.CheckedRowNuber):
#					print("插入行后第",i-1,"行在选中表中")
					it=self.model.item(i)
					it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)
			i+=1

		self.ui.show()
#		self.show()			

# 43 6 (3369)

	def DelItem (self):#删除点选项
#		print("进入DelItem")
		lnum=self.OnOpNumber()#1016
		self.DelItemView(lnum)

# 6 40 (3413)

	def DelItemView (self,lnum):#删除表显项
#		print("进入DelItemView")
		mylist=[]
		for i in range(self.model.rowCount()):
			s=self.model.item(i).index().data()#获取字符
#			print("第",i,"项：",s)
			if(i!=lnum):#至所删行时，跳过列表
				mylist.append(s)
		i=0
		for task in mylist:
			item = QStandardItem(task)
			item.setCheckState(False)
			item.setCheckable(True)
			if i == 0 :
				self.model.clear()
				self.model.appendRow(item)
			else :
				self.model.appendRow(item)
			self.ui.listView.setModel(self.model)
			i=i+1
		i=0
		it=self.model.rowCount()
#		print("\tAddItem表共有",it,"项")
		for i in range(it):
#			print("第",i,"项：")
			if(i<lnum):
				if(i in self.CheckedRowNuber):
#					print("所删行前第",i,"行在选中表中")
					it=self.model.item(i)
					it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)
			if(i>lnum):
				if(i in self.CheckedRowNuber):
#					print("所删行后第",i-1,"行在选中表中")
					it=self.model.item(i)
					it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)

		self.ui.show()
#		self.show()			

# 40 27 (3420)

	def Extract (self):#手动摘录
		#print("\n进入手动摘录　Extract")
		Fruitpath=os.path.join(os.getcwd(),self.FruitFile)
		for i in range(1,self.model.rowCount()):#0.33
			if self.model.item(i).checkState():
#				print("检索第",i,"行已选中")
				if(i not in self.CheckedRowNuber ):#0.33
					self.CheckedRowNuber.append(i)
#		print(self.CheckedRowNuber)
#		f = TemporaryFile('w+t',encoding='utf-8' )
		#print("self.Expbnow=",self.Expbnow)
		if(self.Expfnow==0):
			with open(Fruitpath,mode='w+t',encoding='UTF-8') as f:
				for i in self.CheckedRowNuber:
#					print("\n梳理选中的第",i,"项，写入文件")
					s=self.model.item(i).index().data()
#					print("\t\t选中项字符：",s)          
					if(i in self.NOpIdx):
#						print("勾中行",i,"同时为点中行")
						f.write(s+"⌇\n")
					else:
						f.write(s+"\n")
			self.displayextract()
		else:
			self.EIndex()

# 27 42 (3461)

	def displayextract (self):#编辑框显示摘录
		Fruitpath=os.path.join(os.getcwd(),self.FruitFile)
		f=open(Fruitpath,mode='r+t',encoding='UTF-8')
		if f:
			f.seek(0)#注意读取文件时候要将文件指针指向第一个
			s=f.read()
			mylist = s.split("\n")#含完整的文件路径
			f.close()
			self.ui.textEdit.clear()
			linefeed=True
			for s in mylist:
				if(s.strip()):
				#	if linefeed:
				#		self.ui.textEdit.append(s)#v0.76
				#	else:
				#		self.ui.textEdit.moveCursor(QTextCursor.End)
				#		self.ui.textEdit.insertPlainText(s[:-1])
					if linefeed:
						if(s[-1]=='⌇'):
							self.ui.textEdit.append(s[:-1])#v0.76
						else:
							self.ui.textEdit.append(s)#v0.76
					else:
						if(s[-1]=='⌇'):
							self.ui.textEdit.moveCursor(QTextCursor.End)
							self.ui.textEdit.insertPlainText(s[:-1])
						else:
							self.ui.textEdit.moveCursor(QTextCursor.End)
							self.ui.textEdit.insertPlainText(s)

						linefeed=True
					if(s[-1]=='⌇'):
						linefeed=False
				#if s.strip(): #v0.55插入图片☯xx.jpg
					if (s[0]=='☯') :
						picname=s[1:]+'.jpg'
						self.ui.textEdit.append("<img src=\"file://"+os.path.join(os.getcwd(),"src",picname)+"\" width=\"600\">")#for Ubuntu
						#self.ui.textEdit.append("<img src=\""+os.path.join(os.getcwd(),"src",picname)+"\" width=\"600\">")#for windows
				else:
					self.ui.textEdit.append(s)#v0.76

# 42 14 (3489)
					
	def CopyText(self):#顶显点选行或结果
#		print("\n进入　CopyText,listview 共",self.model.rowCount(),"行")
		i=self.OnOpNumber()
#		print("\t获取正在操作行i=",i)
		if(i==0):
#			print("listview 显示文件名：",self.fileName_choose)
			self.FirstLine(self.fileName_choose)
		else:
			slecstr=self.model.item(i).index().data()#获取列表字符***
			self.myStr=slecstr
#			print("\ti=",i,"字符slecstr=",slecstr)
			self.FirstLine(slecstr)

# 14 6 (3532)

	def FirstLine(self,myStr):#顶行更新
		i1=self.model.item(0).index()#获取0行索引
		self.model.setData(i1, myStr)#更新0行数据
		self.ui.listView.setModel(self.model)

# 6 29 (3547)
	
	def JustCheckedNumber (self):#获取最新勾选的行号
#		print("进入获取最新　勾选　行号方法\n")
#		print("勾选　行序号表",self.CheckedRowNuber)
		i=0
		if(len(self.CheckedRowNuber)==0):
			for i in range(self.model.rowCount()):
				if self.model.item(i).checkState():
					self.JustNum=i
#					print("\n\t只选中一项，为第",i,"行……")
					break
				i = i + 1
		else:
			for i in range(self.model.rowCount()):
				if self.model.item(i).checkState():
					if i not in self.CheckedRowNuber:
						self.JustNum=i
#						print("\n\t不在表中，刚选第",self.JustNum,"行……")
				i = i + 1
		self.CheckedRowNuber=[]
		i=0
		for i in range(self.model.rowCount()):
			if self.model.item(i).checkState():
#				print("选中第",i,"行……",self.mylist[i])
				self.CheckedRowNuber.append(i)
			i = i + 1
#		print("\n\t勾选　行序号表",self.CheckedRowNuber)
#		print("\n\t***刚选中第",self.JustNum,"行")

# 29 23 (3554)
		
	def ViewOp (self):#表项响应
#		print("\n\t列表操作")
		it1=self.OnOpNumber()
		self.JustCheckedNumber()
		if (it1==0):#0行选中全表选中，0行消勾二次，全表取消
			if (self.JustNum!=-1):
				if(self.JustNum==0):
					if self.model.item(0).checkState():
						i=0
						for i in range(self.model.rowCount()):
							it=self.model.item(i)
							it.setData(QVariant(Qt.Checked),Qt.CheckStateRole)
#							print("\t复选第",i,"项")
							i+=1
					else:
						i=0
						for i in range(self.model.rowCount()):
							it=self.model.item(i)
							it.setData(QVariant(Qt.Unchecked),Qt.CheckStateRole)
#							print("\t\t取消复选第",i,"项")
							i+=1

# 23 53 (3565)
			
	def	slot_btn_chooseFile (self):#库文件操作
#		print("选择方法中全局文件名为:",self.fileName_choose)#测试全局变量
		if self.fileName_choose.strip():#v0.4中转打开的非库文件
			filet=self.fileName_choose
		self.fileName_choose,filetype = QFileDialog.getOpenFileName(self,
									"选择库文件或在列文件可以实际更新",
									self.cwd,# 起始路径 
									"All Files (*);;Setfiles(*.set);;Pthon Files (*.py);;Text Files (*.txt);;向导文件(*.xdf)")# 设置文件扩展名过滤,用双分号间隔

		mypath=os.path.join(os.getcwd(),self.OftenFiles)
		mylist1=[]
		lnum=self.OnOpNumber()
		if lnum<0:
			lnum=0
#		print("常用文件路径：",mypath,"当前操作lnum=",lnum,"行")
		fh=open(mypath,mode='a+t',encoding='UTF-8')
		if fh:
			fh.seek(0)#注意读取文件时候要将文件指针指向第一个
			data=fh.read()
			mylist = data.split("\n")
#			print("完成打开文件，准备读取->",mypath,"。文件字符:\n",data,"转列表为：\n",mylist)
			if os.path.basename(self.fileName_choose) not in mylist:
				if(os.path.basename(self.fileName_choose) == os.path.basename(mypath)):
#					print ("你选择了常用文件库本身，不能写入，但列表框内的字符将被更新！")
					reply = QMessageBox.information(self,"文库更新提示", "文件："+self.fileName_choose+" 为文库设置文件，你要更新吗？",QMessageBox.Yes | QMessageBox.No)#使用infomation信息框v0.62
					if(reply==QMessageBox.Yes):
						for i in range(1,self.model.rowCount()):
							mylist1.append(self.model.item(i).index().data())#获取字符
						self.WLinetoFile(mylist1,mypath,-1)
				else:
#					print ("文件名不在列表内,当前选中第",lnum,"行，在其后插入（默认首行0）：")
					reply = QMessageBox.information(self,"文库添加提示", "文件："+self.fileName_choose+" 尚未在文库，你确定添加吗？", QMessageBox.Yes | QMessageBox.No)  
					if(reply==QMessageBox.Yes):
						lstr=os.path.split(self.fileName_choose)[1]
						self.AddItemView(lnum,lstr)
						self.WLinetoFile(mylist,mypath,lnum)
			else:
#				print ("\n\t文件名已在列表内，不进行添加，但正好为列表显示文件时，更新写入列表字符。")
				if(self.fileName_choose==filet):
					if(self.Expfnow==0):#全览模式下保存
						reply = QMessageBox.information(self,"文件覆盖提示", "文件："+self.fileName_choose+" 将被重写覆盖，你确定吗？",QMessageBox.Yes | QMessageBox.No)  
						if(reply==QMessageBox.Yes):
							self.WListtoFile(mylist,self.fileName_choose)
					else:#分页模式下保存
						reply = QMessageBox.information(self,"文件覆盖提示", "文件["+self.fileName_choose+"]正在分页模式下操作，如果保存将只更新本页字符，你确定吗？",QMessageBox.Yes | QMessageBox.No)  
						if(reply==QMessageBox.Yes):
							self.UpListtoFile(mylist,self.fileName_choose)

			fh.close()
		self.ui.show()
#		self.show()

# 53 37 (3589)

	def WLinetoFile(self,llist,lpath,lnum):#行更新进文件
#		print("进入加新行进文件操作，新行:",self.fileName_choose,"\n\t准备写至：",lpath)
#		print("显示列表为：",llist)
		fh1=open(lpath,mode='r+t',encoding='UTF-8')
		if fh1:
			fh1.seek(0)#读取文件时候要将文件指针指向第一个
			data=fh1.read()
			mylist = data.split("\n")#含完整的文件路径
		fh1.close()
		if(lnum>=0):
			mylist.insert(lnum,self.fileName_choose)
			fh1=open(lpath,mode='w+t',encoding='UTF-8')
			if fh1:
				fh1.seek(0)
				for i in range(len(mylist)):
					if mylist[i].strip():
#						print("准备将第",i,"项写入文件：",lpath)
						fh1.write(mylist[i]+'\n')
			fh1.close()
		else:#根据删除、拖放更新文件列表
			fh1=open(lpath,mode='w+t',encoding='UTF-8')
			if fh1:
				fh1.seek(0)
				for i in range(len(llist)):
					for i1 in range(len(mylist)):
						if(llist[i].strip()):
							lstr=os.path.split(mylist[i1])[1]
							if(llist[i]==lstr):
#								print("第",i,"项：",llist[i],"-->对应完整路径：",mylist[i1],"写入")#此法不能删除某一同名文件
								fh1.write(mylist[i1]+'\n')
								break
#							else:
#								print(lstr,"非对应路径，不予写入文件：",lpath)

			fh1.close()

# 37 18 (3643)
						
	def WListtoFile(self,mylist,lpath):#整列表转文件
#		mypath=os.getcwd()+"/"+self.OftenFiles
#		print("进入写文件操作，文件:",self.fileName_choose,"\n\t准备压栈至：",lpath)
		fh1=open(lpath,mode='w+t',encoding='UTF-8')
		if fh1:
			fh1.seek(0)#注意读取文件时候要将文件指针指向第一个
#		with open(mypath, mode='a+t',encoding='UTF-8') as fh:
#'r'读,'w'写,'a'追加,'r+'=r+w可读写，若不存在就报错(IOError)'w+'=w+r可读写，若不存在就创建）
#'a+'=a+r可追加可读，若不存在就创建；二进制文件，就都加一个b：'rb','wb','ab','rb+','wb+','ab+'
		for i in range(1,self.model.rowCount()):
			s=self.model.item(i).index().data()#获取字符
#			if s.strip():
#				print("准备将第",i,"项写入文件：",s)
			fh1.write(s+'\n')

		fh1.close()

# 18 17 (3681)
			
	def UpListtoFile(self,mylist,lpath):#本页列表更新进文件
#		mypath=os.getcwd()+"/"+self.OftenFiles
		print("进入更新列表至文件操作，文件:",self.fileName_choose,"\n\t准备压栈至：",lpath)
		fh1=open(lpath,mode='w+t',encoding='UTF-8')
		if fh1:
			fh1.seek(0)
		for i in range(0,self.Expbnow):
			fh1.write(self.ViewList[i]+'\n')
		for i in range(0,self.model.rowCount()):
			s=self.model.item(i).index().data()#获取字符
			fh1.write(s+'\n')
		for i in range(self.Expfnow,self.lViewList):
			fh1.write(self.ViewList[i]+'\n')

		fh1.close()

# 17 31 (3719)

	def	slot_btn_openFile(self):#显示上栏文件
		#print("\n进入slot_btn_openfile->")
		fh=False
		mypath=os.path.join(os.getcwd(),self.OftenFiles)
		fh1=open(mypath,mode='r',encoding='UTF-8')
		if fh1:
			data=fh1.read()
			filelist=data.split("\n")
		fh1.close()
		i=self.model.item(0).checkState()#检测顶行是否勾选，决定是之后文件格式行显示否
		#print("\n\t检测顶行勾选与否：",i)
		if(i>0):
			self.FormatShow=True#格式行显示
			#print("\n\t格式行显示开关打开",self.FormatShow)
		else:
			self.FormatShow=False#格式行不显示
			#print("\n\t格式行显示开关关闭",self.FormatShow)

		i=self.OnOpNumber()#v0.76
		if (i<=0):
			slecstr=mypath
		else:
#			print("\n\ti>0,i=",i)
			if(filelist):
				slecstr=os.path.join(os.getcwd(),"src",filelist[i-1])
		self.fileName_choose=slecstr
		#print("\n当前打开文件self.fileName_choose名： ",self.fileName_choose)
		self.prompstr="" #slecstr v0.76
		self.myfileopen(slecstr,1)

# 31 21 (3737)

	def	slot_btn3_openFile(self):#显示下栏文件
		#print("\n进入slot_btn3_openfile->")
		fh=False
		mypath=os.path.join(os.getcwd(),self.OftenFiles)
		fh1=open(mypath,mode='r',encoding='UTF-8')
		if fh1:
			data=fh1.read()
			filelist=data.split("\n")
		fh1.close()
		i=self.OnOpNumber()#v0.4
		if (i<=0):
			slecstr=mypath
			#self.fileName_choose=mypath
		else:
#			print("\n\ti>0,i=",i)
			if(filelist):
				slecstr=os.path.join(os.getcwd(),"src",filelist[i-1])
		self.prompstr="" #slecstr v0.76
		self.myfileopen(slecstr,2)

# 21 242 (3738)

	def AltStr (self,slecstr,digit_num,expbnow):#分层拆解括号串
#digit_num,8程序判断小数位数，>=0表强制输出小数位,-3表示不计算；expbnow表示计算1与否0,也表示当前表首项self.Expbnow位置
		
		print("\n\n\t＝＝＝进入计算字符串分解方法AltStr：",slecstr)
#		str1=self.ui.lineEdit_2.text()
#		slecstr=self.model.item(0).index().data()#获0行字符#1015
		mystr=slecstr
#		print("字串为：",mystr)
		strpara=" "
		str1=mystr
#		print("字串为：",str1,"分隔符为[",strpara,"]")
		#strlist=[]
		strlist=str1.split()#strpara
		ns = len(strlist)
		#i1 = len(strpara)
#		print("一级分解后计算字符串成为表：",strlist,"\t共",ns,"项")
		#if (i1==0):
		#	strpara0=""
		itt=0
		pickp=False
		while(itt<ns):#各表项遍历
			mystr= strlist[itt]
			str1t = strlist[itt]#分解的字串项
	#		print("\n分解的字串项：",str1t)
			fmt=self.floatfmt(str1t)#v0.60
	#		print("\t字串小数位数：",fmt)
			bracketn = 0
			slen = len( str1t)
			nct =0 
			while(nct < slen):
				strn = str1t[nct]
				nct+=1
				if(strn == '('):
					bracketn = bracketn+1
	#		print("字符",str1t,"有",bracketn,"个括号")
			nct1=0
			k1=0
			passn=0
			while(k1<=bracketn):#v0.951while(k1<bracketn):#各层括号解析
				if(passn>=slen-1):
	#				print("\n\t循环入口，忽略串长",passn,">=净字符数：",slen)	
					break
	#			else:
	#				print("\n\t循环入口，忽略串长",passn,"<净字符数：",slen)						
				bracketnt = 0
				numn = 0
				bracketb = 0
				brackete = 0
				nct = 0
				sta = 1
				slen = len( str1t)
				while (nct < slen):#找出(需拆解的)最内层括号序号v0.963
					if(nct>nct1+passn):#
						strn = str1t[nct]
						if(strn == '(') :
							bracketnt = nct
						elif(strn==')') :
							bracketb = bracketnt
							brackete = nct
							break
					nct +=1
				sta=brackete-bracketb-1
				print("\t第",k1,"层括号开始于：",bracketb,"\t结束于",brackete,"\t净字符数：",sta,"忽略串长",passn)
				if(bracketn==0):#:k1#v0.951没有括号
					prestr =""
					midstr = mystr#strlist[itt]#str1t
					endstr =""
					oristr=""
				elif(k1==bracketn):
					prestr =""
					midstr = str1t
					endstr =""
					oristr=""
				else:

					prestr = str1t[0:bracketb]
					midstr = str1t[(bracketb+1):brackete]
					endstr = str1t[(brackete+1):]
					oristr=midstr
				print("\t第",k1,"层括号分解后，前串：",prestr,"\t中串：",midstr,"\t后串：",endstr,"操作格式行号",expbnow)
				if(expbnow>=0):#!=0):v0.952由之前的计算标志修改为参照行
					print("\t判断为需变量代换，串长",len(midstr))
					transferp=False
					if (len(midstr) >0):#!= 0):
#						print("\t\talt中间字串：",midstr)
		#				if(midstr.find('@')>=0):#midstr[0]=='@'):
						if(midstr[0]=='@'):
							print("\t\tAltStr准备弹出框运行")
							midstr = self.PopList(midstr,expbnow)
							print("AltStr弹出框获得输入：",midstr)
							transferp=True
						elif(not self.IsNumber(midstr)):#如果有非数字符，进行解析
		#					print("\t\t首字非@字符串分支1")
							if(midstr.find(':')>=0 or midstr.find('?')>=0 or midstr.find(',')>=0):
								print("\t\t",midstr,"首字非@，内含:?,字符串分支2,调用PickList求值,操作格式行号[",expbnow,"]")
								
								pklist=self.PickList(midstr,expbnow)
								print("\t\tPicklist返回表",pklist)
								lp=len(pklist)
								if(lp==1):
									midstr=pklist[0]
								elif(lp==2):
									midstr=pklist[0]
									if(len(pklist[1])>0):
										pickstr2=pklist[1]
										pickp=True
								print("\t\t\t选取首项返回结果[",midstr,"]，第二项附于总返回值末")
								transferp=True
							elif(midstr.find('#')>=0):#末尾#表示有小数进一取整
								if(self.IsNumber(midstr[:-1])):
									midstr=self.EngInt(midstr[:-1])
#								print("\t\t\t\t无@有＃字符串分支4,小数进一取整成",midstr)
							else:#就在索引文件中找变量的赋值
			#					print("\t\t\t\t无@无:?;＃字符串分支5")
								Indexpath=os.path.join(os.getcwd(),self.IndexFile)
								fh1=open(Indexpath,mode='r',encoding='UTF-8')
								if fh1:
									data=fh1.read()
									filelist=data.split("\n")
								fh1.close()
			#					print("midstr[",midstr,"]准备搜索摘引文件变量")
								if(data.find(midstr)>=0):
			#						print("\t\tAltStr搜寻索引文件:",Indexpath,"扫描发现待确认赋值变量字串(",midstr,")")
									parap=False
									lf=len(filelist)
									for il in range(lf-1,0,-1):#
										linedata=filelist[il]
										lls=len(linedata.split())
										if(lls>3):
							#				print("\t扫描",il,"行[",linedata,"]")
							#				if(linedata.split()[3].find(midstr)>=0):
											loclist=self.psplit(linedata,'"','"')
											llsp=len(loclist)
							#				print("\t\t双引号分隔成的列表项数:",llsp)
											if(llsp>=3):
												if(loclist[2].find(midstr)>=0):
													if(loclist[1][1:-1].strip()):
														parap=True
														strt=loclist[1][1:-1]#midstr
														if(strt[-1]=='⌇'):
															strt=strt[:-1]
														print("\t\t搜索摘引文件",il,"行",loclist[2],"中发现字串[",midstr,"]->变量值确认为[",strt,"]")
														break
			#								else:
			#									print("\t\t双引号拆分列表项数小于3")
									if parap:
										midstr=strt
									if(digit_num!=-3):
										print("\t\t\tAltstr中间1待计算字串[",midstr,"]")
										if(not self.IsNumber(midstr)):
											midstr=self.strcacu(midstr)
										#midstr=self.strcacu(midstr)
									if(midstr==oristr and (not self.IsNumber(midstr))):
										midstr='('+midstr+')'
										passn+=brackete#括号查找点后推到忽略括号后
										print("\t\t\t变量代换未确认,返回原表字串[",midstr,"]")
								else:
									if(digit_num!=-3):
										print("\t\t\tAltstr中间2待计算字串[",midstr,"]")
										if(not self.IsNumber(midstr)):
											midstr=self.strcacu(midstr)
										#midstr=self.strcacu(midstr)
									if(midstr==oristr and (not self.IsNumber(midstr))):
										midstr='('+midstr+')'
										passn+=brackete#括号查找点后推到忽略括号后
										print("\t\t变量代换搜寻摘引文件:",Indexpath,"未找到变量代换,返回原表字串[",midstr,"]")
						#else:
						#if(not transferp):
						mystr=midstr
						str1t=prestr+mystr
						str1t=str1t+endstr
		#				if(digit_num!=-3):#v0.952调整digit_num==-3为不计算
		#					print("Altstr中间3待计算字串[",midstr,"]")
		#					if(not self.IsNumber(str1t)):
		#						str1t=self.strcacu(str1t)#midstr)
						mystr=str1t
						midstr=str1t#v0.951
						print("\t第",k1,"次括号运算后，成为串：",str1t)
				else:
					print("\t\t判断为不需变量代换")

				if(not transferp):
					k1+=1	
				else:
					#if(k1>bracketn):
					#str1t=midstr
					ncte =0 #v0.967
					slen=len(str1t)
					bracketn=0
					#passn=0
					while(ncte < slen):
						strn = str1t[ncte]
						ncte+=1
						if(strn == '('):
							bracketn = bracketn+1
					if(bracketn>0):
						k1=0
			#		print("循环末重新统计字符串",str1t,"有",bracketn,"个括号")

#			print("运算前，字串为：",mystr)#v0.85
			if(digit_num!=-3):#v0.952调整digit_num==-3为不计算
			#	print("Altstr中间4待计算字串[",mystr,"]")
				if(not self.IsNumber(mystr)):
					mystr=self.strcacu(mystr)
#			print("运算后，成为串：",mystr)
			#v0.60小数位输出
			if(self.IsNumber(mystr)):
			#	if(self.floatfmt(mystr)!=0):#v0.7
#				fmt=self.floatfmt(mystr)
				value=float(mystr)
#				print("Alt实数运算结果：",value)
				if(digit_num==8):#<0):v0.97确定8为自动判断，-3不计算
					if((abs(value)<1e5) and (abs(value) >1e-3)):
						mystr=str(round(value,fmt))#self.fmt))
#						print("Alt实数自动判断输出小数位",fmt,"，数字输出为",mystr)
				elif(digit_num>=0):					
					if((abs(value)<1e5) and (abs(value) >1e-3)):
						if(digit_num==0):
							mystr=str(round(value))
						else:
							mystr=str(round(value,digit_num))
#						print("Altstr强制输出小数位",digit_num,"，数字输出为",mystr)
#				else:
#					print("Altstr第2项参数",digit_num,"无格式变动，输出为",mystr)
			strlist[itt]=mystr
			#else:
			#	strlist[itt]=str1t
#			print("\n\t第",itt,"表项运算后，成为串：",strlist[itt])
			if(itt==0):
				str1=strlist[itt]
			else:
				str1=str1+" "+strlist[itt]
			itt+=1

			if(pickp):
				str1=str1+' '+pickstr2
			#mystr=str1
			#self.FirstLine(mystr)
			print("\n\t＝＝＝Altstr第",k1,"层括号运算后，成为串：",str1,"\n\n")
			return str1

# 242 516 (3760)

	def strcacu (self,mystr):#算式串计算转化
		caculist1=["sin","cos","tg","ctg","arcsin","arccos","arctg","sinh","cosh","tgh","abs","rand"]
		caculist2=["^", "ln", "lg"]
		caculist3=["*","/"]
		caculist4=["+", "-"]
		listn = 12
		passt = 0
#		self.mystr=self.ui.lineEdit_2.text()
		found1 = len(mystr)#self.
		rank =listn
		inow=0#1014
		i1=0
		value=""
		#print("\n进入字符串计算strcacu，字符串为：",mystr)#1014self.

		while i1<listn:
			foundt = mystr.find(caculist1[i1],inow)#1014self.
			if(foundt>=0): 
#				print("计算字符串[ ",mystr," ]中发现一级优先计算符(",caculist1[i1],")位于",foundt)#self.
				if(foundt <= found1):
					rank = i1
					found1 =foundt
				passt = 1
			i1 +=1
#		print("\n位置1发现")#,self.mystr,"第[",rank,"]运算串",caculist1[rank])
		while(passt ==1):
			numbers = 0
			i5=0
#			print("\t一级前strcacu->ArrangStr中一级运算符:",caculist1[rank],",found1=",found1)
			if(found1>=0):
				loclist=self.ArrangStr(mystr,caculist1[rank])#v0.956
				numt1id=loclist[0]
				numt1=loclist[1]
			value=""#1014
			if(numt1id[1]==1):#1014
				if(numt1[2]=="sin"):
					
					cacustrt = numt1[1]
					numt1[1]=""
					numt1id[1]=0
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.sin (para1)
						numbers = 1
#					print("\tself.IsNumber(cacustrt)值：",self.IsNumber(cacustrt))
					
#					else:print("\tcacustrt.isalnum()值：",cacustrt.isalnum())
				if(numt1[2]=="cos" ):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.cos (para1)
						numbers = 1
				if(numt1[2]=="tg"):
				
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.tan (para1)
						numbers = 1
				if(numt1[2]=="ctg"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = 1.0/math.tan (para1)
						numbers = 1
				if(numt1[2]=="arcsin"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.asin (para1)
						numbers = 1
				if(numt1[2]=="arccos"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.acos (para1)
						numbers = 1
				if(numt1[2]=="arctan"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.atan (para1)
						numbers = 1
				if(numt1[2]=="asinh"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.asinh (para1)
						numbers = 1
				if(numt1[2]=="acosh"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.acosh (para1)
						numbers = 1
				if(numt1[2]=="atanh"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.atanh (para1)
						numbers = 1
				if(numt1[2]=="abs"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						para1= float (cacustrt)
						value = math.fabs (para1)
						numbers = 1
				if(numt1[2]=="rand"):
					
					cacustrt = numt1[1]
#					print("\tstrcacu函数输入值：",cacustrt)
					if(self.IsNumber(cacustrt)):
						value = radom.randint()
						numbers = 1
				else:
					passt=0

			if(value != ""):#滚动输出
				if(numt1id[0]==1):
					mystr=numt1[0]+str(value)#self.
					numt1id[0]=0
					if(numt1id[4]==1):
						mystr=mystr+numt1[4]#self.self.
						numt1id[4]=0
				else:
					mystr=str(value)#self.
					if(numt1id[4]==1):
						mystr=mystr+numt1[4]#self.self.
						numt1id[4]=0
#				print("一级运算",cacustrt,")","\t计算结果值：",value,"mystr=",mystr)#self.
			else:#1014
				inow+=found1+1

				#self.ui.lineEdit_3.setText(self.mystr)
#		print("\n位置2",mystr)#self.
		listn = 3
		passt = 0
		found1 = len(mystr)#self.
		rank =listn
		inow=0#1014
		i1=0
		while (i1<listn):
			foundt = mystr.find(caculist2[i1],inow)#self.
#			print("\t遍历一级计算串[",i1,"]=",caculist2[i1],"foundt=",foundt)
			if(foundt>=0): 
#				print("计算字符串[ ",mystr," ]中发现二级优先计算符(",caculist2[i1],")")#self.
				if(foundt <= found1):
					rank = i1
					found1 =foundt
				passt = 1
			i1+=1
		while(passt ==1):
			numbers = 0
			i3=rank
#			print("\t二级前strcacu->ArrangStr中运算符:",caculist2[rank])
			loclist=self.ArrangStr(mystr,caculist2[rank])#1014self.
			numt1id=loclist[0]
			numt1=loclist[1]
			value=""#1014
			numbers=0
			if(numt1id[1]==1):#1014
				if( numt1[2]=="^"):
					if(numt1id[1]==1):
						cacustrt1 = numt1[1]
						numt1id[1]=0
						numbers+=1
#						print("\tstrcacu函数输入值一：",cacustrt1)
					if(numt1id[3]==1):					
						cacustrt2 = numt1[3]
						numt1id[3]=0
						numbers+=1
#						print("\tstrcacu函数输入值二：",cacustrt2)
						para2= float (cacustrt2)
						numt1id[3]=0
					if((cacustrt1[0] == 'e') or (cacustrt1[0] == 'E')):
						numt1id[1]=0
						value = math.exp (para2)
					elif (numbers>=2) :
						para1= float (cacustrt1)
						#numt1id[1]=0
						value = math.pow (para1,para2)
#						print(cacustrt1,"^",cacustrt2,"=",value)
				if( numt1[2]=="ln"):
					if(numt1id[1]==1):
						if(self.IsNumber(numt1[1])):
							cacustrt = numt1[1]
#							print("\tstrcacu函数ln输入值：",cacustrt)
							para1= float (cacustrt)
							#numbers =1
							value = math.log (para1)
							numt1id[1]=0
							#print("\tln",cacustrt,"=",value)
				if( numt1[2]=="lg"):
					if(numt1id[1]==1):
						
						cacustrt = numt1[1]
#						print("\tstrcacu函数ln输入值：",cacustrt)
						para1= float (cacustrt)
						#numbers =1
						value = math.log10 (para1)
						numt1id[1]=0
						#print("\tlg",cacustrt,"=",value)
					mystr=str(value)#self.
#					print("\n\t***mystr值更新为",mystr)#self.

			if(value != ""):#滚动输出
				if(numt1id[0]==1):
					mystr=numt1[0]+str(value)#self.
					numt1id[0]=0
					if(numt1id[4]==1):
						mystr=mystr+numt1[4]#self.self.
						numt1id[4]=0
				else:
					mystr=str(value)#self.
					if(numt1id[4]==1):
						mystr=mystr+numt1[4]#self.self.
						numt1id[4]=0
#				print("二级运算计算结果值：",value,"\tmystr=",mystr)#self.
				#self.ui.lineEdit_3.setText(self.mystr)
			else:
				inow+=found1+1#1014

	
			passt = 0
			found1 = len(mystr)#self.
			rank =listn
			i2=0
			while(i2<listn):
				foundt = mystr.find(caculist2[i2],inow)#1014#self.
				#foundt = found(caculist2[i1],str)
				if(foundt>=0): 
					if(foundt <= found1):
						rank = i2
						found1 =foundt
					passt = 1
				i2+=1

#		print("\n位置3",mystr)#self.
		listn = 2
		passt = 0
		found1 = len(mystr)#self.
		rank =listn
		inow=0#1014
		i1=0
		while(i1<listn):
			foundt = mystr.find(caculist3[i1],inow)#1014#self.
			if(foundt>=0): 
#				print("计算字符串[ ",mystr," ]中发现三级优先计算符(",caculist3[i1],")")#self.
				if(foundt <= found1):
					rank = i1
					found1 =foundt
				passt = 1
			i1+=1
		while(passt ==1):
			numbers = 0
			i3=rank
#			i5=0
#			print("\t三级前strcacu->ArrangStr中运算符:",caculist3[rank])
			loclist=self.ArrangStr(mystr,caculist3[rank])#1014#self.
			numt1id=loclist[0]
			numt1=loclist[1]
			value=""#1014
			if(numt1id[3]==1):#1014
				if( numt1[2]=="*"):
					if(numt1id[1]==1):
						
						cacustrt1 = numt1[1]
#						print("\tstrcacu函数输入值*：",cacustrt1)
						if(cacustrt1.isdigit() or (cacustrt1[0]=='-' and cacustrt1[1:].isdigit())):
							para1= int (cacustrt1)
						else:
							para1= float (cacustrt1)
						#para1= float (cacustrt1)
						numbers +=1
						numt1id[1]=0
					if(numt1id[3]==1):
						
						cacustrt2 = numt1[3]
#						print("\tstrcacu函数输入值：%s\n",cacustrt2)
						if(cacustrt2.isdigit() or (cacustrt2[0]=='-' and cacustrt2[1:].isdigit())):
							para2= int (cacustrt2)
						else:
							para2= float (cacustrt2)
						#para2= float (cacustrt2)
						numbers +=1
						numt1id[3]=0
					if(numbers>1):
						value = para1 * para2
				if( numt1[2]=="/"):
					if(numt1id[1]==1):
						
						cacustrt1 = numt1[1]
#						print("\tstrcacu函数输入值/：%s\n",cacustrt1)
						if(self.floatfmt(cacustrt1)==0):
							para1= int (cacustrt1)
						else:
							para1= float (cacustrt1)
						#para1= float (cacustrt1)
						numbers +=1
						numt1id[1]=0
					if(numt1id[3]==1):
						
						cacustrt2 = numt1[3]
#						print("\tstrcacu函数/输入值：%s\n",cacustrt2)
						if(self.floatfmt(cacustrt2)==0):
							para2= int (cacustrt2)
						else:
							para2= float (cacustrt2)
						#para2= float (cacustrt2)
						numbers +=1
						numt1id[3]=0
					if(numbers>1):
						if(math.fabs(para2)<1e-10):
							print("除数不能为零！\n")
						else :
							value = para1 / para2
#					if(numt1id[0]!= 0):
#						str1 = numt1[0]+str1
#					if(numt1id[4]!= 0):
#						str1 = str1+numt1[4]
					
#					mystr = str(value)#self.
	
			if(value != ""):#滚动输出
				if(numt1id[0]==1):
					mystr=numt1[0]+str(value)#self.
					numt1id[0]=0
					if(numt1id[4]==1):
						mystr=mystr+numt1[4]#self.#self.
						numt1id[4]=0
				else:
					mystr=str(value)#self.
					if(numt1id[4]==1):
						mystr=mystr+numt1[4]#self.#self.
						numt1id[4]=0
				#print("三级运算结果值：",value,"mystr=",mystr)#self.
			else:
				inow+=found1+1#1014
					
					#self.ui.lineEdit_3.setText(mystr)#self.
			passt = 0
			found1 = len(mystr)#self.
			rank =listn
			i1=0
			while(i1<listn):
				foundt = mystr.find(caculist3[i1],inow)#1014#self.
				#foundt = found(caculist3[i1],str)
				if(foundt>=0): 
					if(foundt <= found1):
						rank = i1
						found1 =foundt
					passt = 1
				i1+=1
#		print("\n位置4",mystr)#四级运算开始，＋，－#self.
		listn = 2
		passt = 0
		found1 = len(mystr)#self.
		rank =listn
		inow=0#1014
		i1=0
		while(i1<listn):
			foundt = mystr.find(caculist4[i1],inow)#1014#self.
			if(foundt>=0): 
#				print("计算字符串[ ",mystr," ]中发现四级优先计算符(",caculist4[i1],")")#self.
				if(foundt <= found1):
					rank = i1
					found1 =foundt
				passt = 1
			i1+=1
		while(passt ==1):
			numbers = 0
			i3=rank
			i5=0
#			print("\t四级前strcacu->ArrangStr中运算符:",caculist4[rank])
			loclist=self.ArrangStr(mystr,caculist4[rank])#1014#self.
			if(len(loclist)>0):
				numt1id=loclist[0]
				numt1=loclist[1]
			else:
				numt1=[0,0,0,0,0]

			value=""#1014
			if(numt1id[3]==1):#1014

				if( numt1[2]=="+" ):
					if(numt1id[1]==1):
						cacustrt1 = numt1[1]
						if(cacustrt1.isdigit() or (cacustrt1[0]=='-' and cacustrt1[1:].isdigit())):
							para1= int (cacustrt1)
						#	print("整数",para1)
						else:
							para1= float (cacustrt1)
						#	print("实数",para1)
						numbers +=1
						numt1id[1]=0
						#print("\tstrcacu函数输入值1：",cacustrt1)
					if(numt1id[3]==1):
						cacustrt2 = numt1[3]
						if(cacustrt2.isdigit() or (cacustrt2[0]=='-' and cacustrt2[1:].isdigit())):
						#if(self.floatfmt(cacustrt2)==0):
							para2= int (cacustrt2)
						#	print("整数",para2)
						else:
							para2= float (cacustrt2)
						#	print("实数",para2)
						numbers +=1
						numt1id[3]=0
						#print("\tstrcacu函数输入值2：",cacustrt2)
					else :
						passt=1
						break
					if(numbers>1):
						value = para1 + para2
						numbers = 2
				if( numt1[2]=="-"):
					if(numt1id[1]==1):
						#i4=len(numt1[1])
						cacustrt1 = numt1[1]#v0.73
						if(cacustrt1.isdigit() or (cacustrt1[0]=='-' and cacustrt1[1:].isdigit())):
						#if(self.floatfmt(cacustrt1)==0):
							para1= int (cacustrt1)
							#print("整数",para1)
						else:
							para1= float (cacustrt1)
						numbers +=1
						numt1id[1]=0
					if(numt1id[3]==1):
						#i4=len(numt1[3])
						cacustrt2 = numt1[3]
						#if(self.floatfmt(cacustrt2)==0):
						if(cacustrt2.isdigit() or (cacustrt2[0]=='-' and cacustrt2[1:].isdigit())):
							para2= int (cacustrt2)
							#print("整数",para2)
						else:
							para2= float (cacustrt2)
						numbers +=1
						numt1id[3]=0
					else :
						passt=1
						break
					if(numbers>1):
						value = para1 - para2
						numbers = 2
	
					passt = 0
					found1 = len(mystr)#self.
					rank =listn
					i1=0
					while(i1<listn):
						foundt = mystr.find(caculist4[i1],inow)#1014#self.
						if(foundt>=0): 
							if(foundt <= found1):
								rank = i1
								found1 =foundt
							passt = 1
						i1+=1
				else:
					passt=0


			if(value != ""):#滚动输出
				if(numt1id[0]==1):
					mystr=numt1[0]+str(value)#self.
					numt1id[0]=0
					if(numt1id[4]==1):
						mystr=mystr+numt1[4]#self.#self.
						numt1id[4]=0
				else:
					mystr=str(value)#self.
					if(numt1id[4]==1):
						mystr=mystr+numt1[4]#self.#self.
						numt1id[4]=0
				#print("四级运算计算结果值：",value,"mystr=",mystr)#self.
				#self.ui.lineEdit_3.setText(mystr)#self.
			else:#1014
				inow+=found1+1

			#print("\n位置5",mystr)#self.
			listn = 2
			passt = 0
			found1 = len(mystr)#self.
			rank =listn
			i1=0
			while(i1<listn):
				foundt = mystr.find(caculist4[i1],inow)#1014#self.
				if(foundt>=0): 
					if(foundt <= found1):
						rank = i1
						found1 =foundt
						passt = 1
#					print("计算字符串[ ",mystr," ]中发现四级优先计算符(",caculist4[i1],")","foundt=",foundt,",found1=",found1,",passt=",passt)#self.
				i1+=1
#		print("cacustr返回值：",mystr)
		return mystr
# 516 236 (4003)

	def ArrangStr (self,lstr,symb):#字串数、符分拆至五位列表
		#lstr为字串，symb为运算符,五位列表：符、数、符、数、符
		state = 0
		statet = 0
		n5=[]
		i1=0
	#	print("\n进入ArrangStr,字符串为：[ ",lstr," ]运算符为：[",symb,"]\n")#(21.6^2+10^2)^0.5
		bracketn = 0
		slen = len (symb)
		xlen = len (lstr)
		ncs = 0
		nct = 0
		nct1 = 0
		pd0 = 0
		pd1 =0 
		founds=0
		pd3 = 0 
		strt = ""#'\0'
		numtt=numt=""
		numt1=["","","","",""]#self.
		numt1id=[0,0,0,0,0]#self.
		founds=lstr.find(symb)
		numberp=self.IsNumber(lstr)
	#	print("\n字串中发现运行符的位置为 ",founds,"是否数字:",numberp)
		loclist=[]
		if(founds>=0 and (not numberp)):
			while(nct < xlen):
				strnl = lstr[nct]#字串遍历 10+30^2*sinln4
	#			print("\n循环中,运算符为：[ ",symb," ]字符串为：[",lstr,"]\n")#30+50+70
	#			print("\n总共",xlen,"个字符，操作第",nct,"个字符，同类第",nct1,"个字符，当前字符[",strnl,"]")
	#			print("\n五位栈表当前：",numt1,"\n五位栈标记表当前：",numt1id,"中转串numtt[",numtt,"]\n")
				#字串是数字？#正负号#科学计数
				if (strnl.isdigit( ) or (strnl == '.') or (strnl == 'e')  or (strnl == 'E') or 
						(((strnl == '-')or(strnl=='+')) and (nct==0)) or 
						(((strnl == '-')or(strnl=='+'))	and ((lstr[nct-1] == 'e')or(lstr[nct-1] == 'E')))
					):
					state = 1
				else: state=0
#				print("状态参数：statet=",statet,"\tstate=",state)
				if(statet == state):#数与非数状态不变
					#print("\n\t数与非数状态不变")
					#print("\tnumt：",numt,"\tnumtt=",numtt,"\tnct1=",nct1)
					if(nct == (xlen-1)):#末字符时
						numt=numt+strnl#字串追加
						numtt=numt#记录字串
						if(state==1):#是数字
							if(numt1id[1]==0):
								numt1[1]=numtt#写入“数1串”栈[前串，数1串,运算串,数2串，后串]
								numt1id[1]=1#标记有“数1串”
								#print("\n\t分支1-1-1列表numt1：",numt1)
								#print("\n\t分支1-1-1列表numt1id：",numt1id)
							else:
								numt1[3]=numtt#已有“数1串”时写入“数2串”栈
								numt1id[3]=1#标记有“数2串”
								#print("\n\t分支1-1-2列表numt1：",numt1)
								#print("\n\t分支1-1-2列表numt1id：",numt1id)
						else:#不是数字
							if(numt1id[4]==0):
								numt1[4]=numtt#写入“后串”
								numt1id[4]=1#标记有“后串”
								#print("\n\t分支1-1-3列表numt1：",numt1)
								#print("\n\t分支1-1-3列表numt1id：",numt1id)
	
						break

					elif(nct==founds):#非末字#运算符处10+30^2*sinln4 1+2^3					
						numtt=numt #记录之前串符
						numt=strnl
						if(numt1id[0]==0):#"前串"栈空时，压栈
							numtp=lstr[0:nct]
							numt1[0]=numtp#列表第1格记录"前串"
							numt1id[0]=1#标记有"前串"
							numt1[2]=symb#列表第3格记录"运算串"
							numt1id[2]=1#标记有"运算串"
							nct+=slen-1
							state=0
							nct1=0
							numt=numtt=""
							#print("\n\t分支1-2高级运算符前串:",numtp)

					elif (strnl=="-"):#1014非末字为-号
						if(lstr[nct-1]!='e' and lstr[nct-1]!='E'):#v0.60
							if(nct<xlen-1):
								if(lstr[nct+1].isdigit( )):
									numtt=numt #记录之前串符
									numt=strnl
									#print("\t分支1-3数与非数状态未改变，但为‘-’号")
									#print("\tnumt：",numt,"\tnumtt=",numtt,"\tnct1=",nct1)
									nct1=0
									state=1
						else:#v0.60
							numt=numt+strnl					

					else:#非末字非运算符处
						numt=numt+strnl					
					nct1+=1
				else :#数与非数状态改变	
					numtt=numt #记录之前串符
					numt=strnl
		#			print("\t分支２数与非数状态改变")
		#			print("\tnumt：",numt,"\tnumtt=",numtt,"\tnct1=",nct1)
					nct1=0
					if(state==0):#分割串非数字时+
#						print("\t分支2-1为数字转非数字状态")
						if(nct == 0):#首字时
							numt=strnl
							#print("\n\t分支2-1-1首字串numt：",numt,"\tnct1=",nct1)
							nct1+=1#设置变化位置
	
						else:
							#numtt=numt #记录之前数符v0.6
							#numt=strnl#v0.6
							if (nct == (xlen-1)):#末字时
								#print("\n\t分支2-1-3末字串numt：",numt,"\t串长nct1=",nct1,"\tnumtt=",numtt)
								if(numt1id[1]==0):#"数1"栈空时，压栈
									numt1[1]=numtt#列表第2格记录运算串
									numt1id[1]=1#标记有"数1"
								elif (numt1id[3]==0):#"数2"栈空时，压栈
									numt1[3]=numtt#列表第4格记录运算串
									numt1id[3]=1#标记有"数2"

								if (numt1id[4]==0):
									numt=numt+strnl
									numt1[4]=numt#字串追加压入[后串栈]
									numt1id[4]=1#标记有后串
	
							elif(nct==founds) :#中字达到高级运算符时压栈数据
								#print("\n\t分支2-1-2中字串numt：",numt,"\tnumtt=",numtt)
								#print("\n\t\t分支2-1-2-1“数1串”空,压栈",numtt)
								numt1[1]=numtt#压栈列表第2格
								numt1id[1]=1#标记有“数1串”
								numt1[2]=symb#压栈列表第3格
								numt1id[2]=1#标记有“运算串”
								nct1=len(numtt) #临时借用nct1变量							
								if(nct1<nct+1):
									numt1[0]=lstr[0:founds-nct1]#压栈列表第1格
									numt1id[0]=1#标记有“前串”
								nct+=slen-1
								nct1=0
							elif(nct>founds+slen):
								#print("\n\t分支2-1-4中运算串后numtt：",numtt)						
								if(numt1id[1]==0) :#运算符后时，检查“数２串”栈
									#print("\n\t分支2-1-4-1中数2串压栈")	
									#if(IsNumber(numtt)):
										#print("\n\t分支2-1-4-1-1中运算串后有数")						
									numt1[1]=numtt#压栈列表第2格
									numt1[4]=lstr[nct:]#压栈列表第5格
									numt1id[1]=1#标记有“数1串”
									numt1id[4]=1#标记有“后串”
								elif(numt1id[3]==0) :#运算符后时，检查“数２串”栈
									#print("\n\t分支2-1-4-1中数2串压栈")	
									#if(self.IsNumber(numtt)):
										#print("\n\t分支2-1-4-1-1中运算串后有数")						
									numt1[3]=numtt#压栈列表第4格
									numt1[4]=lstr[nct:]#压栈列表第5格
									numt1id[3]=1#标记有“运算串”
									numt1id[4]=1#标记有“后串”
								#print("\n\t分支2-1-4列表numt1：",numt1)
								#print("\n\t分支2-1-4列表numt1id：",numt1id)
								break	
					else:#分割串数字时5
			#			print("\t分支２－２为非数转数字状态")
						if(nct == 0):#首字时
							numt=strnl
#							print("\n\t分支2-2-1首字串numt：",numt,"\tnct1=",nct1)
							nct1+=1#设置变化位置
						else:#非首字时5
	#						numtt=numt
	#						numt=strnl
							if (nct == (xlen-1)):#末字时
			#					print("\n\t分支2-2-2末字串numt：",numt,"\t串长nct1=",nct1,"\tnumtt=",numtt)
								if(numt1id[2]==0):#"运算串"栈空时，压栈实际分隔串
									numt1[2]=numtt#列表第3格记录运算串
									numt1id[2]=1#标记"运算串"
								elif(numt1[2]!=numtt):#检查实际分隔串与"运算串"不同时清空退出
			#						print("\n\t分支2-2-2-1实际分隔运算串[",numtt,"]与运算符[",symb,"]不同，处理清除")
									numt1id=[0,0,0,0,0]
									break	
									
								if(numt1id[1]==0):
									numt1[1]=numt#列表第2格记录"数1"串
									numt1id[1]=1#标记"数1"
								else:
									numt1[3]=numt#列表第4格记录"数2"串
									numt1id[3]=1#标记"数2"
							elif(nct==founds) :#运算符时
#								print("\n\t分支2-2-3中运算串numtt：",numtt)						
								if(numtt==symb):#判断是"运算串"
#									print("\n\t分支2-2-3-1是运算串！")						
									if(numt1id[2]==0):#“运算串”栈空时
#										print("\n\t分支2-2-3-1-1运算串空 ，压栈")						
										numt1[2]=numtt#压栈列表第2格
										numt1id[2]=1#标记有“运算串”
									else:#“运算串”满时,压入后串栈
#										print("\n\t分支2-2-3-1-1运算串满，压入后串退出！")						
										numt1[4]=lstr[nct-1:]#列表第5格记录后串
										numt1id[4]=1#标记有“后串”
										nct=xlen#退出
								else:#判断非"运算串"
#									print("\n\t分支2-2-3-2非运算串！")						
									if(numt1id[0]==0):#“前串”栈空时，压栈
										numt1[0]=numtt#列表第3格记录“前串”
										numt1id[0]=1#标记有“前串”
							elif(nct==founds+slen+1):#v0.969(nct>founds+slen):
				#				print("\n\t分支2-2-４中运算串后numtt：",numtt)						
								if(numt1id[3]==0) :#运算符后时，检查“数２串”栈
									if(self.IsNumber(numtt)):
#										print("\n\t分支2-2-4-1中运算串后有数")						
										numt1[3]=numtt#压栈列表第2格
										numt1[4]=lstr[nct]#压栈列表第5格
										numt1id[3]=1#标记有“数２串”
										numt1id[4]=1#标记有“后串”
									else:	
#										print("\n\t分支2-2-4-2中运算串后无数")						
										numt1[4]=lstr[nct-len(numtt)]#压栈列表第5格
										numt1id[4]=1#标记有“后串”
								break	
							elif(nct>founds+slen+1):
								if(numt1id[2]==1):
									if(numt1[2]!=numtt):
					#					print("\n\t分支2-2-5中实际分隔运算串[",numtt,"]不同于运算符[",symb,"]处理清除")
										numt1id=[0,0,0,0,0]
										break	
	
#				print("\n字串栈：",numt1)
#				print("\n字串栈标记：",numt1id)
								
				nct+=1
				strt = strnl
				statet =state 
			loclist.append(numt1id)
			loclist.append(numt1)
	#	print("\n输出五位栈表：",loclist)
		return loclist

# 236 73 (4520)
	def IsFloat(self,localstr):#检测字串是否浮点实数
#		print("进入IsFloat",localstr)
		lens=len(localstr)
		i1=0
		state=0
		while(i1<lens):
			if(i1==0):
				if (localstr[i1].isdigit( ) or (localstr[i1] == '.') or #字串是数字？
					(localstr[i1] == '-') or (localstr[i1]=='+')):
					state+=0
#					print("\t\t",localstr[i1])
				else:
					state+=1
#					print("\tstate=",state)
			else:
				if ((localstr[i1] == '.') or localstr[i1].isdigit( )):
					state+=0
#					print("\t\t",localstr[i1])
				else:
					state+=1
#					print("\tstate=",state)
			i1+=1
		if state>0:
#			print("\t字串[",localstr,"]不是纯浮点数。")
			justnumber=False
		else: 
#			print("\t字串[",localstr,"]是纯浮点数。")
			justnumber=True
		return justnumber
		
	def IsNumber (self,localstr):#检测字串是否实数
		#print("进入IsNumber",localstr)
		lens=len(localstr)
		i1=0
		state=0
		while(i1<lens):
			if(i1==0):
#				print("\t\t",localstr[i1])
				if (localstr[i1].isdigit( ) or (localstr[i1] == '.') or #字串是数字？
					(localstr[i1] == '-') or (localstr[i1]=='+')):
					state+=0
				else:
					state+=1
#				print("\tstate=",state)
			else:
#				print("\t\t",localstr[i1])
				if ((localstr[i1] == 'e')or(localstr[i1] == 'E')):#科学计数
					if(len(localstr)>i1+1):
						if(localstr[i1] == 'e'):
							substre=localstr.split('e')[1]
							if self.IsFloat(substre):
								state+=0
						elif(localstr[i1] == 'E'):
							substrE=localstr.split('E')[1]
							if(self.IsFloat(substrE)):
								state+=0
						else:
							state+=1
					else:
						state+=1
				elif (not (localstr[i1].isdigit() or (localstr[i1] == '.'))):
					state+=1
#				print("\t\tstate=",state)
			i1+=1

		if state>0:
#			print("\t字串[",localstr,"]不是数字。")
			justnumber=False
		else: 
#			print("\t字串[",localstr,"]是数字。")
			justnumber=True
		return justnumber

# 73 15

	def handle (self):
		i=self.OnOpNumber()#1016
		mystr=self.model.item(i).index().data()
#		print("获取字串",mystr)
		numberp=self.IsNumber(mystr)
		if(numberp):	
#			print("所获取字串是数字")
			self.FirstLine(mystr)
		else:
#			print("所获取字串非数字，开始计算")
			fmt=self.floatfmt(mystr)
			mystr=self.AltStr(mystr,fmt,1).split()[0]
			self.FirstLine(mystr)

# 15 23 (4831)
	
	def floatfmt (self,lstr):#获取浮点小数位
	#	print("检测字串：",lstr,"的小数位数->")
		ll=len(lstr)
		i0=lstr.find('.')
		imax=0
		if(i0>=0):
	#		print("第",i0,"位为小数点.")
			i1=i0+1
			it=0
			for i2 in range(i1,ll):
				if(lstr[i2].isdigit()):
					it+=1
					if(it>imax):
						imax=it
				else:
					it=0
					i0=lstr.find('.',i1)
					if(i0>i2 and i2<ll-1):
						i1=i0+1
	#		print("字串：",lstr,"的小数位数为：",imax)
		return imax

# 23 7 (4899)

if __name__ == '__main__':  #主程序
      
	app = QApplication(sys.argv)
	w=MindWay()
	app.exec_()

# 7 0
